										***README***

1. In the folder original_data_folders, there are seven language pairs in total. We can only extract the data from the tsv file in the language pair folders.
   There are "index, original, translation, scores, mean, z_scores, z_mean, model_scores" attributes in the tsv file. We only care about the attributes:
   "original: source sentence", "translation: machine translation sentence", "model_scores: human score".

2. You can view the before-and-after preprocessed dataframe visualizations in the jupyter notebook. At the same time, you can also access the organized raw data
   in the nested_list format such that: [[index, original, translation, scores, mean, z_scores, z_mean, model_scores], ...] in the folder "organized_raw_data".

3. By extracting the key information and preprocessed data, we received new data structure in the format of nest lists, such that: 
   [[src sent1, mt sent1, score1], [src sent1, mt sent1, score1]...]. All preprocessed data are in the folder "(KEY Folder)_after_processed_data".

4. All files are stored in the pickle file format. You can load it by simply using the "load_obj" function in the notebook.

5. For this dataset, we only have the source sentences and corresponding machine translation sentence without the reference sentence. So, the main objective of this
   dataset is to do the src-mt evaluation.