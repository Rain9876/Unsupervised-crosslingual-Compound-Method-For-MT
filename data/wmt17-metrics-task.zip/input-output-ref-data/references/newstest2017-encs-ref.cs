Osmadvacetiletý šéfkuchař nalezen mrtev v obchodě v San Francisku
Osmadvacetiletý šéfkuchař, který se nedávno přistěhoval do San Franciska, byl tento týden schodech místního obchodu.
Bratr oběti ale říká, že ho nenapadá, kdo by mu chtěl ublížit, a dodává: „Konečně se mu začalo dařit.“
Tělo nalezené ve Westfield Mall ve středu ráno bylo identifikováno jako osmadvacetiletý obyvatel San Franciska Frank Galicia, uvedla kancelář soudního lékaře.
Sanfranciské policejní oddělení sdělilo, že se jedná o násilnou smrt a probíhá vyšetřování.
Bratr oběti Louis Galicia pro stanici ABC KGO v San Francisku řekl, že Frank, který byl dříve řadovým kuchařem v Bostonu, získal svou vysněnou práci šéfkuchaře v restauraci Sons & Daughters před šesti měsíci.
Mluvčí restaurace Sons & Daughters řekl, že jsou jeho smrtí „šokováni a zničeni“.
„Máme malý tým, který pracuje jako úzce spojená rodina. Bude nám moc chybět,“ uvedl mluvčí.
V této těžké době patří naše myšlenky a zármutek Frankově rodině a přátelům.
Louis Galicia uvedl, že Frank nejprve přespával v ubytovnách, ale že nedávno „se mu konečně začalo dařit.“
„Našel si byt, chodil s dívkou,“ řekl Louis Galicia pro KGO.
Louis Galicia řekl, že ho nenapadá, kdo by chtěl jeho mladšímu bratrovi ublížit.
Měl laskavou duši a velké srdce.
Když se chtěl spojit s rodinou, vždy nám uvařil jídlo, udělal nám večeři,“ řekl Louis Galicia.
Nikdy se nechtěl účastnit žádné hádky.
Byl to bratr, který bral věci takové, jaké jsou.
„I kdyby všechno ostatní na světě bylo špatně, on byl nebroušený diamant, který ozářil každý den“, řekl.
Pokud byste měli jakékoliv informace, volejte na linku SFPD na čísle: 415-575-4444.
České dráhy investovaly do modernizace vozidel přes 31 miliard.
Mají klimatizaci i nové toalety.
V posledních šesti letech investoval státní dopravce do modernizace vozidel přes 31 miliard korun.
Třetina vozů je v současnosti vybavena klimatizací, zhruba polovina vlaků má nový systém uzavřených WC.
Částky na modernizaci v jednotlivých letech s výjimkou roku 2012 ovšem postupně klesají.
České dráhy v posledních šesti letech investovaly do modernizace vozidel přes 31 miliard korun.
Třetina vozů je v současnosti vybavená klimatizací, zhruba polovina vlaků má nový systém uzavřených WC.
Vynaložené peníze se projevily ve snížení průměrného stáří o dva roky u lokomotiv a samostatných jednotek a o šest let u klasických vagonů.
Větší podíl investic dal dopravce do regionální dopravy, kam směřovalo zhruba 60 procent uvedených peněz, 40 procent pak společnost investovala do obnovy vozidel pro dálkovou dopravu.
Průměrné stáří lokomotiv a jednotek v současnosti dosahuje 19 let.
Modernizovaná starší vozidla jsou ale v tomto ukazateli započítána jako zcela nová.
Pokud by se modernizace vozidel nepočítaly, vzrostlo by průměrné stáří hnacích vozidel ČD o deset let.
O něco starší jsou v průměru osobní vagony, jejichž průměrný věk při započtení modernizací činí 23 let.
Pokud by se bral v úvahu jen věk od data výroby, průměrné stáří těchto vozidel by činilo 33,4 roku.
Klasické soupravy složené z vagonů a tažené lokomotivou nicméně v posledních letech z české i celosvětové železnice postupně mizí a jsou nahrazovány motorovými nebo elektrickými jednotkami.
Mezi roky 2011 a 2015 ubylo lokomotiv z 280 na 223 kusů, podobně klesl i počet klasických vagonů z 2716 v roce 2011 na 2132 v polovině letošního roku.
Dopravce se zbavoval zejména starých vozidel vybavených koženkovými sedadly a dveřmi bez možnosti zablokování otevření během jízdy.
Od ledna do července nechal dopravce sešrotovat 110 těchto vozů.
Z investic, které do vozidlového parku plánují ČD uskutečnit v blízké budoucnosti, je možné uvést například nákup 50 vagonů pro rychlost do 200 kilometrů v hodině, které dopravce plánuje nasadit na mezinárodní lince Praha - Bratislava - Budapešť, nebo rámcovou smlouvu na nákup elektrických jednotek pro tuzemské rychlíkové trati.
Smlouva počítá s odběrem až 30 kusů motorových a 20 kusů elektrických jednotek.
Úřady čtvrt roku vědí o nelegální reklamě, nedokáží se jí zbavit.
Jsme naprosto bezmocní, přiznávají.
Už čtvrt roku redakce online deníku Aktuálně.cz sleduje příběh billboardu v jižních Čechách, který nyní láká motoristy k návštěvě Lipna, kde je nejen turisticky zajímavá procházka v korunách stromů, ale i olympijský park.
Správci dálnic vědí, že tam stojí načerno, ale tvrdí, že s tím nic nezmůžou.
Podobných reklam jsou po celé zemi stovky, možná tisíce.
Podle úředníků je na vině chatrný zákon, kvůli kterému není možné nelegální mobilní billboardy hned odstranit.
Zapotřebí je napřed složité byrokratické kolečko.
Mezitím si ale firma změní jméno a úřad je na ni krátký.
Anebo stačí reklamu posunout o pár metrů a úřední proces musí začít znova.
Ředitelství silnic a dálnic před čtvrt rokem přiznalo: u hlavního tahu z Českých Budějovic na Lipno stojí na našem pozemku u státní silnice reklamní billboard načerno.
Ani tři měsíce ale úředníkům nestačily k tomu, aby se zbavili nepovolené přenosné konstrukce s obřím inzertním plakátem.
Jako by nikomu nevadilo, že stojí těsně vedle vozovky, v padesátimetrovém ochranném pásmu, kde kvůli bezpečnosti nic stát nesmí.
Správci silnic tvrdí, že si s billboardem kvůli děravému zákonu nemohou jednoduše poradit.
Třeba ho naložit a odvézt pryč.
"To si nesmíme jen tak dovolit," říká mluvčí Ředitelství silnici a dálnic Nina Ledvinová a odkazuje na složité byrokratické kolečko, které odstranění billboardu musí podle zákona předcházet.
Případ tohoto konkrétního billboardu, jehož osud začal online deník Aktuálně.cz detailně sledovat na jaře, přitom není ojedinělý a ukazuje na obecný problém, který neumí stát a úřady efektivně a rychle řešit.
Jen v jižních Čechách redakce napočítala desítky podobných mobilních reklam umístěných proti pravidlům těsně vedle vozovky nebo v její blízkosti.
Podobně jsou na tom i další kraje.
"Máme potíže firmy donutit, aby poutače odstranily," potvrzuje šéf odboru dopravy českobudějovického krajského úřadu Jiří Klása, jehož kolegové podobné příběhy řeší.
Podle Klásy je na vině děravý zákon, který úředníky svazuje.
Napřed musí složitě majitele billboardu oslovovat, aby dal reklamu pryč.
Jenže šéfové firem jsou často nedostižní anebo znají fintu, kterou už Aktuálně.cz v minulosti popisovalo, když se o problematiku začalo detailněji zajímat: stačí mobilní stojan s reklamou posunout o pár metrů a úředníci mohou předchozí výzvu k odstranění černé inzerce hodit do koše.
To proto, že úřad musí přesně určit, kde nelegální billboard stojí.
"Pokud jej někdo posune a souřadnice najednou nesouhlasí, nahlíží se na to jako na nové zařízení a musíme majitele oslovit znovu," vysvětluje Jiří Klása.
Nový zákon nepomůže.
Změnu mohl přinést nový zákon, který od září příštího roku zakáže billboardy u dálnic a omezí je i u silnic I. tříd.
Kritici poukazují na to, že pravidla pro potírání nelegálních a snadno přenositelných reklam zůstanou stejná jako dosud.
A úřadům se tak neuleví.
Firmy tak dál mohou na pronájmech nelegálních ploch vydělávat desítky až stovky milionů korun ročně a nikdo na ně nemůže.
Například billboard lákající na Lipno patří společnosti Commerz Billboard.
Úředníci ji dobře znají: českobudějovický magistrát s ní aktuálně vede tři správní řízení za načerno postavené billboardy.
Firmě hrozí v každém řízení třísettisícová pokuta.
Jedná se o více reklam, které byly bez povolení umístěny v ochranném pásmu silnice I. třídy.
Řízení dosud nejsou ukončena, říká Jaroslav Mráz, šéf odboru dopravy českobudějovického magistrátu.
Reklama, o niž se Aktuálně.cz zajímá, sice mezi těmito případy ještě nefiguruje, brzy k nim ale s největší pravděpodobností přibude.
Podle mluvčí ŘSD Niny Ledvinové firma nereagovala na opakované písemné výzvy k odstranění, a případ se tak dostane na stůl krajským a pak nejspíš magistrátním úředníkům.
Společnost Commerz Billboard patří k těm podezřelým firmám, které se nedaří kontaktovat.
Nepřebírá poštu a oficiální sídlo na Žižkově zrušila před více než šesti lety.
Není ani jasné, kdo za ní stojí.
V minulosti pošta firmy chodila k jihočeskému podnikateli Antonu Fischerovi, který proslul ostrým sporem se šéfem českého zastoupení značky Hyundai.
Fischer, jehož společnost Euro Billboard si plochy od Comerz Billboard pronajímá a nabízí je inzerentům, však v minulosti odmítl jakoukoliv spojitost.
Přitom letos na jaře, když se ŘSD začalo na podnět Aktuálně.cz zajímat o reklamu na Lipno, nechal Fischer státní úředníky poslat dopis pro tajemnou společnost Commerz Billboard do svého penzionu, kde údajně nově firma sídlí.
Ani z této adresy se ovšem nikdo správcům dálnic dodnes neozval.
Marný boj.
Podobné mlčení nebo neprůhledné změny sídel nejsou neobvyklé.
Jedné firmě jsme před několika lety postupně dali pokuty za dva miliony korun.
Jenže změnila název a IČO a nebylo co řešit.
Exekutor případ vrátil, reklamy stály dál, možná na jiných místech.
Jsme proti podobným firmám a jejich podnikatelským praktikám dost bezmocní.
Je to jako boj s větrnými mlýny, přiznává pod podmínkou zachování anonymity jeden z úředníků.
Novelu zákona v tomto ohledu zatím nikdo neřeší.
Aktuálně.cz hovořilo s několika poslanci, které problém zaujal.
Dosud ale nevyvinuli žádnou aktivitu.
Naopak se objevili poslanci, kteří chtěli prodloužit termín pro zachování billboardů u hlavních českých komunikací.
Vláda to zamítla.
Billboardy jsou nejen pro celostátní, ale i krajské a obecní politiky velmi citlivé a poněkud schizofrenní téma.
Na jednu stranu vědí o společenské poptávce po jejich omezení, na druhou stranu je sami potřebují kvůli inzerci v předvolebních kampaních.
Nezastávám ten poměrně zavedený dojem, že když něco nefunguje, tak je potřeba měnit zákony.
Zemědělci letos sklidí méně obilí, ale více řepky a máku, odhadují statistici.
Podle odhadů Českého statistického úřadu bude sklizeň obilovin letos o 6,7 procenta nižší než loni.
Přesto letošní úroda převyšuje průměr za posledních pět i deset let.
Vyšší bude naopak sklizeň řepky (o 3,9 procenta) a máku (2,5 procenta).
Sklizeň obilovin bude letos o 6,7 procenta nižší než loni.
Zemědělci sklidí 7,2 milionu tun obilí.
Vyplývá to z odhadu, který podle stavu k 15. červenci zveřejnil Český statistický úřad.
Prvotní odhad před měsícem byl pesimističtější a předpokládal desetinový pokles proti loňsku.
Loňská sklizeň obilovin ale byla nadprůměrná.
Letošní úroda převyšuje průměr za posledních pět i deset let.
Naopak vyšší bude letos sklizeň řepky a máku.
Řepky pěstitelé sklidí o 3,9 procenta více než před rokem, kdy dostali pod střechu 1,256 milionu tun.
Letošní úroda máku by mohla být o 2,5 procenta vyšší než loňská.
Předpokládaný pokles produkce obilovin je způsobený jak snížením hektarového výnosu o 3,7 procenta na 5,71 tuny z hektaru, tak poklesem osevní plochy.
Zemědělci letos oseli o tři procenta méně polí.
Pšenice ozimé, která je pro Česko nejvýznamnější obilovinou, se letos podle odhadu sklidí o 3,3 procenta méně.
Farmáři ji přitom vyseli na více polí.
Na poklesu se ale podepíše nižší hektarový výnos, který klesne na 6,04 tuny.
Zhruba pětinový pokles statistici předpokládají u ječmene jarního, který se nejčastěji používá na výrobu piva.
Za snížením úrody stojí snížení osevních ploch o 15,2 procenta, ale i nižší hektarový výnos.
Ječmene ozimého se naopak urodí o 6,3 procenta více.
Vzroste také sklizeň žita.
Úrodu řepky statistici odhadují na 1,305 milionu tuny, což je proti loňsku více.
Osevní plochy se totiž rozšířily o 7,3 procenta.
Hektarový výnos ale bude o 3,2 procenta nižší než loni.
Letošní úroda řepky převýší desetiletý průměr o 13,3 procenta, zaseta je přitom na ploše o třetinu rozsáhlejší než před deseti lety.
V posledních čtyřech letech také přibývá polí s mákem.
Letos ho farmáři vyseli na 35.543 hektarech.
Proti roku 2008, kdy se mák v Česku pěstoval na rekordních 70 000 hektarech, je ale polí polovina.
Díky rozšíření osevních ploch bude letošní sklizeň máku bohatší.
Stoupne proti loňsku o 2,5 procenta na 27 423 tun.
Hektarový výnos ale bude o 6,1 procenta nižší.
Olomoučtí policisté obvinili dva muže za útok nožem a mačetou, soud je poslal do vazby.
Policie obvinila dva útočníky, kteří v úterý v centru Olomouce napadli nožem a mačetou pětatřicetiletého muže.
"Přestože se napadený snažil utéct, způsobili mu sečné a řezné zranění, které si vyžádalo ošetření v nemocnici a další léčení," uvedla policejní mluvčí Marie Štrbáková.
Oba zřejmé pachatele bezprostředně po útoku zadrželi policisté.
Žalobce podal návrh soudu na jejich vzetí do vazby a soud mu v pátek vyhověl.
Oběma mužům hrozí tři až deset let vězení.
Policisté obvinili dva zadržené z napadení pětatřicetiletého muže v centru Olomouce nožem a mačetou.
Útočníci mu způsobili sečná a řezná poranění, muž skončil v nemocnici.
Útoku předcházel incident mezi dvěma skupinami lidí, který se stal v úterý v pravé poledne na třídě Svobody, uvedla policie.
Pachatelé skončili ve vazbě, informovala olomoucká policejní mluvčí Marie Štrbáková.
Hromadná potyčka mezi dvěma rodinami se odehrála v prostoru zahrádky před barem Tratorie v bezprostřední blízkosti centra Olomouce.
Po agresivní slovní rozepři napadli dva útočníci za pomocí nože a mačety pětatřicetiletého muže.
Přestože se napadený muž snažil utéct, způsobili mu sečné a řezné zranění, které si vyžádalo ošetření v nemocnici a další léčení, uvedla policejní mluvčí.
Při potyčce, která vzbudila v centru města velkou pozornost a kvůli které muselo na místě zasahovat několik policejních hlídek i strážníků, šlo o rodinné spory.
Kriminalisté čtyřiatřicetiletého muže ze Slovenska a sedmatřicetiletého muže z Olomouce obvinili z pokusu těžkého ublížení na zdraví a výtržnictví.
Žalobce podal návrh soudu na jejich vzetí do vazby a soud mu v pátek vyhověl, doplnila mluvčí.
Mačetu použili v centru Olomouce při hromadné bitce útočníci také před pěti lety, stalo se to tehdy jen pár desítek metrů dále, před diskotékou Varna v Riegrově ulici.
Policisté tehdy uvedli, že skupina zhruba deseti cizinců se zbraněmi napadla hosty podniku, kteří stáli před vchodem.
Podle policie měli v rukou nože, hole a mačety.
Soud poté dva útočící cizince potrestal podmíněným trestem.
Opuštěné a prázdné domy v centru Prahy.
Budete překvapeni, možná kolem nich denně chodíte.
Jeden z nejkřiklavějších příkladů nevyužitého a prázdného domu je rozlehlá budova bývalého sídla IPB vprostřed Senovážného náměstí.
Ta už měla dávno fungovat jako hotel.
Jenže pořád nic.
Že je potřeba stavět v metropoli nové a nové byty a kanceláře?
A co využít stávající, často architektonicky cenné a chráněné?
Přímo v centru Prahy v bezprostředním okolí Václavského náměstí je několik činžovních domů, které i přes svou polohu, velikost a často i památkovou ochranu jen pustnou a zejí prázdnotou.
Nemovitosti v centru jsme vybrali pomocí projektu Prázdnédomy.cz, který mapuje dlouhodobě prázdné nemovitosti na území Česka.
Domy jsou obvykle obětí finančních problémů svých majitelů, neprůhledných vztahů mezi firmami nebo patří státu, který se jich neumí či nechce zbavit.
Prázdných domů je v Česku víc než bezdomovců.
Ať za ně majitelé platí speciální daň, chce iniciativa
Málem tu zastřelili Fidela Castra, žil tu i Hitlerův bratr.
Spisovatelé ukázali jinou Malou Stranu.
Nákupní apokalypsa.
Obchodní centra v USA zejí prázdnotou.
Na procházce Prahou Neznámou.
Karlín byl luxusním předměstím.
Územním plánem připomíná newyorský Manhattan, tvrdí architekt.
Manželé Clintonovi loni vydělali 10,6 milionu dolarů.
Trump odmítá zveřejnit své daňové přiznání.
Hillary Clintonová a její manžel, exprezident Bill Clinton v loňském roce vydělali 10,6 milionu dolarů.
Více než milion dolarů věnovali Clintonovi na charitu.
Většina příjmů Clintonových - přes šest milionů dolarů - je za jejich projevy.
Trump své daňové přiznání publikovat odmítá.
Kandidátka amerických demokratů na prezidentský úřad Hillary Clintonová v pátek zveřejnila své daňové výkazy, čímž zvýšila tlak na svého republikánského soupeře Donalda Trumpa, aby učinil totéž.
Hillary Clintonová a její manžel, exprezident Bill Clinton v loňském roce vydělali 10,6 milionu dolarů, oznámila agentura AP.
Většina příjmů Clintonových - přes šest milionů dolarů - je za jejich projevy, a to převážně z období před dubnem 2015, kdy Clintonová zahájila svou kampaň před volbami.
Daňová zpráva ukázala, že manželé Clintonovi odvedli loni federální daň z příjmu ve výši 34,2 procenta a dále pak daň z příjmu na státní a místní úrovni ve výši devět procent.
Celkem tedy zaplatili na daních 43,2 procenta příjmu.
Trump má ale s podobným krokem problém, dosud se ke zveřejnění daňového přiznání neodhodlal.
Je jistá možnost, že Donald Trump neplatí vůbec žádné daně, napsala Clintonová na twitteru pár minut po zveřejnění svého přiznání.
Clintonová se opakovaně vrací k tajnostem kolem Trumpových příjmů, mimo jiné proto, aby vyvolala pochybnosti, zda je její soupeř skutečně tak bohatý, jak tvrdí, uvedla agentura AP.
Trumpovo jmění se odhaduje na miliardy dolarů.
Nižší výdělek by poškodil pověst republikánského kandidáta jako úspěšného podnikatele.
Senátor Tim Kaine, který v tandemu s bývalou první dámou kandiduje na post viceprezidenta, dnes zveřejnil zprávu o svých daňových odvodech za posledních deset let.
Společně se svou manželkou Anne Holtonovou dali 7,5 procenta svých výdělků na charitu a na daních loni odvedli 25,6 procenta výdělku.
V Nigérii znovu propukla obrna.
Islamisté z Boko Haram bránili důslednému očkování a lékaře zabíjeli.
V Nigérii se znovu objevily případy dětské obrny.
Na severovýchodě země tam vláda vyhlásila mimořádné očkování, neboť zde dvě děti nakažené touto nemocí ochrnuly.
Vakcíny tam dopravily vrtulníky.
V zasažené oblasti působili islamističtí teroristé z Boko Haram, kteří očkování bránili a lékaře dokonce zabíjeli.
Podle Světové zdravotnické organizace (WHO) tam virus nepozorovaně koloval.
Na severovýchodě Nigérie začne mimořádné očkování dětí proti obrně, protože tam ochrnuly dvě děti nakažené touto nemocí.
V Africe byla obrna naposledy diagnostikována před dvěma lety v Somálsku.
Nigerijská vláda oznámila, že ve státě Borno bude naočkován milion dětí a další čtyři miliony ve státech okolních.
Nigerijské vojenské vrtulníky v pátek podle agentury AP rychle dopravily vakcíny proti dětské obrně do zasažené severovýchodní části země, kde působí islamističtí teroristé z Boko Haram.
Světová zdravotnická organizace (WHO) uvedla, že virus v oblasti mnoho let nepozorovaně koloval.
Extremisté z Boko Haram v minulosti bránili očkování a lékaře dokonce zabíjeli.
Jejich útoky také ve čtvrtek znemožnily, aby se lékaři dostali do oblastí, kde byly zjištěny děti s obrnou.
Obě postižená batolata přišla s uprchlíky z části Nigérie nově osvobozené od Boko Haram.
Ředitel sekce WHO odpovídající za vymýcení obrny Michel Zaffran stanici BBC řekl, že očkování v Nigérii začne už příští týden.
Ve státě Borno dlouho působila islámská radikální skupina Boko Haram.
Oblast byla mezinárodním organizacím a vládě zpřístupněna až začátkem letošního roku, kdy se podařilo Boko Haram v této části země zásadním způsobem oslabit.
Nigerijský ministr zdravotnictví Isaac Adewole přiznal, že nové případy obrny jsou pro zemi velkým zklamáním, protože Nigérie chtěla příští rok ohlásit, že v ní byla obrna vymýcena.
WHO upozornila, že je možné, že ačkoli se nemoc dva roky neobjevila, přesto se mezi dětmi šířila.
Očkovány nyní budou děti ve věku do pěti let.
V roce 2012 připadala na Nigérii polovina všech případů obrny na světě.
Zatímco v roce 1988 byla obrna ještě ve 125 zemích, nyní přetrvává už jen ve třech oblastech - v Afghánistánu a Pákistánu a na severu Nigérie.
Papež se v Římě setkal s bývalými prostitutkami.
Naslouchal pohnutým příběhům padlých žen.
Papež František se setkal s dvaceti bývalými prostitutkami, které díky policii unikly z gangu pasáků.
Papež si vyslechl jejich těžké životní příběhy a vyzval je, aby s důvěrou hleděly do budoucnosti.
František chtěl tímto setkáním upozornit na obchodování s lidmi a vyzvat k zesílení boje proti němu.
Papež František se v Římě setkal s dvaceti bývalými prostitutkami, které policie osvobodila z moci gangu pasáků.
Hlava katolické církve více než hodinu naslouchala pohnutým příběhům padlých žen a následně je vyzval, aby s důvěrou hleděly do budoucnosti, uvedl mluvčí Vatikánu.
Mezi bývalými prostitutkami, které František navštívil, bylo šest žen z Rumunska, čtyři z Albánie, sedm z Nigérie a po jedné z Tuniska, Itálie a Ukrajiny.
Jejich průměrný věk se pohybuje kolem 30.
Všechny byly podle Vatikánu během nucené prostituce vystaveny krutému fyzickému násilí.
Návštěvou chtěl František upoutat pozornost k obchodování s lidmi a vyzvat k zesílení boje proti němu, uvedl papežův mluvčí.
František často upozorňuje na osudy lidí na okraji společnosti.
Ve čtvrtek například poobědval se syrskými uprchlíky, kteří dorazili do Vatikánu letos v dubnu a v červnu díky jeho osobnímu pozvání.
Francie udeří na výrobny džihádistů.
Bez pomoci muslimů to ale nepůjde.
Francii mají v boji proti radikálnímu islamismu pomoci sami muslimové.
Vláda premiéra Manuela Vallse navíc chystá zásadní změny ve fungování mešit i vzdělávání duchovních.
Od loňského prosince jsme zavřeli 20 mešit a modliteben.
A další budou následovat, oznámil ministr vnitra.
V zemi funguje přes sto výroben džihádistů.
"Pokud muslimové nebudou pomáhat státu v boji proti těm, kteří narušují veřejnou svobodu, bude pro Francii stále těžší zaručit tomuto vyznání svobodu," prohlásil premiér Manuel Valls.
Zajistit hodlá zejména to, aby v mešitách a modlitebnách kázali pouze imámové, kteří se vzdělávali ve Francii.
Současně chce zastavit financování mešit ze zahraničí.
Momentálně přichází z ciziny asi 20 procent peněz na výstavbu nových mešit, nejvíc z Maroka, Alžírska a zemí Perského zálivu.
I kvůli tomu se pak do mešit dostávají kazatelé, kteří mohou ve Francii rozsévat radikalismus.
"Naše země musí ukázat, že islám je s demokracií slučitelný," dodal premiér.
Klíčem, který mu zajistí splnění těchto cílů, bude nová Francouzská islámská nadace.
Ta by měla fungovat jako most mezi sekulárním státem a muslimskou menšinou.
Už žádné peníze z ciziny.
V zemi teď působí Francouzská nadace pro islám, kterou v roce 2005 založil tehdejší premiér Dominique de Villepin.
Už tehdy měla nadace přispět k zprůhlednění finančních toků mezi mešitami a zeměmi, které jejich výstavbu financují.
Jenže instituci brzy zasáhly vnitřní rozpory a rivalita.
"Je to totální neúspěch," konstatoval nedávno Valls.
Na francouzské politické scéně se už po útoku na časopis Charlie Hebdo v lednu 2015 rozhořela debata o nové instituci, která nefunkční nadaci nahradí.
Vše uspíšily další teroristické útoky ve Francii, které ve jménu Islámského státu provedli zradikalizovaní islamisté.
Francouzský ministr vnitra Bernard Cazeneuve se nedávno nechal slyšet, že nová nadace vznikne už letos v říjnu.
Bude mít dva hlavní úkoly - zajistit financování mešit z domácích zdrojů a také dohlížet na imámy.
Prozatím není jasné, kde bude brát peníze nejen na výstavbu nových mešit, ale také různých vzdělávacích center.
Zvažuje se ale několik návrhů.
Jedním z nich je speciální poplatek nebo daň na halal potraviny.
Tu by v praxi platili prodejci halal jídla, a to za poskytnutí certifikace.
Část z těchto peněz by pak putovala právě do kasy nadace.
Příspěvek deset až dvacet eur (270 až 540 korun) by pak mohli platit francouzští poutníci, kteří se vydají do Mekky.
Každý rok jich tam na tradiční pouť do Saúdské Arábie jede asi 30 000.
A nejen to.
Podle premiéra by v mešitách v budoucnu měli působit pouze kazatelé, kteří prošli speciálními vzdělávacími programy na francouzských univerzitách.
To by mělo zajistit, aby kázání bylo v souladu s demokracií.
Radikální mešity zavřeme.
Francouzská vláda je současně v tažení proti radikálům.
A další budou následovat, oznámil nedávno ministr vnitra.
Ve Francii není místo pro ty, kteří v mešitách hlásají nenávist a nerespektují některé principy naší země, jako je rovnost mezi ženami a muži.
V zemi podle odhadů působí asi 2500 mešit a modliteben.
Odhaduje se, že asi 120 z nich je pod vlivem radikálního islamismu.
Od roku 2012 úřady vyhostily zhruba 80 imámu a u několika dalších desítek to zvažují.
Ne všichni si ale myslí, že kroky vlády dokážou výrazně zasáhnout proti radikalismu.
Ti, kteří se chtějí radikalizovat, to udělají stejně.
Nedochází totiž k tomu v mešitách, mladí lidé se radikalizují na internetu, uvedla Severine Labatová, expertka z Národního centra pro vědecký výzkum.
Dráhař Kelemen prohrál v 1. kole sprintu s hvězdou Baugém.
O postup do osmifinále musí český dráhový cyklista zabojovat v opravných jízdách.
Dráhový cyklista Pavel Kelemen na olympijských hrách v Riu de Janeiro po postupu z kvalifikace sprintu mezi nejlepších osmnáct prohrál v 1. kole souboj s francouzským velikánem Grégorym Baugém, obhájcem stříbra z minulých her v Londýně.
O postup do osmifinále musí zabojovat v opravných jízdách.
Na start královské disciplíny na dráze se postavilo 27 jezdců a nejlepší český dráhař současnosti si připsal čtrnáctý nejlepší čas.
Dvoustovku s letmým startem stihl za 9,969 sekundy.
V hlavní vyřazovací fázi ho tak čekal v kvalifikaci pátý Baugé, jenž už má z Ria bronz v týmovém sprintu.
Kelemen sice v závěru dotíral na zkušeného Francouze, ten si však postup pohlídal.
Skvělým výkonem se blýskl obhájce zlata Jason Kenny.
Osmadvacetiletý Brit zajel třetí nejrychlejší dvoustovku historie a kvalifikaci vyhrál v olympijském rekordu 9,551.
Snadno si pak podle očekávání poradil také s posledním postupujícím, jímž byl Němec Maximilian Levy.
Dařilo se i britskému kvartetu v sestavě s Bradleym Wigginsem, jež ve stíhacím závodu na 4 km zajelo nový světový rekord 3:50,570 a postoupilo do finále.
Dosavadní maximum (3:51,659), které Britům patřilo čtyři roky od olympiády v Londýně, vylepšili o více než vteřinu.
Mladí lékaři tlačí: Chtějí čerstvý vítr v oboru
Zástupci mladých lékařů se sešli, aby schválili nové kroky v jejich sporu o novou smlouvu.
Rada mladých lékařů (JDC) při Britské lékařské asociaci (BMA) musí požádat celou radu o podporu dalších oborových akcí ze začátku září.
JDC říká, že ministrům se otázky ohledně smlouvy nepodařilo vyřešit.
Mladí lékaři a studenti medicíny v červenci odhlasovali odmítnutí smlouvy dohodnuté s BMA.
Byla odmítnuta 58 % jejích členů, kteří se volby účastnili.
V dopise členům uveřejněném ve čtvrtek v noci na Twitteru předsedkyně JDC Ellen McCourtová uvedla, že vláda zůstala „i nadále potichu“ k otázkám, což veldo k zamítnutí kontraktu.
Řekla: „V tomto světle orgán výkonné moci JDC hlasováním rozhodl navrhovanou novou smlouvu zcela zamítnout a žádat nová formální jednání ve všech otázkách.“
V odpovědi na mlčení ze strany vlády dnes výkonná rada JDC formálně požádala o zvláštní setkání rady BMA s cílem schválit běžící program vyhrocených oborových akcí ze začátku září.
Spor vedl mladé lékaře letos k vyhlášení do šesti stávek, včetně prvních generálních stávek v historii NHS.
Lídr mladých lékařů v BMA, Dr. Johann Malawana, rezignoval po rozhodnutí o zamítnutí dohodnutých podmínek smlouvy, které BMA doporučila.
Členům BMA na setkáních před hlasováním před 54 000 mladými lékaři a studenty medicíny řekl, že dohoda byla dobrá a měla by být přijata.
Po hlasování ministr zdravotnictví řekl, že smlouva by znamenala pro mediky v Anglii zátěž.
Rusko a Turecko: Spojenectví „neslučitelných“?
Bylo to gesto, které skončilo krizí.
Lídři Ruska a Turecka se sešli v úterý, aby si podali ruce a oznámili formální ukončení osm měsíců dlouhé slovní války a ekonomických sankcí.
Ale zatímco Vladimír Putin přivítal tureckou protistranu v přepychové hale paláce v Petrohradě, měl jsem dojem, že Ankara chce touží po tomto usmíření víc.
Došlo na podání rukou, ano.
Ale Putin se neusmíval a sotva z něj vyzařovala vřelost, a to i podle jeho odměřených standardů.
Recep Tayyip Erdogan naopak opakovaně mluvil o svém „drahém příteli“ panu Putinovi - pětkrát, jak uvádí jedna ze zpráv.
Nepočítal jsem to.
Také slíbil, že vztahy s Ruskem se nejen vrátí na svou úroveň před krizí, ale budou ještě lepší.
Další den jedny z místních novin napsaly, že se Erdogan choval, jako by se nic zlého nikdy nestalo.
Podle mě jeho nadšení prozrazovalo přesný opak.
Ale přetrvávající chlad, který vyzařoval z Putina, ukázal, že ruský lídr nezapomněl nic.
Skutečnou příčinou krize byla první věc, kterou zmínil ve své úvodní řeči: Sestřelení ruského bojového letounu Tureckem na syrských hranicích.
Reakce Moskvy tehdy byla zuřivá.
Putin rozdával rány okolo sebe a Ankaru obvinil z toho, že Moskvě vrazila nůž do zad.
Pohoršení bylo o to větší, že přišlo od domnělého přítele.
Znovu vybudovat skutečnou důvěru bude obtížné, možná dokonce nemožné.
Ruské veřejné mínění se od prosince také změnilo.
Státem kontrolovaná média po měsíce vedla masivní celoplošnou kampaň proti Ankaře.
Najednou to vypadalo, jako by Turci mohli za všechno.
Závažnější byla obvinění od vrcholných státních představitelů o tom, že Erdoganova vlastní rodina měla prospěch z ilegálního obchodu s ropou v částech Sýrie kontrolovaných takzvaným Islámským státem.
Ten toto důrazně popřel.
Ale v Petrohradě přišlo oficiální poselství, že je čas pohnout se dál.
Konec konců, k tomuto setkání došlo pouze proto, že Putinovi se dostalo omluvy, kterou od prezidenta Erdogana žádal.
Rusko mohlo vyhlásit jakés takés vítězství.
Pro Ankaru jsou přínosy vyhlášení příměří jasné.
V první řadě byl Erdogan byl minulý měsíc během nezdařeného puče téměř zbaven moci a proto potřebuje všechny své přátele.
Opakované teroristické útoky v Turecku jím viditelně také otřásly.
Existuje také ekonomický motiv.
Ruské sankce měly tvrdý dopad - především zrušení charterových letů, které každoročně přepraví několik milionů ruských turistů na pobřeží Turecka.
Tento počet se snížil téměř o 90 %.
Pokud jde o Rusko, tour operátoři a charterové společnosti zde si dozajista oddechnou, když případně dojde k obnovení letů.
Vydělávají na středomořském cestovním ruchu v závěru sezóny.
Dokonce i tento týden státní televize slibovala levnější ovoce a zeleninu, až bude znovu dovoz zemědělských komodit z turecka povolen.
„Turisté tam, rajčata zpět sem,“ jak to hlásala zpráva v novinách Vedemosti.
Návštěva ale měla pro Moskvu další politickou hodnotu.
Ankara se na Západ zlobí za to, co považuje za chabou reakci na pokus o převrat.
Kromě toho, dlouhotrvající nevraživost zdlouhavé rozhovory o vstupu do EU a vstup Putina - který dychtí po tom, aby mohl ochlazení využít a přetrhat pouta Turecka se Západem.
Ruský lídr zcela jistě získal bonusové body, když jej Ankara požádala o pomoc zvolených orgánů po pokusu o puč.
Musíte pochopit, že pro Moskvu, která má hluboko zakořeněný strach ze změny režimu, je to dané.
Takže summit v tomto pompézním, přímořském paláci Rusku a Turecku umožnil předvést, co mi jeden z analytiků popsal jako „spojenectví neslučitelných“: jak spojují síly dvě země, které se cítí být odmítnuty a využívány Západem.
Ovšem navzdory tomu, že veřejně ukázaly vzájemné usmíření, jsou mezi těmito dvěma zeměmi zásadní rozdíly.
Prvním je Sýrie, kde se Moskva před nedávnem stavěla do role mírotvorce, ale kde Rusko a Turecko stojí na opačných stranách.
Dalo by se říct, že po téměř tříhodinových úvodních rozhovorech oba prezidenti na tiskové konferenci uvedli, že se o této otázce ani nezmínili.
Turecký prezident se záměrně vyhl odpovědi na otázku ohledně rozdílů mezi nimi, zatímco Putin se rozhodl tyto rozdíly vyzdvihnout.
Neexistuje žádná jasná dohoda, na základě které by oba státy mohly najít společnou řeč v otázce Sýrie.
Ale po měsících otevřeného nepřátelství - a vzhledem k riziku naprosté katastrofy, když člen NATO Turecko sestřelilo ruský bojový letoun - je zajisté lepší, že spolu oba lídři znovu alespoň mluví.
Royal Bank of Scotland zmizí pro zákazníky mimo Skotska
Podle výkonného ředitele banky má být značka RBS potlačena do role back office.
Royal Bank of Scotland se ztratí pro zákazníky mimo Skotska.
Ross McEwan řekl stanici BBC Scotland, že značka RBS byla spojena s globálními ambicemi banky.
Z nich polevila, když před osmi lety téměř zanikla a musela být vykoupena z dluhu.
V té době strategové značky používali „RBS“ s cílem chránit ostatní značky spotřebitelských financí.
Stály za ní miliony liber vydaných na sponzoring mezinárodního sportu, od ragbyového šampionátu Six Nations po šampióna Winbledomu Andyho Marraye.
Nyní ale bylo rozhodnuto, že je lepší dát více vyniknout spíš národním značkám.
Royal Bank of Scotland se bude používat u skotských zákazníků, ale nebude spouštět nové obchody.
Všechny reference na RBS v Anglii a Walesu, s výjimkou centrály a kódování akcií na burze, budou změněny na NatWest.
Pro zákazníky v Irské republice a v Severním Irsku se již používá značka Ulster Bank.
Existují zde jiné, menší značky pro privátní bankovnictví, které se dostanou více do popředí - Coutts, Adam & Co, Drummond, a Holt's Military Bank.
Během cest k zákazníkům a zaměstnanců v Inverness-shire nám McEwan odpovídal na otázky Ross McEwan.
Stanici BBC Skotsko řekl: „Značka RBS přestane být naší investorskou značkou a značkou, pro kterou naši zaměstnanci pracují, protože se nyní mnohem víc stáváme bankou značek.“
Protože se banka sama stala globální značkou, stalo se globální značkou i RBS.
Nyní říkám, že již globální aspirace nemáme, máme snahy zaměřené na domácí scénu.
Každá z těchto značek bude ve svých vlastních komunitách znamenat něco zcela odlišného a naši pracovníci budou pracovat pod těmito značkami.
RBS již uvedla, že nebude pokračovat ve svém sponzoringu šampionátu Six Nations, připravila profil jednotlivých značek sponzoringu sportu.
„Nastala pro nás vhodná doba, abychom se posunuli k bance značek, protože základní otázkou (kterou si klademe) je, jakým způsobem se zaměřit na to, abychom se stali lepší bankou pro zákazníky?“ uvedl výkonný ředitel.
Před třemi lety by bylo velmi cynické, kdybychom řekli, že se staneme skvělou bankou pro zákazníky a ty značky představili.
Ale spolu s tím, jak jsme se zaměřovali na potřeby zákazníků, a ne na naše vlastní, si myslím, že dochází ke spoustě změn.
Můžeme tyto značky znouvu připomenout, myslím, že nadešel ten správný čas.
Frankie Dettori v Newmarketu na koni Predilection dovedl do cíle 3000. vítěze
Dettori rozstřikuje šampaňské poté, co mu dvojité vítězství v Newmarketu přineslo 3000 vítězství
Žokej Frankie Dettori si v pátek zajistil 3000. vítězství v Británii v Newmarketu.
Tohoto milníku dosáhl svým druhým vítězstvím večera na své lokální trati - na koni Predilection, kterého trénuje John Gosden.
Pětačtyřicetiletý Ital je šestým žokejem, který takového výsledku dosáhl v rovinových dostizích.
Jeho předchůdci jsou Sir Gordon Richards, Doug Smith, Lester Piggott, Pat Eddery a Willie Carson.
Trojnásobný šampión žekje Dettori, který dříve vyhrál na koni Ghayyar, řekl: „Je to zvláštní.“
Jsem velmi dojatý, protože je zde také moje rodina
Jsem nesmírně rád, že k tomu došlo v Newmarketu, protože právě zde jsem před 30 lety zakotvil.
Není to ohromná akce, není to Royal Ascot - je to páteční noc na zemi se 20 000 lidmi.
Ulevilo se mi a jsem velmi vděčný.
Dettori sbírá gratulace, když po vítězství přivádí Predilection
Dva žokejové tohoto milníku dosáhli v překážkových dostizích - šampion žokej Richard Johnson a 20násobný šampion na penzi Sir Anthony McCoy, které během své kariéry lámající rekordy dovedl do cíle více než 4 300 vítězů.
Lester Piggott, devítinásobný vítěz Derby, 4 493 vítězů v kariéře
Frankie je jedním z nejlepších žokejů moderní doby a není překvapením, že dosáhl milníku, kterého před ním dosáhlo pouze několik jezdců.
Je stylový a silný, ale je to právě jeho taktický fištrón, který ho od ostatních jezdců ve vážnici odlišuje.
Je fantastickým ambasadorem dostihů, jeho nadšení a charisma přitahovaly fanoušky k tomuhle sportu dlouhé roky.
Před několika týdny jsem Frankiemu v Epsomu řekl, že kdyby nejezdil pouze o víkendech a velké dostihy, tak by měl již 6 000 vítězů!
Ovšem pravdou je, že Frankie jezdil vítěze ve Velké Británii po větší část své 30leté kariéry, a to je opravdu něco.
Má živou povahu, což je pro britský dostihový sport dobré. Ale důležitější je, že je neuvěřitelným žokejem.
Frankie Dettori svůj úspěch oslavil svých pověstným letmým seskokem
Od letmých finišů po letmé seskoky - Frankie Dettori byl poslíčkem britských rovinných dostihů dvě dekády.
Bylo to jako jízda na horské dráze.
Nepřeberná množství vítězů velkých závodů, včetně jeho známé „velkolepé sedmy“ v Ascotu. Přežil ale také havárii letadla a měl zákaz startu kvůli drogám.
Před třemi lety poprvé stagnoval, když se vracel po 6měsíčním zákazu startu, ale prokázal neuvěřitelnou vnitřní sílu a všem pochybovačům navzdory se vrátil v nejlepší formě.
A možná to nebude naposledy - Dettori již dříve prohlásil, že by rád pokračoval v závodění alespoň až do 50 let.
Ruský prezident Putin propustil šéfa prezidentské kanceláře Sergeje Ivanova
Ruský prezident Vladimir Putin v pátek nečekaně propustil Sergeje Ivanova z postu šéfa prezidentské kanceláře.
Ivanov byl jedním z nejbližších Putinových spolupracovníků po mnoho let.
Třiašedesátiletý Ivanov byl jmenován zvláštním zástupcem pro ekologii a dopravu.
V prohlášení z Kremlu se uvádí, že Putin „uvolnil Ivanova z jeho služeb hlavy ruské prezidentské kanceláře,“ ale nebyl uveden důvod.
Jeho místo převezme Anton Vajno, který byl Ivanovovým zástupcem od roku 2012.
Čtyřiačtyřicetiletý Vajno byl dříve diplomatem.
Narodil se v hlavním městě Estonska Tallinnu v roce 1972, promoval na prestižním Státním institutu mezinárodních vztahů v Moskvě (MGIMO) a pracoval na ambasádě v Tokiju.
Na webových stránkách (v ruštině) se uvádí, že později dělal šéfa prezidentského protokolu a prezidentské kanceláře.
Při jmenování Putinovi řekl:„Děkuji Vám za Vaši důvěru.“
Domnívám se, že nejdůležitější úlohou administrativy je podporovat Vaše aktivity hlavy státu ve smyslu návrhu zákonů a kontroly toho, do jaké míry jsou dodržovány Vaše pokyny.
Putin v pátek ruské televizní stanici uvedl, že Ivanov jej požádal o uvolnění z postu a doporučil, aby jej nahradil právě Vajno.
Přesvědčí úsměvy?
Tenhle krok zcela mystifikoval Moskvu.
Sergej Ivanov byl podlouhou dobu jedním z nejbližších spolupracovníků Vladimira Putina a stejně jako Putin pracoval pro KGB.
Jako šéf prezidentské kanceláře byl jedním z nejmocnějších mužů v zemi.
Na setkání s prezidentem Putinem, které odvysílala státní televize, oba muži prohlásili, že z postu šéfa prezidentské kanceláře odchází na vlastní žádost.
Ale úsměvy do kamer přesvědčily jen několik málo lidí - především nyní, těsně před parlamentními volbami.
Jedná se tedy o důsledek nějakého boje o moc?
To zatím nikdo neví.
Ale oficiální tvrzení, že muž, o kterém se kdysi uvažovalo jako o možném prezidentovi, touží najednou vést ekologickou politiku Ruska, se setkalo s velkou nedůvěrou.
Na stránkách Kremlu jsou citovány poznámky určené Putinovi, ve kterých Ivanov uvádí: „Je pravdou, že v roce 2012 jsem Vás v rozhovoru požádal, abyste mi tento velmi náročný post, dokonce by se dalo říct problematický post, svěřil na čtyři roky.
Jak se zdá, byl jsem šéfem prezidentské kanceláře čtyři roky a osm měsíců.
Ivanov se postu ujal v prosinci 2011.
Předtím zastával funkci místopředsedy vlády a ministra obrany.
Je členem Ruské bezpečnostní rady a dříve, podobně jako Putin, pracoval pro výbor státní bezpečnosti (KGB).
Na konci 90. let, když Putin velel Federální službě bezpečnosti Ruské federace (FSB), která nahradila KGB, byl Ivanov jmenován jeho zástupcem.
Když Putin nastoupil k moci, jmenoval Ivanova jedním ze svých pěti nejbližších spolupracovníků.
Svého času se dokonce spekulovalo o tom, že by se Ivanov mohl stát nástupcem Putina v čele státu po jeho druhém volebním období, protože třetí období by pro Putina bylo protiústavní.
Tento post ale převzal jiný blízký Putinův spolupracovník Dmitrij Medveděv.
Putin se před návratem do prezidentského úřadu o pouhé tři a půl roku později stal premiérem.
Thomas Gibson, hvězda seriálu Myšlenky zločince, byl propuštěn po té, co uhodil režiséra
Gibson se minulý měsíc V Los Angeles zapletl do fyzické výměny názorů na scéně.
Televizní stanice ABC a CBS, které seriál produkují, ve společném prohlášení jeho propuštění oznámily.
Gibson, který hrál zvláštního agenta Aarona Hotchnera, se ve čtvrtek před oznámením jeho vyhazovu omluvil.
Došlo ke vzniku kreativních rozdílů na scéně a k neshodám.
Je mi líto, že k tomu došlo,“ řekl v prohlášení.
Podle prohlášení televizních stanic ABC a CBS jsou podrobnosti o tom, jakým způsobem postava Gibsona zmizí ze seriálu, který sleduje příběhy týmu agentů FBI, o něco později.
Čtyřiapadesátiletý herec, kterého proslavila hlavní role v sitcomu Dharma a Greg, v seriálu účinkoval od první série v roce 2005.
„Miluji Myšlenky zločince a během posledních dvanácti let jsem do nich dával srdce i duši,“ uvedl Gibson ve svém prohlášení, které vydal v pátek.
Doufal jsem, že v něm budu až do konce. To ale teď nebude možné.
Chtěl bych ještě vyjádřit svůj dík autorům, producentům, hercům, našemu úžasnému týmu a především skvělým fanouškům, v jaké kdy tahle show mohla doufat.
Návrat seriálu do dvanácté série se očekává 28. září.
Ve městě Banff záhadně přistály v zahradě ryby
Muž z městečka Banff požádal o pomoc při identifikaci ryb, které se objevily v jeho zahradě.
Kevin Bain se domnívá, že 75 kusů ryb mohou být píseční úhoři, které tam zanechala vodní smršť.
Bain, který žije asi 500 metrů od moře, na kanálu Periscope uveřejnil krátký film svého nálezu v domnění, že by mu někdo mohl pomoci objasnit, jak se asi 5centimetrové rybky na jeho zahradu dostaly.
Queensferry Crossing: Most nyní spojuje s Fife
Projekt za 1,35 mld. liber má být dokončen do května 2017
Inženýři propojili severní plošinu a Queensferry Crossing a viadukt - most tedy nyní spojuje s Fife.
Jde tedy o první ze čtyř uzávěr mezi „vějíři plošin“, které jsou nyní téměř dokončené okolo každého ze tří pylonů mostu.
Část mostu od Fife je nyní dlouhá 600 metrů a váží 30 000 tun.
Je v ní 10 000 tun železa a 20 000 tun betonu a 46 závěsných lan.
Projekt za 1,35 mld. liber má být dokončen do května 2017.
Ekonomický tajemník Keith Brown stavbu dnes navštívil a byl mezi prvními, kteří přišli z pevniny na most.
Řekl: „Toto je historický okamžik a symbolický okamžik budování Queensferry Crossing.
Na tomto projektu jsme všichni svědky toho, jak stavební inženýři v skutku impozantním měřítku použili více než 30 000 tun betonu a oceli ke konstrukci této části mostu.
Navzdory masivním rozměrům a hmotnosti mostu bylo dokončení uzávěry mezi viaduktem a plošinou mostu delikátní operací, která vyžadovala mimořádnou přesnost.
Na svém místě je nyní celkem více než 79 % celkové plochy mostu, beton pro poslední části plošiny se nyní odlévá v Rosythu, takže celá plošina je připravena k vyzdvihnutí na most.
Michael Martin, vedoucí projektu Forth Crossing Bridge Constructors, řekl: „První uzávěra při stavbě každého mostu je vždy důležitým milníkem.
Na tomto úžasném projektu tato uzávěra představuje špičku pozemního stavitelství.
Po instalaci poslední části silniční plošiny a jejím připojení k rozšiřující plošině North Tower jsme pak museli uzavřít poslední mezeru na severní straně - směrem na pevninu.
Toto jsme udělali protažením severního přibližovacího viaduktu 700 milimetrů jižním směrem.
Toto byla masivní a současně velice delikátní operace.
Masivní proto, že viadukt je dlouhý 222 metrů, váží asi 6 000 tun a bylo nutné jej táhnout se stoupáním asi 3 %.
Delikátní proto, že tolerance, se kterými tým pracoval, byly velmi malé - pouze několik milimetrů každým směrem.
Všechno šlo naštěstí velmi dobře.
Záchrana v Moelfre Bay: Tři muži jsou „šťastní, že jsou naživu“
Tři muži jsou „šťastní, že jsou naživu“ poté, co je spláchla voda z jejich rybářské lodi u Anglesey.
Stanice záchranných člunů Moelfre RNLI vyhlásila poplach v pátek ve 13:20 britského letního času poté, co posádka incident v zátoce Moelfre viděla.
Všichni tři muži se snažili doplavat do bezpečí, zatímco jejich člun pokračoval neřízeně dál.
„Viděli jsme, jak jejich člun krouží v jejich blízkosti a napadlo nás to nejhorší,“ řekl kormidelník záchranného člunu Moelfre Vince Jones.
„Silný vítr jej naštěstí odvál pryč od nich ještě než jsme vyjeli,“ dodal.
Dva muže zachránila místní rybářská loď, třetí muž ve věku 60 let byl nalezen bez záchranné vesty vyčerpaný, jak se drží bójky.
Všichni byli předáni na palubu pobřežního záchranného člunu a převezemi zpět na stanici záchranných člunů
Jones řekl: „Tři muži svržení do vody jsou šťastní, že jsou naživu a zcela bez zranění.
Motor lodi měl lano pro nouzové vypnutí, ale nějak došlo k jeho odpojení od osoby, která člun řídila, když došlo k převrácení.
Někdo shora nad těmi hochy držel ochrannou ruku.
Soudkyně odmítá řešit případ kvůli Tluchořově ženě.
Petr Tluchoř je jedním ze tří poslanců, kteří měli podle obžaloby dostat od premiéra Nečase a jeho tehdejší šéfky kabinetu Jany Nagyové politickou trafiku, tedy lukrativní post za politický ústupek.
V roce 2012 šlo o schválení daňového balíčku.
Šnajdr, Fuksa a Tluchoř ho umožnili svými rezignacemi.
Pak se objevili na vlivných postech ve státních firmách.
I proto čelili také podezření z úplatku a skončili na měsíc ve vazbě.
Podle soudu ale neoprávněně, a dočkali se tak odškodnění celkem téměř 2 milionů korun.
Tluchoř nyní v kauze vystupuje jako svědek, a to po zásahu Nejvyššího soudu.
Jeho manželka pracuje v soudní budově na Ovocném trhu a řeší civilní spory.
Přesto chce být soudkyně Helena Králová opatrná (řeší trestněprávní záležitosti - pozn. red.) a předejít možným námitkám.
Případ tak zřejmě dostane na starost jiný pražský soudní obvod.
Králová přitom už dvakrát zprostila viny Janu Nečasovou, dříve Nagyovou.
Šlo o údajné zneužití vojenské rozvědky ke sledování první manželky premiéra Nečase Radky.
V tomto případu Tluchoř nefiguroval.
Podle právníka Jaroslava Ortmana jde ale o zbytečně přehnanou reakci.
Myslím si, že nestrannost nemůže být takto vykládána, aby se soud vylučoval, jestliže svědkové mají manželku nebo příbuzné na soudu.
Obávám se, že by se pak nedalo soudit vůbec nic, poznamenal pro deník.
"Připadá mi to ulítlé," dodal.
V případu politických trafik je obviněn také Roman Boček, bývalý úředník.
Podle jeho advokáta Petra Tomana by ale případná námitka měla šanci na úspěch.
Obvodní soud pro Prahu 1 projednával 13. června obžalobu někdejší šéfky kabinetu premiéra Petra Nečase Jany Nagyové (dnes Nečasové) a dalších obviněných v kauze zneužití Vojenského zpravodajství.
Na snímku přichází Nečasová s manželem k soudu.
Tluchořová měla řešit výroky o Peroutkovi.
Manželka exposlance měla například soudit výroky prezidenta Miloše Zemana o demokratickém předválečném novináři Ferdinandu Peroutkovi.
Zeman o něm prohlásil, že sympatizoval s Adolfem Hitlerem.
Jedna ze školaček už je mrtvá!
Dívka zřejmě zahynula při leteckém náletu spojeneckých sil.
Do Sýrie spolu se svými dvěma stejně starými přítelkyněmi odletěla loni v únoru z londýnského letiště Gatwick.
Britské ministerstvo vnitra zprávu o její smrti nekomentovalo.
Mladé Londýňanky, které utekly z domova, byly podle policie tajně převezeny do Sýrie přes tureckou hranici.
Shamima Begumová, Amira Abaseová a Kadiza Sultanaová zamířily podle médií za svou další bývalou spolužačkou z londýnské školy Bethnal Green Academy.
Případ loni vyvolal obrovskou vlnu pozornosti a také napětí ve vztazích mezi Británií a Tureckem.
Britské bezpečnostní složky odhadují, že do Sýrie dosud odcestovalo asi 600 britských muslimů, z toho asi 50 mladých žen a dívek.
Řada z nich se připojila k radikálům z IS a dalších skupin.
Ti, kteří se vrátí domů, představují pro Británii teroristickou hrozbu.
Práce snů za stotisícový plat.
Skvěle placená práce, ke které ani nepotřebujete vysokou školu.
Tak vypadá na první pohled práce ajťáka.
A často i na ten druhý.
Výhodou totiž není jen na české poměry extrémně vysoký plat (v Praze si prací v IT vyděláte až 180 000 Kč), ale i extrémní výhody.
Důvodem je obrovský nedostatek IT specialistů.
Chybí tisíce specialistů.
Podle odhadů chybí v Česku téměř 20 000 IT specialistů.
Mezi nejhledanější patří podle statistik personální agentury Grafton programátoři, vývojáři, network inženýři a aplikační specialisté.
Kandidáti si mohou vybírat mezi několika nabídkami práce.
Nesoupeří tedy kandidáti o pracovní pozici, ale pracovní pozice o kandidáty, komentuje Jitka Součková, marketingová manažerka Grafton Recruitment.
Vysoká škola není nutností.
Vysokoškolské vzdělání přitom není pro ajťáky nutností.
Vysokoškolské vzdělání znamená dobrý základ a je celkovým ukazatelem inteligence a vzdělatelnosti kandidáta, ale nemá často moc společného se znalostí vývoje.
Vývojáři se musejí neustále učit nové věci, což jednou vystudovaná vysoká škola nenahradí, říká Petr Kubačka, ředitel Monster Career CZ.
Nejvíc se vydělá v Praze.
Mzdy ajťáků se všude pohybují vysoko nad republikovým průměrem.
Na nejvíce peněz si přijdou v Praze a Brně, v regionech to už taková hitparáda není.
"Mzdové podmínky v Brně jsou srovnatelné s těmi pražskými," potvrzuje Kubačka.
Na nejvyšší výdělek dosáhnou techničtí ředitelé.
V Praze a Brně si mohou přijít na 120 000 - 180 000 Kč.
V ostatních regionech je plat nižší, ale ani tam neklesne pod 80 000 Kč.
Poptávaní jsou také IT projektoví manažeři.
Při nástupu si mohou vydělat 60 000 - 100 000 Kč.
Boj je i o absolventy.
Zatímco v některých profesích musí absolventi často rovnou vyrazit na úřad práce, u ajťáků to neplatí.
Pokud se totiž firmám přetáhnout a přeplatit odborníka z jiné společnosti, rádi sáhnou po absolventovi.
Můžou si ho totiž vychovat podle svého.
Bez jazyka se neobejdou.
Znalost cizího jazyka se hodí v každé profesí, u ajťáků je ale nezbytná minimálně slušná angličtina.
Znalost alespoň jednoho cizího jazyka je u některých IT pozic nutností.
Na druhou stranu se setkáváme s množstvím případů, kdy firmy hledají zejména odborně vzdělaného a zkušeného člověka a spokojí se pouze s průměrnou znalostí angličtiny.
Pokud však například pracovník podpory ovládá více cizích řečí, je pro svého zaměstnavatele zajímavý, protože dokáže obsloužit více zákazníků z různých zemí, dodává ředitel Kubačka.
Jóóó v Googlu, tam je ráj.
Jen tiše závidět můžou čeští pracanti zaměstnancům v Googlu.
Samozřejmostí je pro ně pružná pracovní doba, možnost práce z domova či různé zkrácené úvazky, nejen pro maminky.
"Novopečeným tatínkům poskytuje společnost čtyři týdny dovolené navíc po narození dítěte," říká Martina Joneková, mluvčí Google.
Hýčkání obnáší i zdravotní péči pro zaměstnance a rodinu, stravování, dopravu, školení, wellness či masáže přímo na pracovišti.
Kdo se chce vzdělávat, má zelenou a nezáleží na tom, co nového se chce učit.
Tím ale výhody nekončí.
Taková plná lednička zdarma také rozhodně není k zahození.
Zdravý oběd (v některých lokalitách i snídaně a večeře) je k dispozici na místě každý den.
Navíc jsou ve všech kancelářích takzvané mikrokuchyňky, kde lidé vždy najdou zdravou svačinu, prozrazuje mluvčí.
A aby se nic nemuselo vyhodit, tak co se nesní, dá do krabiček, které si zaměstnanci mohou vzít večer domů.
A důvod těchto na české poměry neuvěřitelných výhod?
Vytvořit kreativní a motivující prostředí!
"Pro Google totiž není důležité, aby zaměstnanci seděli v kanceláři osm hodin denně, ale výsledky iniciativ nebo projektů, posun či vývoj, nápady a inovativní řešení," dodává mluvčí.
OSN ostře zkritizovala Bulharsko za kriminalizaci uprchlíků.
Zeid Ra'ad al-Hussein, komisař OSN pro lidská práva, obvinil ve čtvrtek Bulharsko, že systematicky porušuje lidská práva kriminalizací uprchlíků.
Oficiální strategie bulharské vlády "vyvolává vážné znepokojení ohledně toho, že Bulharsko nedodržuje mezinárodní právo", varoval Zeid Ra'ad al-Hussein v prohlášení.
Upozornil, že "je zvlášť znepokojující být svědkem toho, jak důležité a vlivné veřejné osobnosti vyjadřují veřejně podporu pro kriminální ozbrojené bojůvky, které drze pořádají hony na uprchlíky na hranici mezi Bulharskem a Tureckem".
"Jedním z nejvážnějších problémů je, že téměř všichni lidí, kteří přejdou na bulharské území nepravidelným způsobem jsou automaticky zatýkáni," zdůraznil Zeid.
A co je ještě horší - často jsou trestně stíháni a vězněni - na rok či déle - pokud se pokusí ze země odejít.
Jejich pokusy odejít ze země jsou kriminalizovány navzdory tomu, že každý má podle mezinárodního práva právo odejít z jakékoliv země, včetně své vlastní.
Bulharsko letos zadrželo 14 000 migrantů, loni za totéž období 21 000.
Pokémon Go - honba za zdravím a štěstím, která se vyplatí
Je fascinující sledovat, jak se svět mění.
Řada lidí během posledního desetiletí lamentuje, že teenageři a děti si již nehrají venku a dávají přednost trávení volného času před obrazovkami.
Pokémon Go zvedá lidi z pohovek a vede je k aktivitě.
Čas strávený před obrazovkami se původně smrskl na televizi, později na video hry a nejnověji na chytré telefony.
Je skvělé sledovat, že technologie a aktivity venku se nevzájem nevylučují.
Mluvím samozřejmě o módě, kterou je Pokémon Go, aplikace založená na postavičkách, které se poprvé objevily ve video hrách na konci 90. let (později vznikl kreslený seriál, hrací karty a další).
Stejně jako u mnoha kulturních fenoménů, i zde došlo před uvedením této nové hry na začátku července v USA, Austrálii a na Novém Zélandu k poklesu zájmu.
Uvedení v dalších zemích pak bylo odloženo kvůli mohutnému zájmu, který vedl k přetížení serverů.
Pokémon Go získal během několika dnů víc uživatelů než Tinder a téměř tolik uživatelů, jako má Twitter.
Jak to funguje?
V krátkosti, hráči na chytrém telefonu jdou ven hledat Pokémony, které sledují pomocí GPS, a když je najdou, mohou je „vyfotit“ (přes screenshot na telefonu) nebo „chytit“.
Mánie zachvátila generaci, která v mladším věku hru hrála, zvedá ji ze sedaček a žene ven hledat Pokémony.
V USA díky této hře došlo k výraznému nárůstu počtu kroků, které „průměrný“ člověk každý den udělá.
Aplikace Cardiogram pro chytré hodinky od Applu, která sleduje 35 000 uživatelů, nedávno pro Washington Post sdělila, že během dvou dnů od spuštění hry se počet sledovaných lidí, kteří každý den cvičili po dobu 30 minut, poskočil ze 45 na 53 procent.
Společnost nemá informace o tom, kdo Pokémon Go hraje - vidí pouze hrubá data o úrovních cvičení.
Mnoho veřejných kampaní usilujících o to, aby lidé „našli 30“, „zvedli se z gauče“ a „byli aktivní každý den“ padlo na neúrodnou půdu, protože většina poselství zaměřených na veřejné zdraví je nudná a určená lidem, kteří nevypadají dobře.
Přesto důležitost cvičení nesmí být podceňována.
Ti, kdo cvičí pravidelně, snižují riziko onemocnění rakovinou nebo depresemi.
Fyzická aktivita se podílí na kontrole hmotnosti, vysokého krevního tlaku, cukrovky a dlouhém seznamu přínosů, který zde nemůžeme celý uvádět.
Ale krása hry Pokémon Go spočívá v tom, že lidé chodí ven a dělají něco, co je baví.
Pokrýváte tak tři pilíře zdraví - pohyb, čerstvý vzduch a sluneční paprsky. A zábavu.
Někteří lidé si dokonce při honbě za pokémony získají nové přátele.
Jak už tomu bývá, najdou se samozřejmě i tací nudní patroni, kteří hledají jakoukoliv záminku k tomu, aby si mohli stěžovat.
A ano, někdo může vejít do dveří.
A co, jako?
Nastal průlom.
Ve své době aplikace pro chytré telefony, jako třeba Fitbit, uměly sledovat naší aktivitu, ale nedávaly nám důvod k tomu, abychom něco dělali, jako je tomu u téhle hry.
Novinka se okouká a zájem o ni začne v určitém okamžiku opadat.
Ovšem díky úspěchu Pokémonů se objeví další hry, které budou kombinovat aplikace a virtuální realitu s aktivitou ve skutečném světě a pomohou řadě lidí při honbě za aktivitou, zdravím a lepší formou.
Přečtěte si blog doktora Joea na www.drjoetoday.com
Simone Bilesová získala zlato ve víceboji gymnastiky žen
Zapomeň na tlak.
Zapomeň na vzrušení.
Simone Bilesová je vůči tomu všemu imunní.
Dynamická na přeskoku.
Bez námahy na kladině.
Při prostných všichni oněměli.
Vynikající ve všem.
A nyní konečně olympijskou šampionkou.
Devatenáctiletá americká gymnastka šla ve čtvrtek přímou cestou za titulem ve víceboji a ostatní na plné čáře pod olympijskými reflektory překonala.
Celkový výsledek 62,198 jasně potvrdil její náskok před stříbrnou medailistkou a členkou týmu „finálové pětky“ Aly Raismanovou a ruskou bronzovou medailistkou Aliyou Mustafinovou.
Simone Bilesová (USA) ve čtvrtek během vystoupení na kladině ve finále víceboje jednotlivců ve sportovní gymnastice na letních olympijských hrách 2016 v brazilském Riu de Janeiru.
Bilesová se stala čtvrtou Američankou v řadě, která vyhrála víceboj, a pátou celkově, když potvrdila svou pověst nejlepší gymnastky své generace a možná i nejlepší vůbec.
Když bylo její celkové finálové hodnocení na tabuli a její dlouhá cesta až do tohoto okamžiku skončila, objevily se jí na tváři slzy.
Tento úspěch ji řadí do stejné ligy ojedinělých atletů své doby, jako je Michael Phelps, kteří svému sportu dodali nový rozměr:
Bilesová svému sportu poslední tři roky dominuje, vyhrála 15 medailí na světových šampionátech - včetně 10 zlatých. Její úchvatné sestavy jsou směsicí ambicí a přesnosti a olympijská šampionka z roku 1984 Mary Lou Rettonová ji označila za „nejlepší gymnastku, jakou kdy viděla.“
Poslední zkouška ji čekala v Brazílii, ani ne tak mezi Bilesovou a zbytkem závodnic, ale mezi ní samotnou a břemenem příliš velkých očekávání.
Cokoliv jiného, než návrat domů ke své rodině ve Spring v Texasu s rukou plnou zlatých medailí, by bylo vnímáno jako zklamání.
Simone Bilesová (USA), vlevo, a Aly Raismanová se objímají po vítězství zlaté a stříbrné medaile ve finále ženského víceboje jednotlivkyň na letních olympijských hrách 2016 v brazilském Riu de Janeiru ve čtvrtek.
První Bilesová získala úterý, kdy byla jako vykřičník v oslavě odcházející národní týmové koordinátorky Marthy Karolyiové.
Bilesová trvá na tom, že se během své dlouhé cesty na vrchol nikdy nedívala kupředu, což ale není tak úplně pravda.
Část její sestavy v prostných - ta, která obsahuje pro ni typické trojité salto s dvojitým obratem - je zasazena do latinské hudby, která by se právě hodila domů, do ulic mimo olympijskou arény v Riu.
To není náhoda.
Dívku adoptovali její prarodiče jako batole a její talent objevila matka trenérky Aimee Boormanové cestou do tělocvičny, kde Boormanová trénovala a kde získal na síle.
Soutěž ve víceboji neprohrála od léta 2013 - to je sled vítězství, který může pokračovat tak dlouho, jak Bilesová bude chtít.
I když Mustafinová převzala na krátko vedení díky dvěma otočkám, byla to jenom iluze.
Kladina a prostné - kde Bilesová obhajuje světový šampionát - čekají.
Dostala se zpět do čela s 15,433 body za kladinu - a završila s 15,933 body v prostných.
Raismanová ji jemně objala, když čekaly na finálové skóre - pouhou formalitu - a okolo třpytivě červených, bílých a modrých stínů se Bilesové objevily slzy, když se splnilo přání, které si kdysi jako malá zapsala do deníčku.
Výkon Raismanové byl tak trochu odplatou za olympiádu před čtyřmi roky, kdy se dělila o třetí příčku s Mustafinovou, tehdy jí ale bronz kvůli součtu tří nejlepších sestav.
Tentokrát dvaadvacetiletá kapitánka týmu, které Američané říkají „babča“, byla o dost vpředu.
Po svých prostných posílala davu vzdušné polibky, zdolána návratem, který se občas zdál nejistý.
Pro Bilesovou má příspěvek, který tahle devatenáctiletá atletka tento týden umístila na Twitter, kde se stal naprostým hitem, zcela nový význam:
Policie: Tři oběti v případu sériového vraha zastřeleny při poslechu hudby v autě
Podle policejní zprávy uveřejněné ve čtvrtek zemřely dvě ženy a dívka ve věku 12 let během nejvažnějšího útoku desetiletí, v případu prvního sériového vraha ve Phoenixu. Byly zastřeleny, když seděly v autě, povídaly si a poslouchaly hudbu.
Úřady oznámily, že Angela Rochelle Linerová, Stefanie R. Ellisová a dcera Ellisové Maleah byly zastřeleny 12. června v autě zaparkovaném na příjezdové cestě.
Ve zprávě se uvádí, že ozbrojený muž stál na straně spolujezdce a z ruční zbraně vypálil osm ran. Poté uprchl v jiném vozidle.
Podle policie nestojí za trojnásobnou vraždou loupež, protože útočník nevzal peněženky, ani částku 2 900 dolarů, kterou u sebe měla jedna z dospělých obětí.
Mluvčí policie ve Phoenixu, seržant Jonathan Howard řekl, že vyšetřovatelé zjišťují, zda střelba neměla nějakou spojitost s některým z předchozích čtyř útoků.
Ve dvou převážně hispánských čtvrtích došlo během čtyř měsíců celkem k devíti útokům, při kterých bylo zabito sedm lidí a dvě další osoby byly zraněny.
„Děje se to ve vilové čtvrti před domy“, uvedl Howard dříve tento měsíc pro pobočku KPHO stanice CBS.
Policie se domnívá, že podezřelý používal několik aut, včetně hnědého Nissanu z konce 90. let, černého BMW z konce 90. let a bílého Cadillacu nebo Lincolnu.
Vyšetřovatelé odmítli prozradit, jaké důkazy je vedly k závěru, že útoky spolu souvisejí a byly provedeny stejným vrahem.
Ellisová (33) byla převezena do nemocnice, kde později svým zraněním podlehla.
Linerová (31) a dcera Ellisové Maleah zemřely na místě.
Svědek policii sdělil, že nebylo neobvyklé, že ženy sedávaly v zaparkovaném autě a poslouchaly hudbu.
Úřady také uveřejnily policejní zprávu o střelbě, jejímž terčem se stala prázdná dodávka pouhou půl hodinu před trojnásobnou vraždou. Policie se domnívá, že jejím původcem byl tento sériový vrah.
Vyšetřovatelé nalezli nábojnice a ze zbytků kulek v sedadle a z pod kapoty motoru sestavili kulku.
Matka šestiletého dítěte s mikrocefalií: „Jeho stav se zlepšuje“
Edmund Picciuto, stejně jako většina dětí jeho věku, miluje zpěv, hračky a samozřejmě také svou maminku.
Ale na rozdíl od svých vrstevníků trpí mikrocefalií, která je důsledkem genetické poruchy, o které jeho matka, Elizabeth Picciutová, během těhotenství nevěděla.
Když poprvé přišel domů, jako první mě napadlo, že tohle nezvládnu.
Tohle nezvládnu.
Na tohle nejsem připravená.
Což vůbec není pravda - jasně, že na to připravení jste,“ řekla.
Ona a její manžel Vincent se dozvěděli, že Edmund je možná nikdy nepozná a že možná ani nepřežije.
Někteří lékaři dokonce navrhovali, aby byl umístěn do ústavu.
„Moje první reakce byla, že jsem si myslela, že tohle už dneska lidé nedělají“, vysvětluje Picciutová.
Edmund chodí s pomocí chodítka.
Až do věku tří let neuměl sedět, ani se plazit. A stále ještě nemluví.
Některé mezníky již ale pomalu naplňuje.
Chodí s dopomocí a jezdí na kole.
Také si moc rád hraje se svými dvěma bratry a miluje zpěv.
Elizabeth předvádí znakovou řeč, pomocí které Edmund říká „prosím, zpívej mi“.
„Učíme ho znakovou řeč“, řekla Picciutová pro CBS News.
Ale není to běžná znaková řeč - říká, že si Edmund některé znaky vymyslel sám.
Mikrocefalie může vzniknout z řady různých stavů: genetických, jako je tomu v případě Edmunda, a po infekcích v těhotenství způsobených viry, jako jsou spalničky nebo Zika.
Symptomy a prognóza se mohou podstatným způsobem lišit.
Je příliš brzy na to, abychom mohli říci, jaký dopad bude mít virus Zika na životy nakažených.
Picciutová připomíná citovou daň, kterou si vybírá nejistá budoucnost.
Neustále se ptám: „Co bude dál?“
Co bude dál?
A stále si tím není jistá.
Ve skutečnosti jsem se nikdy neptala, jaká je celková prognóza, protože nečekám, že by mi to někdo vůbec dokázal říct.
Picciutová má ale povzbudivou zprávu pro matky všech dětí, které trpí vrozenými vadami způsobenými virem Zika.
Situace se zlepšuje.
Vězte, že to bude lepší.
Budete své dítě milovat a vaše dítě bude milovat vás.
Silné deště a záplavy si vyžádaly záchranné práce v Louisianě, Mississippi
Silný déšť a rozsáhlé záplavy v Louisianě přiměly v pátek guvernéra vyhlásit nouzový stav. Ve státě jsou v sobotu očekávány další deště.
Národní meteorologická služba (NWS) ohlásila, že po extrémních lijácích se řada řek na jihovýchodě Louisiany a v jižním Mississippi vylije ze svých břehů a hrozí rozsáhlé záplavy.
Guvernér Louisiany John Bel Edwards řekl, že státní úředníci jsou nepřetržitě v kontaktu s místními úřady a pomoc je již na cestě do postižených oblastí.
Mike Steele, mluvčí kanceláře guvernéra pro národní bezpečnost a připravenost na krizové situace řekl, že dostávají žádosti o vozidla pro jízdu ve vodě, čluny a pytle s pískem.
Steele řekl, že jen okrsek Tangipahoa požádal o deset tisíc pytlů s pískem.
Povodňové hlídky zůstanou ve většině jižní Louisiany pracovat do soboty.
Meteorologická služba v prohlášení uvedla, že nad mořem může napršet ještě dalších asi 8 až 13 centimertů.
V jižní Alabamě byla povodňová hlídka v pohotovosti v pátek, kdy deště pokračovaly v oblasti města Mobile.
Podle předpovědi mají řeky Comite u Baton Rouge a Amite u Denham Springs o víkendu kulminovat.
Meteorolog Alek Krautmann řekl, že obě řekly mohou zaplavit řadu domů v příměstkých oblastech Baton Rouge.
Uvedl dále, že nebezpečím jsou záplavy po proudu v okrsku Ascension, kdy se tyto rozvodněné toky budou do jezera Maurepas odlévat jen pomalu.
Řeka Tickfaw, o něco jižněji od hranice státu Mississippi v Liverpoolu ve státě Louisiana, dosáhla již v pátek v 9 hodin ráno místního času na nejvyšší zaznamenané úrovně.
Záchranáři stále vyzvedávají lidi z přívalových vod v hrabstvím Amite a Wilkinson na jihozápadě Mississippi.
Leroy Hansford, jeho manželka a nevlastní syn byli již dříve v pátek mezi záchráněnými u Glosteru.
Hansford (62) řekl, že voda z Beaver Creeku, které jsou normálně více než 120 metrů od jeho domu, přes noc rychle stoupla.
Řekl, že ho upozornil jeho další nevlastní syn, který žije nedaleko.
„Vzbudili jsme se a voda se blížila,“ řekl Hansford.
Měl jsme ji až do pasu.
Podle jeho manželky je to nejvyšší hladina, kterou kdy na říčce za posledních 48 let zažila.
Hansford řekl, že on a všichni členové jeho rodiny jsou postižení a on je jediný, kdo umí plavat.
Hansford uvedl, že krizoví pracovníci zachránili všechy tři obrovské nákladní vozy ve vojenském stylu a převezli je na hasičskou stanici v Glosteru, kde v pátek zůstaly zakryté.
Krautmann řekl, že s pokračováním vydatných dešťů se záplavy „rychle šíří“ a úřady zvažují evakuaci.
Podle Krautmanna pozorovatel nedaleko Livinstonu oznámil, že od půlnoci do pátku do rána spadlo 35 centimetrů dešťových srážek.
Krautmann řekl, že půda je od středy silně nasáklá.
Úřady uvedly, že vydatný déšť a zaplacené cesty si vyžádaly záchranu obyvatel z jejich domovů v okrese Tangipahoa a zrušení výuky v pěti školních okrscích.
Pobočka WWL stanice CBS oznámila, že podle stařešiny z Tangipahoa bylo zaplaveno 200 domovů.
Obyvatelé byli evakuováni do dvou kostelů, které jsou oba ale nyní zaplaveny.
Starosta obce Robby Miller uvedl, že úřady zachránily 72 lidí a sedm domácích zvířat, které vysoká voda uvěznila.
V obci Amite a ve městě Hammond byly zřízeny přístřešky pro ty, kteří byli evakuováni.
„Budou se moci vrátit domů, až voda začne opadávat,“ řekl.
V okrsku Tangipahoa ve městě Hammond bylo kvůli povodni uzavřeno více než 20 ulic a místní obyvatelé dostali k dispozici pytle s pískem, které si mohli vyzvednout a pokusit se ochránit své domovy a podniky před vodou.
„Poslední velké záplavy jsme tu měli v březnu,“ řekl správce městla Lacy Landrum.
Zdá se, že tyhle záplavy budou podobné.
Rupert Lacy, manažer pro krizové situace v hrabství Harrison ve státě Mississippi uvedl, že na pobřeží Perského zálivu pokračuje vytrvalý déšť.
Řekl, že ve čtvrtek bylo oznámeno zatopení pár domů, ale v pátek se žádné z nich už v hlášení neobjevily.
Keith Townsonová, vedoucí Shopper Value Foods v Amite, žije v oblasti již 40 let.
„Viděla jsem vodu na několika místech, kde jsem ji nikdy předtím neviděla,“ řekla Townsonová, „a je tam stále.“
Mahaj Brown (6) - „chlapec rozstřílený jak řešeto“, přežil střelbu ve Filadelfii
Podle policie byl ve Filadelfii postřelen šestiletý hoch. Tento týden se jedná již o druhou střelbu na dítě ve věku 6 let ve městě.
Prarodiče dítěte jej pro CBS Philadelphia identifikovali jako Mahaje Browna.
Prarodiče říkají, že chlapec utrpěl několik střelných zranění, včetně slabin, nohy, paže a břicha, ale při přepravě do nemocnice byl při vědomí.
„Schytal toho hrozně moc, jeho malé tělo bylo prostřílené jak řešeto,“ řekla stanici jeho babička, Delores Melendezová.
Nemohu tomu uvěřit.
Chlapec je v kritickém stavu v nemocnici a podstoupil několik operací.
Rodina pro stanici uvedla, že by se chlapec měl uzdravit.
Měl nastoupit do první třídy základní školy.
Mahaj Brown je mezi čtyřmi lidmi, kteří byli postřeleni v části Germantown.
Postřeleni byli ještě další tři muži: dva ve věku 29 let a jeden ve věku 32 let.
Jeden z mužů ve věku 29 let je v kritickém stavu, podle CBS Philadelphia jsou další dvě oběti ve stabilizovaném stavu.
Podle hlášení stanice bylo dítě nalezeno postřelené na předním sedadle vozidla spolu s devětadvacetiletým mužem v kritickém stavu.
Další dvě oběti nebyly ve voze a policie zkoumá, zda by některý ze zraněných mužů mohl být střelcem.
Vyšetřovatelé stanici CBS Philadelphia uvedli, že pravděpodobně došlo k přestřelce mezi několika ozbrojenými muži.
Na místě byly nalezeny nábojnice ze zbraní útočného typu, patřící různým útočným zbraním.
Podle všeho šlo zcela určitě o pokračující bitvu.
Na ulici byly nábojnice po obou stranách chodníku.
Zdá se tedy, že zde bylo několik ozbrojených bojujících osob, které byly aktivně zapojeny,“ uvedl pro stanici kapitán filadelfské policie Anthony Ginaldi.
Zasaženo bylo také několik domů a vozidel v oblasti.
Nikdo nebyl zadržen a policie údajně prozkoumává videonahrávky z kamer.
Další šestileté dítě, tentokrát dívka, byla postřelena do paže zbloudilou střelou v úterý před domem v sousedství West Oak Lane.
Dívka se zotavuje a policie stále hledá podezřelého.
Proč potřebujeme Simone, Gabby a Laurie
Právě takhle si představuji ženský tým gymnastek pro letošní olympijské hry, a to hned z několika důvodů.
Za prvé, byl jsem na každé letní olympiádě od roku 1984 a USA nebyly nikdy tak dominantní.
A za druhé: V tomhle týmu jsou tři gymnastky, Simone Bilesová, Gabby Douglasová a Lauren „Laurie“ Hernandezová, které inspirovaly tolik mladých barevných dívek.
Každý je hrdý na složení tohoto týmu, které doplňuje Aly Raismanová, která je židovského původu, a katolička Madison Kocianová.
Konečně máme tým, který vypadá jako Amerika.
Také upevnil přítomnost černošek a latinskoameričanek na špičce tohoto sportu.
Gymnastkou číslo jedna v uplynulých čtyřech letech byla afroameričanka.
Simone a Gabby byly loni na první a druhé příčce.
To něco znamená.
Na poslední olympiádě se Gabby Dougalsová překvapivě stala šampionkou olympijských her a Amerika jásala.
Nyní svět mohl být svědkem neuvěřitelného výkonu trojnásobné světové vítězky Simone Bilesové, Douglasové a Laurie Hernandezové, které předvedly neočekávané, ale mistrné gymnastické figury.
Ve čtvrtek se Simone stala čtvrtou Američankou, která získala zlato v ženském víceboji jednotlivců.
A členka týmu Aly Raismanová získala stříbro.
Jsme svědky sportovního vrcholu, ale v hodinách gymnastiky v zemi to tak nevypadá.
Simone, Gabby a Laurie absolvovaly do olympijského týmu stejnou cestu jako Aly a Madison.
Jsou „finálovou pětkou“, protože tým gymnastek na příští olympijské hry bude složen pouze ze čtyř atletek, a toto je poslední rok, kdy Marta Karolyiová trénuje.
Skutečnost je ale taková, že gymnastika je finančně náročný sport a gymnastky trénují převážně v soukromých gymnastických klubech, které udržují rodiče, kteří platí náklady na tréninky, vybavení, cesty, dresy, poplatky za soutěže, hotelové ubytování (pro trenéry a jejich svěřence a rodiny). A to zdaleka není vše.
Většina těchto sportovních klubů je v bohatých oblastech na předměstí, které mohou aktivity podporovat.
V těchto klubech mají gymnasté veškeré tréninky a pro rodiny gymnastek a gymnastů se jedná o nákladný a dlouhodobý závazek.
Aimee Boormanová, trenérka Simone Bilesové, a Maggie Haneyová, trenérka Laurie Hernandezové, obě trénovaly atlety v době, kdy začaly v gymnastice.
Je naší povinností přinést tréninky gymnastiky, které jsou více dostupné a přístupné komunitách bezpočtu mladých dívek, které Simone, Gabby a Laurie inspirovaly.
Nadaci pro gymnastiku jsem založila před 20 lety.
V mých organizacích, kde nabízíme gymnastiku zdarma nebo s nízkými náklady v Harlemu pro více než 15 000 mladých lidí v rámci města (především černošského a hispánského původu) a trénovali jsme národní i mezinárodní šampiony.
V září budeme expandovat do Detroitu (mého rodného města), kde budeme poskytovat kvalitní gymnastiku mladým lidem, kteří si zaslouží možnost učit se a těžit z tohoto skvělého olympijského sportu.
Gymnastika rozvíjí sílu, pružnost a koordinaci těla a tvrdou práci, disciplínu a odhodlání mysli.
Tato kombinace znamená doživotní přínosy pro dobré zdraví, úspěchy ve škole a v práci.
Právě inspirace tímto týmem k nám bude posílat tisíce mladých dívek, které budou chtít dělat gymnastiku. A to je skvělé.
Účast na tomto sportu je velmi důležitá, především pro dívky.
Je to velmi vzrušující doba.
Děkuji vám, Simone, Aly, Laurie, Gabby a Madison, za to, že jste prokázaly „dívčí sílu“ a vyhrály jste olympijské týmové zlato. A děkuji vám za to, že motivujete tolik mladých dívek všech původů, aby se vydaly na cestu stát se zdravými, silnými a úspěšnými mladými ženami.
Po zamítnutí návrhu Jeremyho Hunta jsou mladí lékaři připraveni vstoupit do dalších stávek
Ministři doufali, že po uzavření přepracované smlouvy se zástupci Britské lékařské asociace (BMA) dojde k ukončení neshod ohledně změn. Ale 58 procent z 37 000 mladých lékařů, kteří se voleb zúčastnili, smlouvu odmítlo.
Hunt v červenci odhalil plány na vynucení smlouvy s tím, že NHS byla v „zemi nikoho“ a další zpoždění by mělo škodlivý dopad na zaměstnance a pacienty.
První mladí lékaři již podepsali novou smlouvu, která zahrnuje změny v nočních a víkendových pracovních postupech s cílem zlepšení péče v nesociálních hodinách.
Lékařka Ellen McCourtová, předsedkyně komise BMA pro mladé lékaře v prohlášení minulou noc uvedla: „Mladí lékaři stále mají vážné obavy týkající se navrhované smlouvy, především v tom smyslu, že dojde k nárůstu současné krize pracovních sil a tedy k férovému zacházení se všemi lékaři.“
Pouhých osm týdnů předtím, než první skupina lékařů přejde pod novou smlouvu, je nutné dosáhnout pokroku a dochází čas.
Úsilí BMA o vyřešení sporů prostřednictvím vyjednávání se setkaly s neochotou zapojit dr a často s ohlušujícím tichem ze strany vlády.
A to navzdory slibu Jeremyho Hunta z minulého měsíce, že tato možnost je stále otevřená.
„Jeremy Hunt nyní musí jednat, zatlačit na vynucení a vyřešit obavy mladých lékařů.“
Pokud k tomu nedojde, pak jsou mladí lékaři připraveni provést další kroky.
Během poslední stávky na konci dubna došlo k odložení téměř 13 000 rutinních operací a 100 000 návštěv, protože sestry a specialisté byli povoláni, aby zastoupili lékaře, kteří byli mezi protestujícími.
Ministři doufali, že po uzavření přepracované smlouvy se zástupci Britské lékařské asociace (BMA) dojde k uzavření neshod týkajících ohledně změn.
BMA chce vyšší platby za práci o víkend pro 54 000 mladých lékařů, kteří by byli předmětem smlouvy.
Daniel Mortimer, předseda zaměstnavatelů NHS, vyzval mladé lékaře, aby do žádné stávky nevstupovali.
Mortimer řekl: „Oborovou akcí se dosáhne jenom málo nebo vůbec nic, ale vznikne tlak na již tak přetížené týmy a služby a vzrostou obavy, vyčerpání a narušení pro pacienty, ošetřující personál a jejich rodiny.“
V uplynulých dvou měsících jsme jednali s radou mladých lékařů a spolu s ministerstvem zdravotnictví a ostatními jsme pozitivně reagovali na jich obavy ohledně role dohledu a informátora.
Zaměstnavatelé doufali, že pokračující pozitivní zapojení v dalších důležitých otázkách - jako je vytížení, flexibilita při školeních, další školení pro ty, kteří se vracejí po přerušení kariéry, náklady na školení, vzájemné uznávání předmětů, studijní volno a rozdíl v platech mezi pohlavími - bylo důkazem toho, jak vážně zaměstnavatelé, Health Education England a ministerstvo zdravotnictví berou dohody, které byly s BMA dosaženy v listopadu, únoru a květnu.
Lék za šedesát korun na den dokáže snížit nebezpečí infarktu
Tisíce pacientů ohrožených infarktem budou moci užívat lék, který v přepočtu stojí okolo šedesáti korun (dvě libry). Úřady doporučují podávat jej více pacientům po delší dobu.
Lék proti srážení krve Ticagrelor snižuje u lidí s onemocněním srdce nebezpečí, že k záchvatu dojde znovu.
Lék se nyní po prodělání infarktu podává po dobu 12 měsíců, aby se snížilo nebezpečí mrtvice nebo jiného záchvatu.
NHS watchdog NICE doporučuje, aby byl lék lidem podáván po dobu čtyř let, aby se dále snížilo nebezpečí kardiovaskulárních problémů.
Nyní ale NHS watchdog NICE doporučuje, aby byl podáván lidem po dobu čtyř let, aby se dále snížilo nebezpečí kardiovaskulárních problémů.
V Anglii infarktem utrpí každý rok asi 140 000 lidí a čtvrtinu z nich postihne ještě další záchvat nebo srdeční mrtvice.
Infarkt a mrtvice jsou způsobovány nahromaděním tuku, který na stěnách arterií vytváří souvislou vrstvu.
Pokud dojde k odtržení této vrstvy, může dojít ke vzniku krevní sraženiny, zablokování přístupu krve do srdce a vzniku srdečního infarktu.
Pokud se sraženina uvolní, může krevním řečištěm pokračovat dál, zablokovat přívod krve do mozku a způsobit mozkovou mrtvici.
Lidé, kteří již infarkt prodělali, jsou vystaveni vyššímu riziku dalšího záchvatu.
Ticagrelor, který vyrábí britská firma AstraZeneca a který je prodáván pod obchodním názvem Brilique, snižuje riziko tím, že ke vzniku sraženin dochází méně pravděpodobněji.
V návrhu směrnice NICE, který byl dnes uveřejněn, se doporučuje, aby pacienti dostávali 90 mg ticagreloru po dobu 12 měsíců a pak 60 mg spolu s aspirinem, a to dvakrát denně po dobu dalších třech let.
Profesor Carole Longsonová, ředitelka centra pro hodnocení technologií pro zdravotnictví NICE, řekla: „Navzdory dostupnosti účinné sekundární preventivní léčby existuje čtvrtina pacientů, kteří měli infarkt a které postihne další srdeční záchvat nebo mrtvice - často s devastujícími následky.“
Strach z opakování může mít významný negativní dopad na kvalitu života pacienta.
Je prokázáno, že Ticagrelor v kombinaci s aspirinem je účinný ve snižování nebezpečí dalších srdečních záchvatů a mrtvice u lidí, které již infarkt postihl.
Je nám potěšením, že při předběžném doporučení Ticagreloru můžeme rozšířit možnosti léčby, které jsou dostupné mnoha tisícům lidí, kteří z něj budou moci těžit.
Protože informace o účinnosti a bezpečnosti Ticagreloru - především o nebezpečí krvácení - nad rámec tří let jsou omezené, není v návrhu léčba nad tuto dobu doporučena.
S počítačovou kulturou začaly vzkvétat podvody v muslimských oblastech
Starosta města Tower Hamlets Lutfur Rahman byl minulý rok odvolán z funkce kvůli korupci, což bylo spojeno s vládní zprávou
Kultura politické korektnosti vedla k přehlížení šířících se podvodů v muslimských komunitách, uvádí se dnes ve vládní zprávě.
Ex-ministr Sir Eric Pickles ostře kritizuje policii, volební inspektory a radnice za to, že ignorovaly zneužívání voličů kvůli „přecitlivělosti na etnicitu a náboženství.“
Dřívější tajemník komunity, nyní vládce protikorupčních zásahů, řekl, že zastrašování voličů na základě jejich náboženství je tak zlé, že policie by měla před volebními místnostmi udělat kordóny a vystražené voliče chránit.
Doporučil, aby si voliči s sebou vzali doklad totožnosti a mohli při volbách prokázat, kdo jsou.
V současnosti voliči stačí uvést své jméno a adresu.
Ve zprávě se dále navrhuje na prsty osob při odevzdávání hlasu nanést nesmazatelný inkoust, aby se předešlo tomu, že někdo bude volit dvakrát.
Whistlebloweři by měli mít větší ochranu, říká Pickles.
Žádá, aby tisk dostal větší přístup k dokladům ze zasedání a k rozhodnutím, která přijímají neoficiální výbory nebo pracovmí skupiny.
„Nejedná se pouze o ochranu proti volebním podvodům, ale také o ochranu místní vlády před širším korupčním prostředím a finančními podvody, které s tím jdou ruku v ruce,“ řekl.
Zprávu si vyžádala Downing Street jako důsledek volebního skandálu v Tower Hamlets v západním Londýně.
V loňském roce zvláštní volební soud rozhodl, úřadující starosta města Lutfur Rahman by měl být odvolán ze svého postu po obvinění z korupce a nelegálních praktik.
Soud shledal, že Rahman „cynicky zasáhl“ náboženské cítění své muslimské komunity a umlčel své kritiky obviněními z rasizmu a islamofobie.
Rahman podle svých slov „vedl svou kampaň tak, aby bylo náboženskou povinností oddaných muslimů, aby pro něj hlasovali.“
Až 300 hlasů bylo zpochybněno nebo jako výsledek krádeže totožnosti, kdy člověk hlasuje a vydává se zě někoho jiného.
Sir Eric uvedl, že existují důkazy o podvodech v celé zemi.
Vyjádřil zvláštní znepokojení nad podvody u korespondenčního hlasování - o kterém se tvrdí, že starší členové muslimské komunity během něj vyvíjeli nátlak na lidi, aby hlasovali pro kandidáta, které oni zvolili.
Sir Eric, na snímku, dal několik doporučení, jak volební systém vyčistit, včetně předložení dokladu totožnosti
V jeho zprávě se uvádí: „Byl předložen důkaz o tom, že na zranitelné členy některých etnických menšin, především na ženy a mladé lidi, byl vyvíjen nátlak, aby hlasovali podle vůle starších, a to především ve společenstvích pocházejících z Pákistánu a Bangladéše.“
„Vznikly obavy že... státní instituce přivíraly před takovým chováním oči kvůli „politicky korektní“ přecitlivělosti vůči etnickému původu a náboženství.“
Sir Eric přednesl 50 doporučení, jak systém vyčistit, včetně toho, aby bylo politickým aktivistům zakázáno manipulovat s korespondenčním hlasy a zabránit tak „vytěžování hlasů.“
Zpráva, kterou nyní hodnotí Theresa Mayová, také žádá o důkladnější kontroly při registracích, aby se zabránilo využívání volebních seznamů pro imigrační podvody a podvody s dávkami.
Zvážit možnost žádat od voličů, aby před hlasováním předložili doklad totožnosti.
Použití nesmazatelného inkoustu na prsty osob při hlasování, aby se předešlo tomu, že někdo bude volit dvakrát.
Provádění systematických kontrol národnosti osob, aby se zajistilo, že mohou volit.
Žádosti o automatické korespondenční hlasování omezit na dobu tří let.
Zakázat politickým agitátorům a aktivistům, aby manipulovali s odevzdanými korespondenčními hlasy a volebními obálkami.
Dát policii oprávnění vytvořit okolo volebních místností kordony.
Změnit zákony, aby bylo snadnější stíhat osoby vyvíjející nezákonný nátlak podle reformního zákona z roku 1983.
Zakázat pořizování fotografií ve volebních místnostech.
Vyžadovat, aby ve volebních místnostech pracovali pouze Angličané (s výjimkou Walesu).
Posílit školení a zajistit tak, aby pracovníci dodržovali pravidlo, že do volebních kabin chodí voliči jednotlivě.
Sir Eric kritizuje londýnskou policii a říká, že je „překvapující“, že po případu Tower Hamlets nebyla vznesena žádná obvinění z trestných činů.
„Soud pro otázky voleb vyloučil Lutfura Rahmana a jeho agenta za litanii korupce a nelegálních praktik“, řekl.
Z řady důvodů byl shledán vinným nad rámec důvodných pochybností - v síle důkazu trestného činu.
Také kritizuje bezvýsledné „kontrol zaškrtávacích políček“ v odděleních pro registraci voličů na radnici.
Sir Eric řekl: „Loňské rozhodnutí soudu v případu Tower Hamlets probuzením.
Náš národ má hrdý odkaz kolébky parlamentní demokraci, ale znepokojující a skryté šíření volebních podvodů a stav zamítání některými orgány tuto reputaci ohrožují.
Pobláznění cyklistickou dvojnicí vévodkyně Kate a dalších dvojníků známých osobností na olympiádě v Riu
Fanoušci olympijkých her v Riu 2016 se tento týden zbláznili do francouzské cyklistky Pauline Ferrand-Prevotové, která je až nápadně podobná vévodkyni z Cambridge.
Ale čtyřiadvacetiletá olympionička není zdaleka jedinou atletkou usilující letos o zlato, která se může pochlubit vlastním dvojníkem z řad známých osobností - alespoň ne podle sociálních sítí.
Na oslavu olympijských her v Riu a všech známých osobností, které se v současné době objevují na našich obrazovkách, sloupek pro ženy FEMAIL sestavil seznam olympioniků, kteří jsou víc než vzdáleně podobní holywoodským celebritám.
Jako lovená zvěř: Člen amerického týmu lukostřelců Brady Ellison (vlevo) byl od malička přirovnáván k Leonardu DiCapriovi
Vedle dvojnice Kate na cyklistické dráze řada lidí online rychle poukázala na to, že jistý lukostřelec by mohl být dvojčetem hvězdného Leonarda DiCapria.
Závodník z tým amerických lukostřelců Brady Ellison způsobil na Twitteru bouři po té, co se vynořily jeho snímky, na kterých se nápadně podobá vlkovi z Wall Street.
Brady sám si všiml mediálního šílenství a přiznal, že o své podobnosti s Leem slýchával od malička.
„Sám žádnou velkou podobnost nevidí, snad kromě vousů,“ řekl Brady pro Huffington Post.
„Je to frajer a vypadá dobře, takže myslím, že je to kompliment.“
Jedno z nejpopulárnějších srovnání z Londýna 2012 bude letos bezpochyby zdůrazňováno ještě víc: nápadná podoba mezi britským skokanem do dálky Gregem Rutherfordem a oblíbeným hercem Neilem Patrickem Harrisem.
O ruské gymnastce Aliye Mustafinové s jejíma velkými, výraznýma očima, se říkalo, že je kopií kubánsko-americké zpěvačky Glorie Estefan.
A když se podíváme k plaveckému bazénu, jihoafrický plavec Cameron van der Burgh je již několik let přirovnáván k hvězdě seriálu Gell Matthewovi Morrisonovi.
A pro změnu: Uživatel si myslí, že Nathan se „atletickou verzí“ herce z filmu Počátek (Inception)
Dalším dlouholetým srovnáním je přirovnání tenisové hvězdy Rafaela Nadala a herce Joshe Hartnetta, kteří mají podobně husté obočí a rty.
Ruská stříbrná plavkyně Yulia Efimovová se pyšní nejen stejnou snědou pletí a blond vlasy, jako má Annalynne McCordová. A o Nathanu Adrianovi z týmu USA fanoušci říkají, že vypadá jako „atletická verze Josepha Gordona Levitta.“
Zdatné ženy: hvěda fotbalu Hope Solová (vlevo) a herečka seriálu Dexter Jennifer Carpenterová (vpravo) mají podobný tvar obličeje a očí
Nejenom jeden: Uživatel Twitteru byl velice potěšen, že podobností si všimli i ostatní
Na vlnách teorie: Podle tohoto uživatele možná existuje důvod za podobným vzhledem párů
Jedna uživatelka Twitteru před nedávnem na stránkách vyjádřila svou spokojenost nad tím, že „zbytek Internetu si myslí, že Hope Solová a Jennifer Carpenterová jsou v pravdě identické.“
Fotbalová hvězda Hope Solová a herečka seriálu Dexter Jennifer Carpenterová mají opravdu neuvěřitelně podobný tvar obličeje a očí.
Mezi dalšími oblíbenými srovnáními je Kerri Walsh-Jenningsová a její úsměv, který je téměř identický s úsměvem herečky Laura Linneyové, nebo držitelka zlaté medaile za gymnastiku Gabby Douglasová, pyšnící se svým nádherně širokým úsměvem, který jako by kopíroval úsměv Gabrielle Unionové, hvězdy filmu Bravo, girls!
Komentátor olympijských her stanice CBC se omlouvá za to, že o čínské plavkyni řekl, že „vybouchla“
Diváky středečního živého přenosu z olympijských her na stanici CBC pobouřil rozbor výkonu čtrnáctileté Ai Yanhanové komentátorem Byronem MacDonaldem. Plavkyně skončila na čtvrtém místě závodu žen na 4x200 m štafety volným stylem
Kanadská stanice CBC byla donucena omluvit se po té, co jeden z jejích komentátorů řekl, že se čtrnáctiletá čínská plavkyně během závodu „táhla jako smrad“ a „vybouchla“.
Komentátor Byron MacDonald se domníval, že jeho mikrofon byl vypnutý, když na konci finále štafety žen na 4x200 metrů volným stylem začal chrlit vlastní názory.
MacDonald, který měl do týmu komentátorů CBC přinést „oživení“, mimo jiné prohlásil: „Ta malá čtrnáctiletá z Číny to vzdala, ty bláho.“
Přílišné vzrušení, táhla se jako smrad, vybouchla.
Díky.
Čínská plavkyně Ai Yanhanová (14) uplavala druhou štafetu závodu v čase 1:57.79 - tedy o 1,61 vteřiny pomaleji než kanadská Taylor Rucková a umožnila Kanaďankám Čínu dotáhnout.
Diváci v Kanadě se začali rychle ozývat online a byli zděšeni tónem a jazykem, který komentátor použil
Emmett Macfarlane napsal na Twitter: „Prohlásil ten hlasatel na CBC, že čtrnáctiletá plavkyně z Číny „vybouchla“????“
Ten idiot si nevšiml, že je ještě ve vysílání.“
Ai Yanhanová z Číny ve finále ženského štafetového závodu na 4x200 metrů volným stylem byla popsána jako: „Ta malá 14letá z Číny to vzdala, ty bláho.“
Kritika Byrona MacDonalda na Twitteru přišla ze všech stran a mnozí žádali jeho odvolání
Když se uživatelé Twitteru dozvěděli, jak necitlivý Byron MacDonald je, nedrželi se zpátky
Další uživatelka, Sarah Paradisová, napsala: 'Wow #ByronMacDonald.
Zastupujete CBC a Kanadu a zní to, jak bychom byli banda rasistů.#znechucení.
Brzy poté se Scott Russel, který vysílání CBC hostil, omluvil za živý komentář MacDonalda a řekl: „Omlouváme se za komentář k výkonu plavkyně, který unikl do vysílání.“
Byla to nešťastná volba slov, je nám líto, že k tomu došlo.“
Stanice CBC se nakonec omluvila více než 90krát lidem, kteří tweetovali v odpovědi na komentář
Spolukomentátor Scott Russel se musel omluvit jménem MacDonalda
CBC pak zkopírovala a vložila jejich omluvu do odpovědi pro více než 90 uživatelů Twitteru, kteří si na poznámky komentátora MacDonalda stěžovali
Stanice se také rychle omluvila a uveřejnila prohlášení.
Upřímně lituje, že ta byla slova vyřčena, neměla se dostat do éteru.
Rychle jsme se omluvili našim divákům ve vysílání a těm, co nás sledují na sociálních sítích.
Aby bylo jasné, Byronovy komentáře se týkaly výkonu plavkyně, ne plavkyně samotné.
Jinými slovy se jednalo o nevhodnou a nešťastnou volbu slov. Byron se hluboce omlouvá za to, co řekl.
Ve čtvrtek odpoledne se Byron MacDonald omluvil v živém vysílání a pokusil se svou poznámku vysvětlit tvrzením, že nechtěl, aby vyzněla jako osobní útok.
„Rád bych se nyní omluvil za komentář, který jsem uvedl včera v noci po štafetě žen,“ řekl ve vysílání z olympiády na stanici CBC.
„Měl jsem na mysli výkon plavkyně a ne osobu plavkyně jako takovou.“
„Není potřeba říkat, že jsem neměl v úmyslu žádnou neúctu a velmi mě to mrzí.“
Zákazníci v Primark pohoršeni ženou, která si nestydatě zkoušela spodní prádlo uprostřed obchodu
Když se žena vysvlékla, aby si na prodejní ploše uprostřed Primark vyzkoušela kalhotky, nebyli si nakupující jistí, kterým směrem se dívat.
Aby to bylo ještě horší, zkoušela si, jak jí velikost padne, kalhotky si svlékla a vrátila je zpět do regálu.
V prohlížení pokračovala a nakonec si v obchodě v nákupním centrum Bouverie Place ve Flokestone vyzkoušela čtyři páry kalhotek.
Obchod Primark v nákupním centru Bouverie Place ve Folkestone, kde si žena zkoušela kalhotky před tím, než je vrátila do regálu
Matka dvou dětí Jenny Davidsonová, která byla v danou dobu v obchodě, uvedla, že záhadná žena se po vyzkoušení spodního prádla „znovu oblékla a vyšla z obchodu, aniž by si něco koupila.“
Řekla: „Lidé nemohli uvěřit vlastním očím.“
Stála uprostřed obchodu, vzala z regálu kalhotky, svlékla si svoje vlastní punčocháče a kalhotky a nasadila si je.
„Nepokoušela se ani najít nějaké diskrétní místo - jen tak tam stála, drzá jako opice.“
„Každý jen zíral, jak si kalhotky znovu svlékla, a evidentně se jí nelíbily, protože je vrátila zpět do regálu.“
To samé udělala ještě s třemi dalšími, než se konečně rozhodla, že se jí nic nelíbí, znovu se oblékla a odešla.
„Vypadala, že jí vůbec nevadí, kdo se dívá - ani, že by pomyslela na toho člověka, který se třeba koupí kalhotky, které si zkoušela.“
Slečna Davidsonová (33), která žije v Kentu, řekla: „Ta představa, že si někdo vezme domů kalhotky, které na sobě měl někdo jiný a nikdo je nevyčistil. To je hnusné.“
K události došlo v úterý odpoledne.
Slečna Davidsonová dodala: „Když odešla, posbírala jsem věci, které si evidentně zkoušela, abych je stáhla z prodeje - co je také jediné správné.“
„Děsila by mě představa, že si přinesu domů nové kalhotky a zjistím, že je na sobě měla jiná žena, svlékla si je a že nebyly vyprané.“
Mluvčí obchodu Primark řekl: „Primark ví o incidentu, ke kterému došlo v našem obchodě ve Folkestone v úterý 9. srpna.“
Veškeré dotčené výrobky byly staženy z prodeje.
Jak se bránit proti útoku zbraní pomocí Krav Maga
Svět venku je nebezpečný, ale díky tomuhle videu z Dailymail.com by pro vás mohl být o něco bezpečnější.
Mluvili jsme s Rhonem Mizrachi, velmistrem federace Krav Magy sídlícím v New Yorku, abychom zjistili, jak si poradit s ozbrojenými lupiči na blízkou vzdálenost.
Toto video vám ukáže, jak náhle získat nad násilníkem převahu, ať už se k vám přiblízí zepředu, nebo zezadu.
Pokud se k vám přiblíží zezadu, říká Mizrachi, pak první, co musíte udělat, je obrátit se, abyste svého útočníka viděli a „měli volnou dráhu střely“.
Uchopíte pak zbraň mezi své předloktí a rameno těsně předtím, než jej uhodíte do obličeje volným loktem.
Pak následuje koleno do slabin, a zatímco se útočník svíjí v bolestech, vykroutíte mu zbraň z ruky, udeříte jej hlavní do obličeje a začnete ustupovat, zbraň přitom budete držet namířenou na něj.
Pokud se k vám blíží ozbrojený muž zepředu, je to podobná technika - dostaňte své tělo z palebné linie, uchopte zbraň a vykruťte ji, aby darebák nemohl střílet.
Současně dejte do zbraně sílu a udeřte útočníka do hrudi, pak zbraň z jeho sevření vykruťte a začněte ustupovat, stále na něj přitom miřte.
Zní to složitě?
Podívejte se na video, kde přesně uvidíte, jak to Mizrachi dělá.
Nezapomeňte ale, že nejbezpečnějším způsobem, jak se z přepadení dostat - pokud nejste velmistrem Krav Maga - je vydat veškerou hotovost.
Cestovatel Ian Wright olizuje nejšpinavější místa v Evropě do cestovního průvodce
Britský cestovatel se rozhodl podrobit těžké zkoušce svůj imunitní systém a dávivý reflex - olizováním těch nejšpinavějších a nejnechutnějších míst v Evropě.
Moderátor a autor cestopisů Ian Wright (51), původem ze Suffolku, na důkaz síly svého imunitního systému oblízl svým jazykem eurovou bankovku, zábradlí na Piccadilly Circus, tlačítko splachovadla na toaletě ve vlaku a ruský veřejný telefon.
Před oblíznutím každého předmětu použil luminometr, aby ukázal sobě i nám všem, do čeho se pouští.
Experiment, na základě kterého byl natočen film Lickhiker's Guide to Inner Strength, ovšem přinesl zajímavé výsledky.
Nápad olíznout tlačítko splachovače ve vlaku, které použily tisíce jiných lidí, se může zdát naprosto odpudivý, nicméně třeba v kuchyňském dřezu je ve skutečnosti mnohem víc škodlivých bakterií.
Ian Wright během celé své cesty po Evropě hovořil s lékaři a specialisty ve zdravotnictví o posilování bakterií střevních flóry a o svém vlastním zdraví.
Naštěstí nic z toho, co olízl, mu v ústech nezanechalo nic horšího než pachuť.
Ian Wright se proslavil testováním odolnosti svých střev na cestách kolem světa a pojídáním podivných i úžasných věcí.
Během téhle mise zcela bezpečně svůj imunitní systém otestoval - od veřejných zábradlí na vlakových stanicích po splachovadlo
Ve filmu, který o tom natočil, říká: „Už od dětství jsem se o své zdraví moc nestaral a do pusy jsem si dával všechno možné, od hlíny po pojídání červů a bahnité vody.“
Ve filmu svou reputaci dozajista potvrdil.
Jediné, co odmítl, byly špinavé veřejné záchodky v Rusku.
Po jednoduchém stěru luminometr ukázal hodnotu více než 4000 jednotek.
Pro porovnání, čerstvě umyté ruce by měly mít méně než 60.
Jeden veřejný záchodek v Rusku ale olíznout odmítl po té, co jeho luminometr ukázal více než 4000 jednotek, zatímco čerstvě umyté ruce mají méně než 60
Ian Wright a finský výrobce mléčných výrobků Valio natočili cestovatelův film s názvem The Lickhiker's Guide to Inner Strength, který ukazuje počty bakterií na různých místech, jako například v koupelně
Ve filmu řekl: „Tohle je skoro to nejhnusnější, co jsem kdy na záchodě cítil.“
Nic špinavějšího než tohle neexistuje!
Olizovat nebudu nic, protože je to tu nechutné.
Film Lickhiker's Guide to Inner Strength byl natočen ve spolupráci s finským výrobcem mléčných výrobků Valio.
Společnost panu Wrightovi poskytla přípravek Valio Gefilus, který obsahuje bakterie mléčné kyseliny a vitamíny C a D, které u lidí pomáhají posilovat střevní bakterie a imunitní systém.
Niko Vuorenmaa, senior viceprezident společnosti Valio pro občerstvení, džusy a nové kategorie, řekl: „Chtěli jsme spotřebitelům nabídnout něco opravdu nového.
Něco, co by sledovali se zaujetí a zároveň by nám umožnilo vysvětlit přínosy probiotik.
Vymysleli jsme spousty bláznivých nápadů, které skončily nápadem „zavolejme Ianovi.“
Říká se, že zájem o zdraví střev se stává celosvětovým fenoménem.
Namísto toho, abychom pouze o výrobcích mluvili, jsme je chtěli dát do širších souvislostí - dobré a špatné bakterie v našem každodenním prostředí, důležitost zdraví střev a jak je to propojeno s imunitním systémem.
Rostoucí zájem o zdravá střeva je celosvětovým fenoménem a prostřednictvím tohoto dokumentu jsme spotřebitelům zajímavým způsobem přinesli podrobnější informace.
Také si myslím, že se ve filmu objevuje skvělý smysl pro humor!
Tom Hakala, který film režíroval, dodává: „Řekněme to takhle, Ian by ztratil můj respekt, kdyby olízl něco z toho, co jsem po něm chtěl - jako třeba ten nechutný ruský záchod, co se ve filmu objevuje.“
Olíznout některé věci bylo pro Iana přirozeně snazší, jiné zase pěkně těžké.
Jsem rád, že jsme olíznutí některých těch špinavých věcí natočili.“
Společnost Valio provedla v roce 2015 průzkum, podle kterého si 84 procent respondentů spojovalo bakterie kyseliny mléčné především se zdravím žaludku a střev a 58 procent respondentů uvedlo, že alespoň příležitostně užívají výrobky obsahující přidané bakterie kyseliny mléčné.
Rodina sociálně potřebných před vystěhováním poničila obecní budovu ve městě Saltash v Cornwallu
Rodina sociálně potřebných zanechala na svém obecním domě škodu ve výši 50 000 liber poté, co byli obvinění z terorizování svých sousedů.
Tanya Skeldonová a její partner Shaun Trebilcock byli vystěhováni z domu ve městě Saltash, Cornwall, po dlouhé řadě stížností proti nim.
Po jejich násilném vystěhování z domu byli úředníci bytového družstva šokováni, když zjistili, že se nemovitost nachází v havarijním stavu.
Ve zdech byly díry, podlahová krytina byla potrhaná, všude na podlaze se válely odpadky a zdi byly počmárané.
Rodina se již odstěhovala a má se za to, že bydlí v soukromém ubytování
Donna McEvoyová, ředitelka pro otázky bydlení ve společnosti Cornwall Housing uvedla, že měla obavy, zda dům půjde zachránit.
Řekla: „Pro lidi zde to byla noční můra a nemyslím si, že by lidé měli takhle žít.
Je třeba zvážit řadu okolností, protože tahle nemovitost vejde nejspíš do povědomí jako „ne až tak pěkná část“ Cornwallu.
Ta rodina je nechvalně známá a jejich jména jsou nechvalně známá.
Pár má tři syny, kteří v domě občas pobývali, a policie uvedla, že hrůzovláda, kterou rodina působila, patřily pouliční bitky s použitím baseballových pálek, zastrašování okolních obyvatel, užívání drog, distribuce drog a hlasitý křik, hádky a nadávky.
Skeldonové (47), jejíž jméno bylo uvedeno na nájemní smlouvě, byl v červnu udělen trest za antisociální chování.
V několika místnostech v domě, který možná bude zbourán, byly nalezeny zapáchající odpadky.
V domě, odkud se v minulosti distribuovaly drogy, byla vytrhaná podlahová krytina
Sousedé říkají, že je viděli na ulici, jak se perou, a pravidelně sem lidé volali policii
Společnost Cornwall Housing ji a jejího partnera násilím z domu tento týden vystěhovala poté, co dostali dodatečnou lhůtu 11 týdnů k tomu, aby se vystěhovali dobrovolně.
Sousedé, kterým se ulevilo, vystěhování přivítali s tím, že jejich životy byly živoucím peklem.
Jeden z nich řekl: „Nestarali se vůbec o nikoho.“
Žili jsme vedle nich 20 let a vždycky to bylo takhle.
Kolikrát jsme tady viděli policii, se nedá vůbec spočítat.
„Dneska ráno jsme nemohli spát.“
Vstali jsme, protože tady bylo neuvěřitelné ticho - na to nejsme zvyklí!
Bude tu pěkně, když jsou konečně pryč.
Adam Fitzpatrick, manažer pro dohled v sousedství společnosti Cornwall Housing, uvedl, že rodina nedokázala spolupracovat s místními autoritami.
Rodina v domě žila 20 let, k domu byla pravidelně přivolávána policie
Odpadky a staré hračky se povalovaly v zarostlé části obecního domu
Dodává: „Je ostuda, že nájemnice nedokázala přijmout odpovědnost za vlastní chování a za chování své rodiny. Vystěhování je vždy až tím posledním krokem, který společnost Cornwall Housing zvažuje.
Jednalo se velmi složitý případ, protože jejich chování bylo extrémní a jejich akce podle svědka musely její sousedy děsit.
Vážím si veškeré práce, kterou odvedl můj tým, policie z Devonu a Cornwallu a členové místní komunity, kteří nás statečně informovali.
Doufám, že tenhle krok přinese trochu pohodlí sousedům a současně s sebou ponese poselství, že nespolečenské chování nebudeme tolerovat.
Fitzpatrick řekl, že všem třem synům nájemnice, kteří v domě v různém čase žili, bylo okolo 20 let.
Znečištěná matrace, která po vystěhování zůstala na podlaze jedné z ložnic v domě
Pracovníci budou nyní muset odstranit hromady odpadků, které zůstaly pohozené okolo domu
V roce 2014 provedla police v domě razii a nalezla přes 70 gramů konopí, váhy, vybavení a 1 700 liber v hotovosti.
Skeldonová dostala pokutu, když byla shledána vinnou za držení drog třídy B, které chtěla prodávat.
Tvrdila, že peníze byly určeny na základy domu pro jejího syna, Leeho Skeldona, který zemřel při automobilové nehodě v roce 2013.
Má se za to, že Tanya a její partner po vystěhování nyní žijí v soukromém ubytování v Plymouthu.
Zdi v mnoha místnostech domu byly pomalované graffiti.
Policie říká, že budou usilovat o vystěhování nájemníků, kteří porušují pravidla jejich nájemních smluv
Angela Crowová z policie Denovu a Cornwallu uvedla, že vystěhování bylo vysláním jasného vzkazu pro ostatní nájemníky, kteří budou i nadále pravidla porušovat.
„Tohle je vzkaz všem těm, kteří si myslí, že se mohou chovat beztrestně, a těm, kteří by chtěli takové chování následovat,“ řekla.
Policie Denovu a Cornwallu nikdy nebude tolerovat zločinné a nespolečenské chování a i nadále bude spolupracovat s partnery na ochraně našich společenství.
Turisté v Portugalsku vyděšeni po nízkém přeletu vojenského tryskového letadla nad pláží
Turisté, kteří si vychutnávali sluneční paprsky v portugalském Aveiru, byli vyděšení k smrti
Letoun portugalského vojenského letectva P-3C Orion přelétával až neuvěřitelně nízko
Vojenské letectvo prohlásilo, že se jednalo o cvičný let, a trvalo na tom, že nedošlo k ohrožení bezpečnosti
Ve chvíli, kdy se nízko letící tryskáč snesl nad zaplněnou pláž, zachvátila vystrašené turisty panika.
Na dramatických záběrech je vidět, jak se vojenské letadlo dostává do vzdálenosti téměř na dotek od slunících se lidí na písečné pláži u města Aveiro v severním Portugalsku.
Turisté se začali zvedat poté, co je zneklidnil hluk motorů tryskového letadla, aniž by viděli, co se z mraků vynoří.
K incidentu došlo včera odpoledne na Costa Nova v blízkosti města Aveiro.
Daniel Fernandes, jeden z několika rekreantů, kteří uveřejnili videonahrávky dramatického přeletu na sociálních sítích, řekl: „Letadlo přeletělo dvakrát opravdu nízko a v jednom okamžiku se zdálo, že se zřítí.“
Nuno Arroja dodává: „Surfoval jsem a doopravdy jsem si myslel, že mi letadlo spadne na hlavu.“
Turisté na pláži v Aveiru byli zděšeni, když se z temnoty objevilo letadlo letící nízko
Portugalské vojenské letectvo dnes prohlásilo, že pilot letounu P-3C Orion byl na cvičném letu s cílem identifikovat rybářské lodi u pobřeží a musel se snést nízko, protože to byl jediný způsob, jak lodi zkontrolovat.
Letoun údajně letěl o něco níž, než je obvyklé, kvůli špatné viditelnosti způsobené kouřem z nedalekých lesních požárů. Letectvo nicméně trvá na tom, že bezpečnost lidí nebyla ohrožena.
Lesní požáry letos v létě zničily část pevninského Portugalska a vyžádaly si čtyři oběti na životech na ostrově Madeira.
Portugalské vojenské letectvo dnes prohlásilo, že pilot musel letět nízko kvůli husté mlze a kouři z požárů, které mu bránily ve výhledu
Letoun byl na cvičném letu a pilot byl požádán, aby v rámci výcviku identifikoval rybářské lodi.
Polovina pohřebních služeb nedodržuje předpisy.
Polovina poskytovatelů pohřebních služeb nedodržuje právní předpisy.
Česká obchodní inspekce (ČOI) to zjistila při kontrolách ve druhém čtvrtletí.
Pohřební služby podle ní nejčastěji neinformují pozůstalé o svých cenách nebo nevydávají písemné potvrzení o převzetí objednávky.
ČOI za to uložila 41 pokut v celkové hodnotě 73.000 korun.
Dnes o tom informoval její mluvčí Jiří Fröhlich.
Inspektoři zjistili pochybení při 47 z 95 kontrol.
Vedle neinformování o cenách a chybějících potvrzení některé pohřební služby také prodaly výrobky nebo poskytly služby za jiné ceny, než bylo sjednáno.
V pěti případech nebyly prodávané výrobky řádně označeny a jednou prodávající použil úředně neověřené měřidlo.
Inspekce proto zakázala prodej 23 výrobků za celkem 7077 korun.
Týkalo se to obalů na urny, krytů na svíčky a váz, které nebyly řádně označeny povinnými informacemi.
"Vzhledem k tomu, že v této specifické oblasti služeb stále dochází k porušování zákona, bude kontrolní akce pokračovat i v dalším čtvrtletí tohoto roku," dodal Fröhlich.
Londýnská školačka, která se připojila k IS, byla zabita v Sýrii
Bylo oznámeno, že Kadiza Sultana, jedna ze tří britských školaček, které loni odešly z Londýna, aby se připojily k IS, zemřela v Sýrii.
Právní zástupce Tasnime Akunjee řekl, že rodina se o její smrti v syrské Rakce dozvěděla před několika týdny.
ITV News ve čtvrtek oznámila, že byla pravděpodobně zabita během ruského leteckého útoku v Rakce, která je baštou skupiny v zemi.
Sultaně bylo 17 let a podle její rodiny zemřela právě ve chvíli, kdy se připravovala na útěk z válkou sužované země a na návrat do Británie.
„Člověku se chce věřit, že jediným dobrým na celé té věci - jako poselství a výstraha pro ostatní, že toto jsou skutečná nebezpečí spojená s cestou do válečné zóny - je, že odradí lidi od toho, aby kdy rozhodnutí udělali,“ řekl Akunjee.
Sultana a dvě další školačky z východní části Londýna nastoupily v únoru 2015 do letadla do Turecka a pak do autobusu k hranici se Sýrií.
Rodina Sultany se dozvěděla, že se v Sýrii vdala za bojovníka IS - a během několika měsíců ovdověla.
Reid říká, že pokud bude Clintonová zvolena, ponechá Garlanda jako kandidáta Nejvyššího soudu.
Lídr v Senátu za demokratickou stranu Harry Reid říká, že je přesvědčen, že kandidátka prezidentských voleb za demokraty Hillary Clintonová nominuje soudce Merricka Garlanda do nejvyššího soudu v případě svého zvolení.
Republikáni v Senátu zablokovali Garlandovo jmenování, i když jej prezident Barack Obama nominovat již v březnu.
Lídr senátní většiny Mitch McConnel říká, že osobu, která nahradí zesnulého soudce nejvyššího soudu, zvolí budoucí prezident.
Reid během konferenčního hovoru ve čtvrtek prohlásil, že se domnívá, že Clintonová vybere Garlanda „s určitým stupněm důvěryhodnosti.“
Reidova mluvčí později uvedla, že s Clintonovou přímo nemluvil o tom, zda by Garlanda nominovala, a že pouze spekuloval.
Ocenil Garlanda a řekl, že tým Clintonové by volbou někoho jiného nechtěl „rozhoupat loď“.
Garland je předsedou federálního odvolacího soudu ve Washingtonu.
Reid řekl, že republikání, kteří blokují Garlandovo jmenování, jsou „přisluhovači“ a „poskokové“ republikánského kandidáta na prezidentský úřad Donalda Trumpa.
Řekl, že Trump se do úřadu nehodí.
Podle magazínu Treats jsou nahé kalendáře pro „ženy i pro muže“
Magazín Treats úzce spolupracuje s fotografem Davidem Bellemerem na vydání kalendáře pro rok 2017, inspirovaného kalendářem Pirelli ze 70. let.
Ale namísto odhalených známých osobností se snaží pro svůj kalendář 2017 NU Muses najít další generaci top modelek.
Prezident Treats Steve Shaw nám již dříve v tomto roce sdělil, že jeho magazín plný nahoty se od Playboy ze staré školy liší, protože „Playboy je pro muže.“
Já to dělám pro ženy.
Evidentně se domnívá, že kalendář také.
„Musíme se vrátit k zobrazování nadčasové a klasické nahoty, kdy se příjemně cítí ženy i muži a nechávají se inspirovat fotografiemi ženského těla,“ prohlásil Shaw v tiskovém prohlášení k vydání kalendáře.
Ženy chtějí být součástí tohoto projektu, protože je to nádherný kus umění.
Modelky mohou posílat své snímky online nebo osobně během otevřených konkurzů v Los Angeles a v New Yorku.
Kam směřuje vinyl: kdo doopravdy kupuje gramofonové desky?
Vinyl milují osamocení muži ve středním věku.
Než se rozhodnete sekci komentářů zahltit peprnými poznámkami pod pseudonymem NeVšichniOsamělíMužiVeStřednímVěku, podotýkáme, že tento výrok vychází ze skutečných údajů.
Podle YouGov je tolik diskutované vzkříšení gramofonových desek spojeno ne s boomem mileniálů, kteří se chtějí kochat originalitou vlastnění fyzického předmětu, ale s nostalgií středního věku.
Těmi, kteří si v nedávné době koupili album na vinylu, jsou nejpravděpodobněji lidé ve věku mezi 45 a 54 roky.
Mladí lidé ve věku 18-24 jsou nejméně pravděpodobní.
Nejde vlastně ani o hromadění nadšeného fanouška - celé to má emocionální rozměr: starší lidé, kteří si kupují gramofonové desky, si pravděpodobněji chtějí uchovat své pocity (56 % versus 53 %) a jsou rádi sami (69 % versus 66 %).
Ale jsou výsledky YouGov pravdivé?
Pokud by tento blog byl odvysílán jako televizní reportáž, sledovala by mě kamera, jak vyrážím do rušné ulice v Soho, oblečen do decentního šedého obleku a široce gestikuluji. Pak bych se zastavil, vytáhl ruce a řekl něco autoritativního, jako: „Tak se na to pojďme podívat.“
Tak se na to pojďme podívat.
Zatímco se ze srdce Soho pomalu vytrácí jeho šarm a kouzlo - budovy kdysi obsazené nezávislými prodejci, jsou nyní zaplněny hotely, restauracemi a jídelnami, konfekcí a kancelářskými potřebami - několik fantastických specializovaných obchodů s gramofonovými deskami ještě zůstalo.
Nejspíš bych požádal kameru, aby na chvíli přestala natáčet. Já se postavím do blízkosti různých mužů v těchto obchodech a pokusím se vypozorovat, jaký je jejich věk a emocionální rozpoložení.
Stuart (55), rodák z Glasgowa, kterého sleduji ze Sister Ray (počty: dvě mladé ženy, tři muži středního věku) do Reckless Records (počty: osm mužů středního věku, jedna žena okolo 20) má v Londýně odpoledne schůzku a prohlíží si obchody, aby vyplnil několik hodin času.
Ptám se ho, zda je sběratel.
„Já myslím, že ano,“ říká.
Mám asi 3 nebo 4 tisíce nahrávek.
Všechny ty nahrávky lemují stěny jeho obýváku - na obrázku nahoře (fotku mi poslal e-mailem, nesledoval jsem ho až domů).
Tohle obrovské množství alb a singlů má také díky tomu, že si to může dovolit: může si nyní kupovat gramofonové desky, které si dovolit nemohl, když vycházely původně, a znovu si kupuje to, co prodal v mládí a neměl ani vindru.
„Hodně z toho, co si kupuji, je z konce 60. let a z počátku 70. let. Jsou to věci, které by vydávané, když mi bylo 11 nebo 12. Tehdy jsem byl moc malý a nemohl si je pořídit,“ říká.
Souhlasí s tím, že ti, kdo si nahrávky kupují, jsou nejspíš introverti, co mají rádi společnost sebe samých. A dodává: „Nekouřím a ani moc nepiji.
Tohle je můj hřích.
Wez (25) pracuje v Sister Ray a také si myslí, že řada zákazníků, se kterými se setkává, zapadá do profilu YouGov.
Všiml si také nového přílivu lidí ovlivněných mediální vlnou. Lidí, kteří o comebacku slyšeli a cítili se nuceni koupit si své staré gramofonové desky zpět.
Podle mých rozhovorů se lidé svých sbírek zbavovali nejčastěji mezi roky 1998 a 1999.
Zákazníci, kteří jednou prodali své gramofonové desky a nakupovali CDčka, nyní prodávají svá CD, aby své gramofonové desky nakoupili zpět,“ říká.
To by mohlo vysvětlovat boom milovníků gramofonových desek určitého věku.
Ale co údajná emocionální důležitost gramofonových desek?
Nezabere vám víc než několik vteřin, abyste v obchodě jako Phonica zjistili, že v obchodech s hudbou naleznete příjemné společenství lidí s podobným smýšlením.
Podle Weze jsou někteří starší zákazníci obzvlášť pohoršeni systémem bezkontaktních plateb.
Někteří příznivci gramofonových desek se mohou v digitálním světě cítit zahlceni a rozhodli se pro známé prostředí obalů gramofonových desek, věcí, které vyvolávají vzpomínky na pokojné dospívání.
„Myslím si, že vyplnění mezery nebo vlastnění něčeho hmotného může přinášet určitý komfort,“ říká Wez.
Sám jsem sběratel, u mě je to tak a myslím, že u spousty lidí také.
Je to snadný způsob, jak zaplnit místo v hlavě.
„Všichni jsme jako jejich sociální pracovníci!“ ozývá se spolupracovník od hromady gramofonových desek.
Průzkum společnosti ICM v dubnu odhalil, že téměř 50 % lidí, kteří si o měsíc dřív koupili vinylové album, si jej ještě neposlechlo.
Podle průzkumu má 41 % dotazovaných gramofon, který nikdy nepoužívají, zatímco 7 % z těch, co si kupují gramofonové desky, gramofon nemá.
V tomhle bodě reportáže byl nejspíš vypadal vážně znepokojený při procházení hromádky compilací bossa nova.
Aspekt „trofeje“ a oživení zájmu je něco, čeho si všiml Jonny (42), který pracuje v Sounds of the Universe (počet: tři muži středního věku).
„Někdo nedávno přišel a řekl: „Ještě nemám gramofon, ale chci si koupit na desce Radiohead, abychom si ji mohli vystavit na poličce,““ povídá.
Procento takových není velké, ale dochází k tomu.
Jde víc o produktovou stránku než o hudbu.
Chodí k nám lidé, kteří říkají: „Gramofon nemám.“
To jsou mladší lidé, ne ti starší, odrostlí puberťáci, kteří se do toho dostávají.
Fopp, kde je v současné době téměř celé jedno patro vyhrazeno gramofonovým deskám, má při mém příchodu mnohem různorodější návštěvníky.
Jsou tu páry sedmdesátníků, turisté, co dělají fotky, puberťáci a ženy ve středním věku.
Zatímco atmosféra není tolik uvolněná, jako obchodech dříve - z reproduktorů se namísto tahavého jazzu ozývá nejnovější pop od Wild Beasts plný syntezátorů a sexu, je dobré vidět rozličné zákazníky.
Žádný z nich nevypadá nijak zvlášť osamoceně, ale vtíravé duševní trauma těžko odhadnete, když vedle někoho stojíte 30 vteřin.
Elanora (27) se několik minut ve Fopp prochází a prohlíží si různé gramofonové desky ve slevě.
Je jednou z těch, kdo si spíš prohlíží výlohy, než aby horečně utrácela.
Podle svých slov moc nevydělává, takže nepřipadá v úvahu, že by gramofonové desky sbírala.
Stojí to spoustu peněz.
Je snadné poslouchat hudbu na počítači nebo podobně. Ale gramofonové desky mají své kouzlo... ,“ povzdychne si toužebně.
Neumím to vysvětlit - je to jedinečné.
Mou poslední zastávkou je obchod, který údajně inspiroval novou generaci milovníků gramofonových desek: Urban Outfitters.
Tvářím se, že jsem velice zaujatý lýtky děvčat v upnutých džínách a sleduji skupinu náctiletých dívek, které se právě shlukují okolo fotoaparátů Polaroid. Pak se otec s dcerou rozhodují o nákupu gramofonu Crosley.
Nalevo je schodiště, jehož stěnu zakrývají gramofonové desky Adele, Jeffa Buckleyho, Amy Winehouse a Fleetwooda Maca: směs současné a klasické hudby, základ jakékoliv průměrné sbírky gramofonových desek.
Nikdo se na ně nedívá - možná právě proto, že jsou jenom pro dekoraci a některé jsou tak vysoko na zdi, že se na ně nedá dosáhnout.
Je to čistě „vinylový trik“.
Ale protože jakákoliv přitažlivost k němu by mohla znamenat víc peněz pro odvětví a poslat několik zákazníků do hlubin Soho pro další, není moc na co si stěžovat.
Není žádným překvapením, že demografická oblast, kde je pravděpodobněji víc času a peněz než v ostatních oblastech, je také tou, kde se nejvíce utrácí za nejluxusnější zboží, jakým vinyl určitě je.
Ale zatímco podle mých zjištění se zdá, že výsledky YouGov jsou přesné - tedy alespoň v obchodech s gramofonovými deskami, nezohledňují velké množství sběratelek a milovníků vinylu, kteří existují ve skutečnosti, v obchodech s gramofonovými deskami a na online fórech.
Tito lidé nejspíš těžce pracují ve školách nebo v kancelářích.
Určitě netráví čtvrteční ráno potulováním se po obchodech s gramofonovými deskami na Berwick Street, procházením nahrávek a vyhýbáním se pohledu na podivného, třicetiletého falešného televizního moderátora, který se skrývá za zády nic netušících mužů středního věku.
Grónský žralok je nejdéle žijícím obratlovcem - videoreportáž
Podle vědců má grónský žralok nejdelší střední délku života ze všech obratlovců na planetě.
Julius Nielsen, který žraloky studuje, říká, že nahrávka ukazuje samici, jejíž věk je odhadován mezi 272 a 512 roky a měří pět metrů
Soud ve Francii odmítl zbourat obchody v uprchlickém táboře Džungle
Soud ve Francii zamítl příkaz úřadů v Calais k demolici desítek provizorních obchodů a restaurací v táboře Džungle, kde žijí tisíce uprchlíků.
Během soudního jednání tento týden úřady v Calais namítly, že stát by měl být možnost zrušit celkem 72 provizorních obchodů, kde lidé uvnitř tábora prodávají zboží, od cigaret po energetické nápoje, nabízejí stříhání vlasů, v provizorních restauracích prodávají čaj za 50 centů nebo základní pokrmy za několik euro.
Kancelář prefekta v Calais argumentovala tím, že místa je nutné zbourat, protože představují paralelní ekonomiku, která neplatí daně, a protože znamenají nebezpečí vzniku požáru a zdravotní rizika.
Humanitární organizace u soudu uvedly, že obchody a restaurace jsou vitální a že jídla zdarma, která nabízí státem podporovaná asociace a další skupiny, neposkytují dodatek jídla pro rostoucí počty uprchlíků v táboře.
Sporné provizorní obchody a restaurace často poskytují přístřeší a jídlo zdarma lidem v nouzi.
Soud v Lille rozhodl, že neexistuje žádný právní základ, který by lidem zabraňoval 72 provizorních obchodů provozovat, ale uvedl, že námitky prefekta Calais jsou „zcela pochopitelné“.
Soudce Jean-François Molla řekl, že prodejny potravin, kavárny a restaurace mají mnohem větší roli než pouhé podávání jídla lidem, kteří „žijí v mimořádně zoufalých podmínkách.“
Řekl, že prostory poskytují klidná místa k setkávání uprchlíků a dobrovolníků.
Jedním z míst, kterému hrozila demolice, byla kavárna v táboře, Jungle Book Kids, kterou provozuje nezisková organizace a která denně nabízí 200 jídel, hodiny angličtiny a francouzštiny a azylové poradenství pro stovky ohrožených nezletilých osob bez doprovodu v táboře.
Petici na ochranu „dětské“ kavárny podepsalo více než 170 000 lidí.
Guardian obdržel dopis, podle kterého by zavření kavárny „bylo pro tyto děti katastrofou, některým z nich je i jenom 8 let.“
Charitativní organizace Help Refugess a L'Auberge des Migrants v pátek odhadly, že počty uprchlíků v táboře po strmém nárůstu příchozích během léta vzrostly na více než 9 000 - což je doposud vůbec nejvíc za celou dobu.
Myslel si, že je mrtvej.
Ulč křísí sebe i volejbalové Ústí.
"Od března jsem mohl normálně trénovat," hlásil se na startu letní přípravy v plné síle.
Co vám bylo?
Měl jsem oboustrannou plicní embolii, pak kvůli tomu i problémy se srdcem.
Protože když jsem byl na univerziádě v Koreji, nevěděl jsem, že mám nějaké problémy s krví.
Takže potíže způsobil dlouhý let do Asie?
Dva roky jsem měl v lýtku sraženinu a nevěděl jsem o tom.
Bolelo mě to, nikdo mi nic nenašel.
Pak se sraženina dostala nahoru.
V lýtku je poničená žíla, ta bude bolet pořád, hlavně když se maká anebo se mění počasí.
Ale nic, co by mě limitovalo, spíš estetická věc.
Měl jste obavy o život?
Měl.
Minulý rok na letním turnaji v Dřevěnicích jsem nevěděl, že embolii mám, a už jsem se tam nemohl vůbec hýbat.
Večer jsem zvracel krev.
Doktoři mi říkali, že to je něco úplně jiného, já byl ještě pět dní úplně vyřízenej.
Fakt jsem si v Dřevěnicích myslel, že jsem mrtvej, i moje přítelkyně a rodina.
Už jsem se viděl někde jinde.
Jak jste se s tím srovnal?
Asi jsem si to prožít musel, teď už to půjde jen nahoru.
Vím, že mám nějaké problémy s krví, že se musím víc hlídat, když někam poletím.
Ale dá se s tím dělat všechno.
Akorát když jsem se chtěl loni hned vrátit do přípravy Příbrami, objevily se ještě problémy se srdcem.
Teď je už všechno v pohodě.
Od března jsem se kondičně připravoval sám doma, abych byl schopný zase hrát.
Zaklepu to, fyzicky jsem na tom líp než předtím.
Co od Ústí očekáváte?
Těším se, parta vypadá dobře, většinu kluků znám.
Jsem zvědavý na další dva cizince, kteří přijdou.
Snad si sedneme lidsky, aby nám to dohromady pasovalo.
Zvednete Ústí?
Mělo pověst otloukánka, ale každá sezona je jiná.
Brno před dvěma lety bylo osmé, teď skončilo druhé.
V Ústí je nový tým, zůstalo jen pár hráčů.
Bylo poslední v extralize, takže je velký prostor ke zlepšování.
Jak ho využijeme, je na nás.
Uvidíme po prvních kolech, kdo bude otloukánek, my snad ne.
Je zárukou úspěchu kouč Brom?
Už je zkušený a zažil toho hodně, bude pomýšlet na lepší než poslední místo.
Ale můj příchod s tím jeho nesouvisel, já se domluvil dřív.
Ve hře byli i jiní trenéři, s jedním jsem velký kamarád a bylo dohodnuto, že tady bude působit.
Jméno říkat nebudu.
Nakonec přišel pan Brom a já jsem rád.
Má velké jméno, byl v dobrých klubech, trénuje spoustu desítek let, je bývalý dobrý hráč.
Posune nás nahoru.
Co přinesete vy?
Tenhle tým bude bojovat, což je moje pozice.
Já rád bojuju, rád hecuju a rád dostávám příležitost v ne tak špičkovém týmu.
Byl jsem dva roky v Příbrami, Ústí je ale větší výzva, než být hned v šestém týmu, protože se začíná od spodku.
Zmínil jste cizince, v Ústí už trénuje Australan Boehm.
Jak vypadá?
Já ho shodou okolností znám, na univerziádě jsme hráli proti sobě ve skupině.
A párkrát jsme se tam spolu bavili, občas jsme spolu seděli večer po zápasech, takže už se známe i kamarádsky.
My je porazili 3:1, hned jsem mu to na startu letní přípravy v Ústí nasypal.
Má slovenskou přítelkyni, je sympaťák.
Ještě dorazí Američan Nadazdin a Brazilec Ze.
Víte o nich něco?
S Američanem jsem si psal, vypadá jako fajn kluk, Brazilec kdoví, jak bude umět anglicky.
Vy jste Američana kontaktoval?
Připadalo mi to jako dobrý nápad.
Jsem nahrávač, tedy ten, kdo tvoří, tak bych měl se všemi komunikovat.
Hned jsem zjišťoval, co to je za hráče, našel jsem si na internetu, jak hraje, viděl jsem nějaká videa.
Jevil se celkem v pohodě, kluk skáče, vysoký je.
Na Facebooku jsme si napsali pár zpráv, zdál se jako vtipálek, zapadne k nám.
Jak se těšíte na pozici nahrávačské jedničky?
Nechtěl jsem vzít nic jiného.
Přece jen mi bude čtyřiadvacet a nemám povahu na to jít střídat.
Radši jsem v centru dění, radši si tým vedu já, než aby ho vedl někdo jiný.
Asi bych už nechtěl hrát, kdybych měl být jako druhý nahrávač a věnovat se tomu na plný čas. Když se něco nedělá naplno, stojí to za prd.
Kolikrát jste byl jedničkou?
Půlrok v Příbrami, když to nešlo Kustovi jako kapitánovi, zranil se, pak byly problémy s penězi a on odešel.
Od té doby jsme stoupali nahoru a já hrál pořád.
V Brně, jehož jsem odchovanec, jsem střídal jedničku a dvojku.
Výborný rok byl ve Starém Městě, po něm jsem měl hodně nabídek a vybral si právě Příbram.
Odtamtud mě chtěly Budějovice, já zůstal, ale sezonu jsem kvůli té embolii nedokončil.
Teď je to nový začátek.
Zlato číslo 22.
Krátká polohovka zůstává Phelpsovou doménou.
"Být znovu na stupních vítězů a slyšet hymnu je sladké jako vždycky," smál se Phelps a přitom měl znovu oči plné slz.
Jeho snoubenka i matka opět jásaly v hledišti, syn Boomer tentokrát poklidně spal se sluchátky na uších.
Prožívám neskutečný týden na závěr kariéry.
Je to šílené - před 20 lety jsem začal závodně plavat a za pár hodin bude po všem, řekl dojatě.
Ve finále za Phelpsem o bezmála dvě sekundy zaostal stříbrný Japonec Kosuke Hagino, který vyhrál dlouhou polohovku.
Bronz získal Číňan Wang Šun, bronzový medailista v této disciplíně z loňského mistrovství světa.
Po Alu Oerterovi (disk) a Carlu Lewisovi (dálka) je Michael Phelps třetím sportovcem, který ovládl stejnou disciplínu na čtyřech hrách za sebou.
Po většinu závodu se s Phelpsem drželi v čele další Američan Ryan Lochte a domácí Thiago Perreira.
Zatímco obhájce zlata v závěrečné kraulařské padesátce nasadil k drtivému finiši, oni se propadli mimo medailové pozice.
Americký superhrdina bude mít v Riu ještě minimálně jednu šanci na rozšíření své unikátní medailové sbírky.
Krátce po slavnostním vyhlášení polohovky postoupil do finále závodu na 100 metrů motýlek.
Legendu nemohl zastínit ani krajan Ryan Murphy, jenž získal znakařský double - po stovce vyhrál v Riu i dvojnásobnou trať.
Ve finále za sebou nechal o 37 setin australského plavce Mitchella Larkina, třetí skončil Rus Jevgenij Rylov.
Zatímco z loňského mistrovství světa má Murphy jen páté místo ze dvoustovky, v Riu se stal znakařským králem.
Z pomyslného trůnu sesadil Larkina, jemuž se stejný double podařil právě na loňském světovém šampionátu.
Na olympiádě ale získal medaili jen teď.
Na kraulařské stovce se o zlato podělily Kanaďanka Penny Oleksiaková a Američanka Simone Manuelová.
Pro šestnáctiletou Oleksiakovou to byla čtvrtá medaile na těchto hrách, pro Manuelovou druhá po stříbru ze štafety.
Plavecké zlato získala na OH jako první Afroameričanka v historii.
Věřím, že můžu být inspirací pro ostatní.
Tahle medaile je pro všechny, kteří přijdou po mně, sport se pro ně stane láskou a dostanou se až tam, kam já, řekla dojatá Manuelová.
Třetí byla Švédka Sarah Sjöströmová, která v Riu ve světovém rekordu vyhrála závod na 100 metrů motýlek a má ještě stříbro z kraulařské dvoustovky.
Až šestá skončila světová rekordmanka Australanka Cate Campbellová.
Prsařskou dvoustovku vyhrála Japonka Rie Kanetová, pro kterou je to v sedmadvaceti letech první olympijská medaile.
Nemá žádný cenný kov ani z mistrovství světa, jejím maximem bylo čtvrté místo v této disciplíně v roce 2013.
Druhé stříbro v Riu získala Ruska Julija Jefimovová, která se kvůli startu na hrách navzdory dopingové minulosti potýká s nevraživostí diváků i soupeřek.
Jednou jsem udělala velkou chybu.
Ale vyhrála jsem u soudu a nevím, proč bych měla na tyto otázky pořád odpovídat.
Jsem z toho strašně unavená, řekla ruská plavkyně.
Právo startu v Riu si vymohla až u zvláštního panelu sportovní arbitráže CAS těsně před začátkem her.
Zabývali se mým odvoláním a já vyhrála.
Jestli se to někomu líbí nebo ne, nebo jestli má jiný názor, ať se obrátí na arbitrážní soud, dodala.
Hermannová: Zklamání, mohly jsme vyhrát.
A start o půlnoci?
To nepamatuju.
Češky zažily zvláštní den.
Teprve necelou hodinu před zápasem se dozvěděly, proti komu nastoupí.
Musely bleskově zvládnout taktickou přípravu.
A pak, v netradičním čase, začaly zápas na malém kurtu číslo 1.
První set nezačaly dobře, pak dotáhly náskok soupeřek, ale za stavu 19:19 nezvládly koncovku.
Ve druhém byly jasně lepší a srovnaly, avšak rozhodující tie-break jim nevyšel.
Především řada pokažených servisů znamenala prohru 10:15 a loučení s olympijským turnajem.
"Mohly jsme Rusky porazit," litovala Hermannová.
Jak byste zhodnotily zápas?
Hermannová: Po nešťastném startu, než jsem se rozehrála, tak jsme se krásně dostaly do hry.
V koncovce mi v posledním balonu uletěl příjem, na který jsem si předtím zvykla.
Ztratily jsme tím set, což bylo klíčové.
V dalším setu jsme na ně nastoupily s přehledem na hřišti, jinou obranou a zatlačily jsme na servisu.
V tie-breaku bylo strašně zkažených podání, tam jsme ubraly po téhle stránce.
Bylo to zklamání, protože jsme mohly Rusky porazit.
Sluková: Škoda začátku prvního setu, tam nám to uteklo.
Dokázaly jsme to stáhnout, ale bodíky nám chyběly.
Druhý set byl super a ve třetím rozhodoval servis.
Udělaly jsme moc chyb.
Darovaly jsme jim pět bodů a o těch pět to bylo, tam jsme hodně zaváhaly.
Je to škoda, protože Rusky byly hratelné.
Jak se vám hrálo na malém dvorci číslo 1?
Sluková: Podobné jako v Číně na vedlejších dvorcích.
Prostředí a atmosféra byly jiné.
Byla jedna hodina v noci, úplné ticho, hudba nehrála, nikde nic.
To byl rozdíl oproti centru.
Takové podmínky bychom si nevybraly, ale vybírat si nemůžeme.
Jaká byla příprava na zápas, když jste zjistily jména soupeřek hodinu před zápasem?
Hermannová: Byla zvláštní.
Začaly jsme se rozcvičovat na zápas, aniž bychom věděly protihráčky, takže jsme nemohly udělat taktickou přípravu jako na ostatní týmy.
Ale Simon (kouč Nausch) si přichystal taktiku skoro na všechny možnosti, které tam byly.
Měl připraveno spoustu papírů s taktikou, takže po téhle stránce jsme byly docela dobře připravené.
Pamatujete, že byste někdy začínaly zápas o půlnoci?
Hermannová: Asi ne.
Hrály jsme v půl jedenácté, ale ve dvanáct ne.
Blok Rusky Birlovové v předkole play-off na OH v Riu.
Plážové volejbalistky Markéta Sluková a Barbora Hermannová v objetí v předkole play-off na OH v Riu.
Bylo to nepříjemné?
Sluková: Tím, že jsme hrály už poslední dva zápasy ve skupině od deseti, tak jsme měly režim posunutý už dříve.
Tohle bylo ještě o dvě hodiny víc.
Je to zvláštní, nedovedu si představit, že jiný sport má sportovce, kteří musí podávat svůj nejlepší výkon ve dvanáct hodin.
Ale myslím, že jsme se připravily nejlépe, jak jsme mohly.
Věděly jsme, že to tak bude, ale úplně typické to není a asi to nebude má oblíbená doba na hraní.
Jak hodnotíte olympijskou zkušenost?
Hermannová: Jelikož byl postup ze skupiny náš cíl, tak je to na jednu stranu v pořádku, dobré.
Zvládly jsme, co jsme si řekly.
Ale teď po zápase jsem smutná.
Sluková: Já se z toho vyspím a od zítřka budu na olympijský turnaj vzpomínat jen pozitivně.
Velký bratr je tady, přichází první šmírovací SIM.
Neuniknete jí.
Nová pravidla se mají vztahovat na všechny osoby bez thajského pasu, které se při pobytu v Thajsku rozhodnou pořídit SIM některého z místních operátorů.
Tedy nejen na turisty, ale také na osoby s dlouhodobými vízy, které v Thajsku například pracují či tam uzavřely manželství.
Generální tajemník Úřadu národního vysílání a telekomunikační komise Takorn Tantasith totiž informoval, že nebudou existovat žádné výjimky.
Plán prodeje SIM určených výhradně cizincům představil národní telekomunikační regulátor začátkem srpna.
Nové opatření, které umožní sledování jejich polohy, hodlají úřady zavést do šesti měsíců.
Podle Tantasitha jde o prostředek k zachování národní bezpečnosti, který umožní řešit trestnou činnost páchanou právě cizinci.
Takzvané turistické SIM mají navíc pomoci odhalovat i osoby, které překračují povolenou délku pobytu.
U prodejců by se tak do půl roku měly po boku SIM určeným výhradně Thajcům objevit i speciální SIM pro cizince.
Odlišností bude právě funkce sledování, která bude u karet určených osobám bez thajského pasu permanentně zapnutá.
Nebude ji možné vypnout.
"Tato funkce u SIM pro Thajce není, protože ty můžeme vždy snadno sledovat," doplnil Tantasith.
Nutno dodat, že v Thajsku nejsou předplacenky anonymní jako v Česku.
Prodejce vyžaduje doklad totožnosti.
Na druhou stranu několik let jeden z operátorů rozdával zdarma startovací SIM turistům na letištích.
Ty tak byly plně anonymní.
Zavedení stejného opatření jako Thajsko zvažuje i deset telekomunikačních regulátorů z dalších asijských zemí zahrnujících například Malajsii či Singapur.
I v nich v současnosti platí povinná registrace SIM, nicméně legální využití sledovacího systému možné není.
Chystané opatření nicméně neznamená pro cizince povinnost pořídit si při vstupu do země SIM místního operátora.
Mohou samozřejmě využívat roamingové služby s vlastní domovskou SIM, v takovém případě na ně budou thajské úřady krátké.
Operátoři dané země totiž po překročení hranice, tedy po přihlášení SIM k jejich síti, znají pouze relevantní síťové informace.
Znají tedy telefonní číslo, nikoli však informace o vlastníkovi.
Nicméně rozdíl roamingových cen oproti sazbám místních operátorů je natolik propastný, že se i většina turistů v průběhu svého pobytu v Thajsku začne poohlížet po místních SIM.
Snaha úřadů mít dohled nad pohybem cizinců se ze strany cizinců žijících v Thajsku legálně dočkala okamžité kritiky.
Tantasith situaci uklidňuje a v souvislosti s ochranou soukromí chystaný systém přirovnává k povinnosti poskytnutí rezidenční adresy v imigračních dokumentech.
Policie bude navíc v případě potřeby sledování konkrétní osoby potřebovat soudní příkaz.
Za jakékoli zneužití systému bude hrozit blíže neurčený trest.
"Bude-li poskytovatel služeb sledovat polohu SIM bez soudního příkazu, bude obviněn z trestného činu," dodal Tantasith.
Systém by měl navíc maximalizovat i využití předplacených karet.
Zatímco v současnosti dojde k recyklaci konkrétního čísla až po uplynutí 90denní lhůty, po níž se daná SIM nepřihlásila k síti, tak nově by mohlo v případě opuštění Thajska dojít k obnově čísla již po patnácti dnech.
Luxusní byt v novostavbě na Vinohradech má bazén i vířivku na terase.
Proč jste si vybrali byt v novostavbě?
Hledali jsme bezstarostný byt, kde většinu péče o nemovitost obstará správce.
Podmínkou byl dostatek parkovacích míst a výtah v domě, což v podstatě diskvalifikovalo starší zástavbu.
Nemluvě o problematické akustice ve starých domech, problémech s houpáním podlahy, vysoké energetické náročnosti a podobně.
Podmínkou byly také velké terasy, což stará zástavba není schopná nabídnout.
Další zajímavé návštěvy najdete v časopise Moderní byt.
Celý interiér pro vás navrhla architektka Lenka Langerová se svou kolegyní Kamilou Polákovou ze studia Artiga.
Proč jste oslovili právě je?
Doporučili byste spolupráci s odborníkem každému?
Spolupráci s architektem bychom doporučili každému, pokud navrhuje byt od počátku, jde totiž o velmi komplexní technický proces.
Druhá rovina je samotný design interiéru: designéři mají podstatně lepší představu o škále možných materiálů a na základě přání klienta jsou schopni interiér vhodně sladit.
S architektkou Lenkou Langerovou jsme spolupracovali už na našem horském apartmánu, tehdy na bázi osobního doporučení jiného klienta, a vzhledem k tomu, že vše dobře fungovalo, byla pro nás jasná volba i při rekonstrukci našeho nového bytu na Vinohradech.
Jaké byly vaše praktické a estetické požadavky?
Přáli jsme si velkorysý společensko-obytný prostor s odpovídajícím zázemím pro čtyřčlennou rodinu pojatý jako moderní, ale nikoliv chladný interiér.
Prioritou bylo docílit propojení bytu s terasami a realizovat inteligentní ovládání domácnosti.
A samozřejmě bylo třeba uhlídat kvalitu provedení.
Nechali jste vše na odbornících, nebo jste sami zasahovali do konečné podoby interiéru?
Veškeré návrhy včetně technických výkresů a vzorků materiálů jsme schvalovali, nicméně návrh vždy vzešel od architektů.
Na začátku jsme si stanovili, co od designu očekáváme, a ukázali některé prvky interiéru, které bychom do návrhu rádi začlenili, například koberce nebo obrazy.
Myslím, že právě naše sbírka převážně českých autorů zahrnující díla Karla Malicha, Karla Vysušila, Václava Špály nebo Otto Gutfreunda architektce pomohla orientovat se v našem vkusu.
Také kombinace černé, bílé a ořechového dřeva byla nápadem architektky stejně jako jednotlivé kusy nábytku, stěny, podlaha, osvětlení, koberce, textilie, umění atd. To, zda vše dohromady ladí, jsme pak společně ověřovali pomocí vizualizací.
Objevily se při realizaci nějaké komplikace, kvůli kterým jste se museli původních nápadů vzdát, nebo naopak přistoupit na nové?
Snad jen v úvodní fázi projektu, když jsme přišli na stavbu v okamžiku, kdy bylo poprvé možné vystoupat do výšky našeho podlaží, a zjistili, že výhledy, které jsme si plánovali, ve skutečnosti stíní okolní budovy.
Tehdy jsme dispozice doslova přes noc od základu změnili.
Na kuchyňské lince i na obložení krbové stěny byla použita žula.
V interiéru pak převládají dřevěné povrchy doplněné kůží, například na čalounění jídelních a barových židlích Norma od Arperu.
Jak byste interiér charakterizovali?
Chystáte tu nějaké změny nebo je něco, co byste si dnes přáli mít jinak?
Mám za to, že jde o moderní vzdušný interiér, který především plní svůj účel.
Změny nechystáme, většina úprav po nastěhování se odehrála v rovině stínění a zabydlení teras.
Snad jediná výtka je k podlaze, kdy se nám ořechové dřevo ukazuje jako příliš choulostivé do domácnosti se psem.
Slovo architektek, Ing. arch. Lenka Langerová a MgA. Kamila Hornychová, autorky realizace.
Byt je v posledním patře novostavby, proto bylo možné v rámci stavby provést kompletně nové dispoziční řešení a několik dalších úprav.
Pro interiér je důležitým prvkem umístění světlovodů do stropu chodby a hlavní toalety.
Tím jsme dostali denní světlo do tmavších prostor bytu.
Také přímý vstup z hlavní koupelny na střešní terasu k bazénu od USSPA je jedna ze stavebních úprav, která byla velmi přínosná pro funkci celého bytu.
Součástí je také bazén a vířivka.
V porovnání s Francouzi negativní nejste, říká muslimka žijící v Praze.
Pocházíte z Francie.
Kde všude jste žila předtím, než jste se přestěhovala do Prahy?
Moji rodiče jsou původem z Alžírska.
Já jsem se narodila na jihu Francie, kousek od španělských hranic.
Docela dost jsem se stěhovala.
Žila jsem v Toulouse, Lyonu i Marseille.
Ve Francii jsem vystudovala žurnalistiku, díky čemuž jsem se pak dostala k práci v jednom magazínu.
Proč jste se tedy rozhodla odstěhovat ze země?
Začínala jsem mít pocit, že se ve Francii dusím.
Už jsem tam prostě nechtěla bydlet.
Hlavně kvůli atmosféře mezi lidmi.
Přišlo mi, že je každý Francouz hrozně negativní.
Lidé ve Francii jsou negativně naladění obecně, ale poslední dobou se to ještě zhoršilo.
To je zajímavé, že zmiňujete zrovna negativismus.
Někteří lidé totiž takhle hodnotí českou povahu.
Věřte mi, v porovnání s Francouzi negativní nejste.
Některým lidem to tak možná nepřijde, když přijedou do Francie, protože to jako turisté tolik nevnímají.
Ale pro mě to bylo příliš.
Velkým tématem jsou třeba peníze.
Lidé mají pocit, že mají málo peněz, přitom minimální mzda ve Francii je patnáct set eur, což je podle mě dost.
Teď je tu navíc problém s chováním lidí vůči muslimům.
To je pro mě úplně nepochopitelné.
Například v ulici, ve které jsem žila, se na mě můj nemuslimský soused začal dívat skrz prsty jen proto, že jsem muslimka.
Jako kdybych byla nějaké zlo.
Proto jsem se ve Francii necítila dobře.
Moje rodina tam ale zůstala.
Takže jste se rozhodla odejít do jiné země.
Proč jste si vybrala zrovna Českou republiku?
Hledala jsem práci v podstatě kdekoliv jinde a narazila jsem na volné místo u společnosti Air France tady v Praze.
Přiznám se, že jsem z počátku Prahu vůbec neznala.
O České republice jsem něco věděla, tatínek mi dokonce vyprávěl o tom, co se dělo v Československu, ale vůbec jsem nevěděla, co od Prahy očekávat.
Teď už jsem tu tři roky a nedovedu si představit, že bych tady nebydlela.
Byl to velký rozdíl, když jste se přestěhovala z Francie do Prahy?
Hlavně kvůli úplně jiné atmosféře.
Možná je to tím, že nemluvím česky, takže nedokážu zachytit nějaké negativní reakce nebo nadávky, ale mám pocit, že jsou tady lidé svobodnější.
Že můžu dělat cokoliv, oblékat se jakkoliv a nikdo mě nebude soudit.
Ve Francii se na vás pořád někdo nepříjemně dívá, třeba když máte zvláštní oblečení a podobně.
V Praze jsem si začala připadat opravdu svobodná.
Pražané se o takové věci podle mě nestarají.
Kde pracujete teď?
Po zaměstnání v Air France jsem chvíli pracovala pro jeden cestovní web.
Potom jsme ještě s jedním kamarádem založili webové stránky, na kterých lidé nabízejí a hledají sdílené bydlení.
Zatím působíme jen v Praze, ale chtěli bychom to rozšířit na celou střední Evropu.
Máte v Praze nějaké české přátele?
Mám tady dva velmi blízké kamarády, kteří jsou Češi z poloviny, a ještě dvě kamarádky Češky.
Musím říct, že další specifikum Čechů je v tom, že si zpočátku více drží odstup.
Nepustí si někoho hned tak k tělu.
To je docela rozdíl oproti místu, kde jsem vyrůstala.
Na jihu se všichni objímají a líbají na tvář.
Tady je to jiné, ale chápu, že je to kulturní záležitost, tak se snažím adaptovat.
Zmiňovala jste, že nemluvíte česky.
Je pro vás jazyková bariéra problém?
Naopak to mám v Praze dost jednoduché, protože snad každý tady mluví anglicky.
Dokonce i ve večerkách nebo v potravinách.
Chtěla bych se naučit česky, ale nemám tolik času.
A tím, že každý dovede alespoň trochu komunikovat v angličtině, nemám takovou potřebu se jazyk rychle naučit.
A pokaždé když mám nějaký problém, tak se najde někdo, kdo mi pomůže.
Setkala jste se i s nějakými negativními reakcemi?
Třeba kvůli tomu, že jste muslimka?
V podstatě ne.
Možná je to také tím, že pracuji v mezinárodním prostředí, které je více tolerantní.
Jedna zkušenost mě napadá.
Moje vedoucí, Češka, mi jednou vyprávěla o francouzském fotbalovém týmu a pronesla něco ve smyslu: Vždyť to nejsou Francouzi, ale Afričané.
To se mě docela dotklo.
Ale že by měl někdo problém s tím, že jsem muslimka, to se mi ještě nestalo.
A to i přesto, že mě kolega jednou upozorňoval na nějaké protimuslimské demonstrace.
Říkal, ať nechodím do centra, že mi tam budou nadávat.
Protimuslimské demonstrace zčásti souvisí s teroristickými útoky.
Jak na vás současná situace působí?
Bojíte se třeba, že se něco podobného jako v Paříži, Nice nebo Bruselu může stát i v Praze?
V Praze si připadám bezpečně.
Ale problém je, že se v dnešní době může stát cokoliv kdekoliv.
Ještě donedávna jsem si třeba nedokázala představit, že by se něco takového stalo ve Francii.
A netýká se to jen muslimů.
Islám navíc násilí vůbec neuznává.
Pro mě lidé, kteří zabíjejí, nejsou muslimové.
Korán říká, že člověk nemá právo zabíjet, protože není Bůh.
Jak vnímáte to, když se teroristé zaštiťují vaší vírou?
Je to hodně těžké.
Cítím stud a vinu, i když bych se tak vůbec cítit neměla.
Snažím se ty zprávy o násilí moc nesledovat, ale pokaždé když si něco přečtu, tak mám potřebu se omlouvat za něco, co vlastně není moje vina.
Jsem úplně jiný člověk, tak proč bych se měla omlouvat za teroristy?
Sešli jsme se na náměstí Jiřího z Poděbrad.
Ve středu tu čeští muslimové spolu s křesťany demonstrovali proti násilí.
Zaregistrovala jste to?
O tom jsem nevěděla.
Ale chápu to tak, že ti lidé cítí potřebu dokazovat, že s násilím nesouhlasí.
Já si nemyslím, že by něco takového museli dělat.
Proč by měli cítit vinu za něco, co nezpůsobili?
Setkáváte se v Praze i s jinými muslimy?
Moji spolupracovníci jsou například z Egypta a dalších muslimských zemí.
Jsou trochu víc nábožensky založení než já, takže máme někdy docela divoké diskuse o islámu, protože ho každý vnímáme trochu jinak.
Já pocházím z Francie, takže jsem si prošla jiným vzděláním, oni se třeba islám učili na škole.
Máme rozdílné přístupy, ale vzájemně se respektujeme.
Lidé si islám někdy spojují s podřízeným postavením ženy.
Jak to vnímáte vy?
Já si podřízeně v žádném případě nepřipadám.
Spíše naopak.
Jsem žena, mám sílu.
Souvisí s tím i to, že nenosíte žádnou pokrývku hlavy.
Například hidžáb?
A podepisuje se na tom hlavně způsob, jakým jsem byla vychována.
Moje maminka je například opravdu zásadová muslimka.
Modlí se pětkrát denně, ale šátek prostě nenosí.
Vždycky mě učila, že víra je čistě osobní věc.
Záleží na každém, jak si ji interpretuje.
Když si člověk přečte Korán, měl by si na ty věci udělat vlastní názor.
Takže když jsem si v Koránu přečetla pasáž, která říká, že Bůh řekl Prorokovi, aby schoval své ženy před zraky ostatních, řekla jsem si: Já nejsem Prorokova žena, tak proč bych se měla schovávat?
Na druhou stranu to respektuji, a když přicestuji třeba do Íránu nebo Saúdské Arábie, kde šátky vyžadují, tak si ho vezmu.
Plánujete v Praze zůstat?
Zatím ano.
Nikde jinde jsem se necítila tak dobře.
Chvíli jsem přemýšlela o Polsku, ale v Praze je mi skvěle.
Dokonce si dovedu představit i to, že bych tady vychovávala vlastní děti.
Praha je pro to podle mě ideální město.
Čeští muslimové spolu s křesťany demonstrovali proti násilí.
Jachtařku Kozelskou Fenclovou vítr v Riu zavál na postupové příčky.
Páteční jízdy na moři v brazilském Riu de Janiero vyšly české jachtařce Veronice Kozelské Fenclové.
Ve třídě Laser Radial se posunula před závěrečnými dvěma rozjížďkami na desáté místo.
To by Češce zajistilo účast ve finálové jízdě.
Balíčky posbíráte jako pokémony.
Chtějí konkurovat přepravcům.
Za nápadem využít už naplánované cesty pro převoz zásilek stojí televizní režisér Matěj Liška a manažer pražského hudebního klubu Marek Greger.
S myšlenkou vdechli život trojici aplikací s rozdílným geografickým dosahem.
Vnitrostátní aplikaci Převezu jsme spustili v květnu.
V tuto chvíli je v ní nahraných tisíc měst a síť budeme rozšiřovat.
V Česku se to nejprve chceme naučit, než se víc zaměříme i na zahraničí, říká v rozhovoru pro iDNES.cz jednačtyřicetiletý manažer.
Jak aplikace Převezu funguje a kdo z ní může mít užitek?
Stáhnete si ji a zdarma se zaregistrujete.
Pak můžete zadat trasu a údaje, jak velký balík zvládnete převézt a kolik za to chcete.
Někdo zase v ten den třeba poptává převoz.
Když vyhovuje trasa i čas doručení, spáruje se to a oběma přijde vzájemná notifikace.
V tu chvíli se otevře chat, kde si dvojice domluví předání.
Kolik lidí by se podle vás odhadem muselo zaregistrovat, aby si každý balíček vždy našel svého kurýra?
Ideální stav neznám, nedokážu odhadnout, kolik zaregistrovaných a kolik cest je potřeba, aby bylo pokrytí zcela optimální a každá nabídka se spárovala s poptávkou.
Na hlavních tazích už to funguje a je to logicky jednodušší než třeba na cestě mezi vesnicemi.
Čím víc lidí, tím větší potenciál rychlosti a přesnosti.
Lidé si taky zatím budují důvěru a zjišťují, že s balíčkem nikdo neuteče.
Zatím jste takový případ nemuseli řešit?
Kolik uživatelů má služba po dvou měsících od spuštění?
Momentálně máme asi 5 až 6 tisíc lidí, kteří vytvářejí cesty.
To považujeme za úspěch a věříme, že se budou nabalovat další.
Nehrozí třeba, že bude odesilatel čekat moc dlouho?
Doufáme, že budeme konkurencí pro velké konglomeráty už jen z toho důvodu, že jsme schopni věc doručit třeba ještě týž den a za zlomek ceny.
U velké společnosti za doručení do dvou hodin zaplatíte několik tisíc.
Tady zaplatíte třeba stovku i méně, protože to je cesta, kterou někdo už podniká.
Měly by se tradiční přepravci do budoucna obávat možného úbytku zákazníků?
Doufáme, že to tak bude.
Trh má obrovský potenciál, krmí se tady obrovští nadnárodní přepravci, stejně jako obchodní řetězce, kde začali všichni nakupovat a postupně zjistili, že kvalita neodpovídá tomu, za co platí.
Nikdo nechce najít ve schránce lísteček se vzkazem, že si má zásilku vyzvednout na pobočce, a to nejdřív ten den po 19. hodině.
Tou dobou jsem přece balík už šest hodin potřeboval a čekal jsem doma, protože to bylo důležité.
Chceme lepší, rychlejší a funkční službu, která nebude nikoho štvát a vyšle konkurenci signál, ať se snaží.
Marek Greger (41) a Matěj Liška (39).
Ani jeden nikdy nepůsobil v oboru informačních technologií.
Marek Greger pracuje jako manažer hudebního klubu, Matěj Liška jako televizní režisér.
V roce 2014 začali připravovat aplikaci Shippansee LTD, která využívá k přepravě balíčků již naplánované cesty mezi světovými metropolemi, především letadlem.
V roce 2015 zadali projekt ke zpracování společnosti, která vytvářela aplikace třeba pro MALL.cz, Jobs.cz nebo ČSFD.
Programování trvalo tři čtvrtě roku a aplikaci uvedli na trh v březnu 2016.
Aplikaci Převezu začali vyvíjet v prosinci minulého roku a vydali letos v květnu.
Jedná se o lokální verzi Shippansee upravenou pro český trh.
Aplikaci Mesíkem a Mesíkem Profi vyvíjeli od letošního ledna a zpřístupnili uživatelům na konci července 2016.
Záměr bylo od začátku udělat všechny tyto aplikace, které se jednoho dne spojí v jednu.
V Česku chtějí aplikaci doladit a pak se ve spolupráci se silným investorem více zaměřit i na celosvětový trh.
Sdílená ekonomika je v poslední době tématem a tohle je služba typu AirBnB či Uberu.
Nemáte obavy z působení v oblasti, o níž zatím nikdo moc nedokáže říct, kde je hranice sdílení a kde šedé ekonomiky?
Je to stejné, akorát jiný produkt.
Je nám jasné, že pokud to bude mít úspěch a půjdeme s tím nahoru, budeme dalším trnem v oku skrze šedou ekonomiku.
Ale přestože někdo ušetří a někdo vydělá, není záměrem obcházet finanční úřady a daňové kontroly.
Každý uživatel, ať na jedné nebo druhé straně, bude vybízen k tomu, aby danil své příjmy, pokud si z toho příjmy udělá.
Z čeho soudíte, že služba má tak velký potenciál?
Odesílatel ušetří a převozce vydělá, respektive sníží si náklady na cestu.
V tom je ta silná myšlenka, která spojuje zájem na obou stranách.
V době sociálních sítí, které lidi rozdělují, bychom chtěli, aby tahle naopak sbližovala.
Mohou vznikat hezké příběhy, lidé mají radost z toho, že někomu pomohli a budou si o tom vyprávět.
Třeba vám někdo doveze zapomenuté brýle, klíče nebo prášky.
Lidem podle mého už delší dobu chybí osobní přístup, o téhle aplikaci říkáme, že je to služba lidí lidem.
Jak tedy zaručujete, že kurýr s balíčkem neprchne?
Každý uživatel aplikace spolu s registrací naskenuje občanský průkaz a uvede bankovní spojení, platební či kreditní kartu.
To jsou kanály, které dávají službě i člověku věrohodnost.
Kurýři také sbírají hvězdičky na základě hodnocení odesílatelů.
Nabídneme i pojištění, detaily ještě ladíme.
Za nepojištěnou zásilku v případě ztráty či poškození ručí kurýr, ale nepřejímá podle trestního práva odpovědnost za obsah, pokud je uvnitř něco protizákonného a neví o tom.
Pokud ho zastaví policie a najde v uzavřeném balíčku v jeho kufru samopal nebo deset kilo hašiše, přepadá trestní odpovědnost na odesilatele.
Nehrozí zneužití citlivých dat z databáze?
Zaregistrovaní jsou v případě potřeby dohledatelní správním orgánem, který jako jediný bude mít možnost do ní nahlédnout, ani my sami nejsme schopni je vidět, data jsou proti zneužití chráněná.
Kolik peněz dostane po úspěšném dodání zásilky do ruky kurýr?
Kurýr určuje cenu a dostane celou částku, o kterou si řekne.
Odesilateli se naúčtuje několik procent navíc za zprostředkování kontaktu.
Tyto peníze jsou náš zisk, je to ale jen pár procent, protože chceme tlačit na objem.
Kurýra taky nikdo nemůže obvinit, že zásilku nedodal, když ji ve skutečnosti doručil, převzetí i doručení se ověřuje pomocí QR kódů.
Jsou nějaká omezení?
Ať už ve vztahu k velikosti či obsahu balíčku?
Převézt můžete cokoli.
Máme tři velikosti, malou jako kostku másla, střední jako plato vajec a velkou jako basu piv.
Poté už není další omezení a má-li někdo místo v autě, převeze třeba lednici.
Plus má odesílatel možnost v aplikaci balíček vyfotit, takže kurýr vidí, co se po něm chce.
Věc dokonce ani nemusíte balit, pokud vyloženě nechcete skrýt obsah.
Zapomenutou mikinu strčíte kurýrovi do ruky a je to.
Kdo přišel s nápadem a jak dlouho trvalo službu spustit?
Kamarád dostal nápad už před více než dvěma lety, tehdy jsem tomu nevěnoval moc pozornost.
Pak mi ukázal demo aplikace s nadnárodním dosahem, která cílí hlavně na cestující letadlem.
V ten moment jsem mu řekl, že nebudu hledat investora, ale sám bych se jím chtěl stát a dát do toho úspory.
Další rok trval vývoj, než jsme kvůli větší kredibilitě celého produktu založili v Londýně firmu Shippansee LTD.
Tohle ale není verze, na kterou se nyní především soustředíte.
Ne, marketing jsme zaměřili na Česko, kde se snažíme aplikaci dovychytat, protože to celé mělo porodní bolesti a pořád je co řešit a zlepšovat.
Snažíme se reagovat na zpětnou vazbu od zákazníků a zahraniční trh momentálně tolik neřešíme.
Víme, že je to běh na dlouhou trať, ale nechvátáme, chceme vytvořit opravdu dobrý produkt pro lidi.
Shippansee LTD byla základní a nejdražší aplikace, další dvě byly svým způsobem upgrade.
Převezu vzniklo, když jsme si řekli, že vnitrostátní segment může být daleko zajímavější a že se to v Česku alespoň naučíme.
Třetí aplikace Mesíkem je lokální, pro město.
Dokáže ale poslat balíček na přesnou adresu i na druhý konec světa.
Funguje pro odesílatele stejně jako Převezu, rozdíl je ale v tom, že v ní jako kurýr vidíte zásilky ve formě bodů na mapě, které jsou vám nejblíž, díky geolokátoru v mobilu.
Aplikace pro kurýry, kteří se tím chtějí živit, jsme nazvali Mesíkem Profi.
Takže si někdo může vyloženě přivydělat tím, že bude po městě balíčky vyzvedávat?
Přesně, poslední aplikaci si stáhne v Praze třeba taxikář, student, matka na rodičovské dovolené, někdo, kdo chce vytěžit cestu do práce.
Jak teď všichni blbnou s těmi pokémony, tak tohle mohou sbírat úplně stejně.
Člověk vidí, kde po městě jsou zakázky, přijede k tomu, klikne a vidí, kdy to musí být doručeno a zásilku převeze.
Je to nastavené levněji než konkurenční služby.
V tuto chvíli děláme ještě webové rozhraní, které bude stěžejní pro firmy na odesílání zásilek, na webu si o nich vyplní údaje, čili vytvoří body na mapě.
My jsme pak schopní jim využívání služby třeba každý měsíc vyfakturovat.
Projektu se nyní věnujete na plný úvazek?
Vytěžuje nás to, ale máme to normálně při zaměstnání, abychom projekt mohli uživit a rozvinout.
Neskrývá se za námi silný nadnárodní investor, jsme dva kluci, z nichž jeden měl geniální nápad a druhý do toho přiskočil s dalšími podněty a nápady.
Nyní hledáme investora dostatečně silného na to, aby s námi zvládl ukočírovat ne český trh, ale který by měl s prominutím koule jít s námi do celosvětového produktu a stát se dalším obrovským hráčem na trhu jako AirBnB a Uber.
Příběhová část Titanfall 2 má přinášet takřka zapomenutou pestrost.
To napraví druhý díl a sólo hra v něm bude podle prvních informací pestřejší než v Call of Duty.
Délka se bude pohybovat okolo standardních osmi hodin a náplň má vycházet právě z pojetí síťového zápolení v prvním dílu.
Těšit se proto lze na volnost pohybu, která kromě běhání zahrnuje i možnost využívat bojového titána.
Kromě akčních pasáží navíc hra bude obsahovat úrovně zaměřené právě na obratný pohyb.
Budou připomínat plošinovky a zahrnovat rébusy.
K jejich překonávání jsou proto zásadní kupříkladu dvojité skoky, běhání po zdech a lanový skluz.
Někdy přitom navíc bude nutné likvidovat i nepřátele.
Chybět nebudou ani mapy připomínající bludiště a úrovně se speciálními koncepty.
V jedné například bude možné zvedat i sesouvat plošiny a zavírat mohutné dveře.
Upravovat tak budete podobu bojiště.
Tempo hry by díky tomu mělo oscilovat mezi zuřivou akcí a klidnějšími momenty pro prozkoumávání neznámé planety.
Hrát budeme za pěšáka Jacka Coopera snícím o kariéře pilota.
Cooper na začátku kampaně společně s kapitánem Lastimosou ztroskotá na mimozemské planetě Typhon, kterou obývají nepřátelští vojáci.
A shovívavá k němu nebude ani tamní divočina.
Lastimosa navíc při havárii utrží smrtelné rány, a Cooper proto dostane za úkol zprovoznit kapitánova titána.
Jeho sen o kariéře pilota se tak splní dříve, než očekával.
Prvním krokem ale bude ukradení baterie nutné pro robotovu opravu.
Významné budou i hovory Coopera s titánem.
Hráčům poslouží jako zdroj informací o vojákově minulosti, zároveň však robotovou odosobněnou komunikací budou vznikat humorné momenty.
Například když titan bude suše vyjmenovávat všechna zranění, která Cooperovi hrozí při plánovaném výskoku.
První informace o kampani v Titanfall 2 přinesl server Polygon.
Výsledek navíc bude možné posoudit již za dva měsíce a Bonusweb vám po Gamescomu přinese první dojmy ze síťové hry.
Titanfall 2 vychází 28. října, a to pro PC, PlayStation 4 a Xbox One.
Značka THQ ožije, původní vydavatelství však zůstává mrtvé.
Švédská společnost Nordic mění jméno na THQ Nordic.
Po krachu vydavatelství THQ totiž v roce 2013 získala řadu jeho značek a právo na užití loga i názvu společnosti.
Nordic díky tomu vydalo například Darksiders 2 Deathnitive Edition či balík Red Faction Collection.
Pro vydavatelství navíc vzniká dalších 23 her a 13 z nich firma ještě neodhalila.
Před třiceti lety, v době, kdy jsem odcházel do důchodu, si manželka, po třiceti letech manželství, našla o dvacet let mladšího muže, našeho souseda.
Já to od začátku věděl - nejprve se o něj očividně delší dobu pokoušela, pak se dali dohromady.
Je to takový velký chlap, asi její typ, protože s podobným chodila i přede mnou.
Úplně se do něj zbláznila.
V ty první dny se jí dokonce proměnil hlas, měla takový dívčí, zamilovaný hlásek.
Ale když jsem jí řekl, že vím, co se děje, tak to zapírala.
Já to ale celé pozoroval.
On tehdy chodil z práce pravidelně v půl čtvrté, a tak ona vždy odcházela ve tři na nákup.
Každý den se snažila, aby ho alespoň viděla.
Později jsem přišel na to, že se scházejí u něj v baráku, v prádelně.
Kolikrát jsem věděl, že tam právě jsou.
Opatřil jsem si klíče, byl rozhodnutý, že je tam přistihnu.
Ale nevím proč, nakonec jsem vždy zůstal sedět doma.
Nikdy jsem tam nedokázal jít, udělat ten rozhodný krok.
Možná se mi budete smát, ale já věřím tomu, že mě manželka myšlenkově ovládala.
Brzy podle mě zjistila, že jsem ovladatelný, že budu dělat to, co ona bude chtít.
A já to skutečně dělal.
Možná jsem jen taková bačkora.
Přitom sousedky mi tehdy naznačovaly, že o tom také ví.
Já byl takový blbec, že jsem se jich nikdy nezeptal, co mám dělat.
Bál jsem se, že kdyby to všechno prasklo, tak že bude zle.
Že to v rodině na všechny dopadne, něco tušila jen dcera.
Takže já to vždy odkládal, dál a dál.
Jednou jsem ale šel za ním do bytu, že bych s něčím potřeboval v prádelně pomoc.
Šel tam se mnou a já mu řekl, že jsem dostal anonym, že se schází s mou ženou a že tomu všechno nasvědčuje.
Zeptal jsem se ho, co mi na to řekne.
On tam stál, krčil rameny, koukal do země a neřekl ani slovo.
Pak jsem také v té době jednou potkal jeho manželku na cestě z obchodu.
Řekl jsem jí to, ale ona tomu vůbec nevěřila.
Nijak na to nereagovala a také mi nic neřekla.
Nikdo mi tehdy nic neřekl.
Já jsem takový člověk, který nikdy nikam moc nechodil, který má problém se s někým seznámit, natož si najít ženskou.
Takže o rozvodu jsem ani nepřemýšlel.
Pořád jsem se spoléhal na to, že to jednoho dne skončí.
Říkal jsem si, že jí to všechno odpustím a život půjde dál.
Tak to ale nebylo.
A já se s tím vším v podstatě nikdy nevyrovnal.
Dodnes to mám v sobě.
Dříve jsem jí to dost často dával najevo, ale nakonec jsem toho pro klid nechal.
On dál žije ve vedlejším domě a já dál žiju s ní.
Jen je to spíše než moje manželka moje hospodyně.
Doma vždy všechno udělala - vařila, prala, uklízela.
Je pracovitá.
Vždy se podle mě snažila, abych neměl jiný důvod si stěžovat.
A dá se říct, že je i hodná.
Ale někdy bych ji chtěl pohladit, obejmout a ona se nenechá.
My spolu přitom chodíme na procházky a na nákup a všichni si myslí, jaké máme šťastné manželství.
Ona mi ale kdysi řekla, že mě nikdy nemilovala.
Že mě měla a má ráda, ale že mě nemilovala.
A já vidím, že jeho miluje dodnes, je to její bůh.
A mě takový život nebaví.
Už tehdy, když to začalo a já to velmi špatně nesl, jsem jí jednou řekl, že se mi nechce žít a zeptal jsem se, co by řekla tomu, kdybych to skončil.
Chtěl jsem vědět, jestli by s tím souhlasila anebo ne.
A to jsem od ní chtěl slyšet: Ano nebo ne.
Ona se ale zamyslela a nakonec řekla: "Ale vždyť je tady místa dost."
Premiér Manuel Valls chce zřídit novou Francouzskou islámskou nadaci, která by měla sloužit jako most mezi státem a jeho muslimskými obyvateli.
Po teroristických útocích stupňuje Francie boj proti radikálním islamistům a na pomoc volá vláda i místní muslimskou menšinu.
"Pokud sami muslimové nepomohou státu proti těm, kteří narušují veřejnou svobodu, bude pro Francii stále těžší zaručit svobodu jejich vyznání," řekl premiér Manuel Valls.
Ten hodlá zajistit, aby v zemi kázali pouze duchovní vzdělaní ve Francii.
Zastavit chce také financování mešit ze zahraničí, kdy s penězi často přicházejí kazatelé naočkovaní džihádem.
Do října chce premiér Valls zřídit novou Francouzskou islámskou nadaci, která by měla sloužit jako most mezi státem a jeho muslimskými obyvateli.
Nová instituce nahradí současnou Francouzskou nadaci pro islám, kterou v roce 2005 založil tehdejší premiér Dominique de Villepin.
Už tehdy měla přispět k zprůhlednění finančních toků mezi mešitami a zeměmi, které jejich výstavbu financují.
Brzy ji ale zasáhly vnitřní rozpory, a nikdy proto pořádně nefungovala.
"Je to totální neúspěch," konstatoval Valls.
V čele nové nadace zřejmě stane bývalý ministr vnitra a obrany Jean-Pierre Chevènement, který je známý jako zastánce sekulárního státu.
Ve Francii působí zhruba 2500 mešit a modliteben, asi 120 z nich slouží radikálnímu islamismu.
Od roku 2012 francouzské úřady ze země vyhostily zhruba 80 islámských duchovních a u několika dalších desítek tento krok zvažují.
Tento týden zasáhla proti džihádistickým duchovním také německá policie.
Imámové údajně verbovali bojovníky pro Islámský stát.
Jeden z nich provozoval prostor, kde se věřící údajně radikalizovali a později zaútočili na sikhský chrám v Essenu.
Hned po útocích na Charlie Hebdo v lednu 2015 se ve Francii rozhořela debata o nové instituci, která nefunkční nadaci nahradí.
Vše uspíšily další teroristické útoky, které ve jménu Islámského státu provedli radikální islamisté.
Nová nadace bude mít dva hlavní úkoly − zajistit financování mešit z domácích zdrojů a také dohlížet nad imámy.
Není ale dosud jasné, kde získá finance, přestože se zvažuje několik návrhů.
Jedním z nich je zvláštní poplatek na halal potraviny, tedy především na maso pocházející z porážek podle islámských zásad.
Tuto daň by v praxi platili prodejci halal jídla, a to za poskytnutí povolení.
Část peněz by pak putovala právě do rozpočtu nadace.
Příspěvek 10 až 20 eur by mohli také platit francouzští poutníci, kteří se vydají do Mekky.
Každý rok jich na tradiční pouť do Saúdské Arábie vyráží z Francie asi 30 tisíc.
Ve francouzských mešitách by navíc měli působit pouze kazatelé, kteří prošli vzdělávacími programy na tamních univerzitách.
Díky tomu by jejich kázání mělo být v souladu s demokracií.
Vláda také zavírá radikální mešity.
"Od prosince jsme jich zavřeli dvacet a další budou následovat," uvedl ministr vnitra Bernard Cazeneuve.
"Ve Francii není místo pro ty, kteří hlásají nenávist a nerespektují principy naší země, jako je rovnost mezi ženami a muži," řekl.
Zaragoza.
Svou bývalou manželku těžce zranil neznámý střelec v pátek dopoledne v nákupním centru v severošpanělské Zaragoze, píše deník Independent.
Ke střelbě došlo poté, co žena s dcerou opustily prostory garáže ve svém autě.
Muž čekal v autě před nákupním střediskem, odkud také začal střílet.
Podle svědků muž poté obrátil zbraň proti sobě, píše Independent.
Ženu odvezla do nemocnice nezraněná dcera, pro muže v kritickém stavu musela přijet sanitka.
K činu došlo okolo 11.00 v centrální části metropole autonomní oblasti Aragonie, nedaleko místní univerzity.
S odvoláním na španělskou agenturu Europa Press píše Independent, že motivem byl pravděpodobně nevyřešený nedávný rozvod obou partnerů.
Závitky s chřestem, wakame řasami, zázvorem a chilli omáčkou.
Léto přeje lehkým, dobře stravitelným jídlům, jenomže my Češi jsme rebelové a máme své chutě i svou hlavu.
A tak z letních zahrádek voní grilované krkovice, bůček, vepřová kolínka.
Nic moc zdravého, nic moc lehkého, ještě tak občas s výjimkou salátu či opečené zeleniny.
Pravda, grilování je úsporné na čas i nádobí, navíc je to společenská záležitost a nikdo nemusí být zavřený v kuchyni.
Ale jsou i jiné alternativy, jak si udělat dobře pochoutkami, které ozvláštní stolování, jejich příprava představuje malý rituál, zároveň však není třeba nic dlouze vyvařovat, péct, smažit či dusit.
A ještě k tomu nám přispějí ke zdraví.
Ať už je to třeba domácí sushi či sashimi, kde kvalitní suroviny a pár dobře osvojených grifů postačí k tomu, aby už příprava byla zábava a jídlo samotné opravdová exotická lahůdka.
Stejně jako ještě snadnější rolky v rýžovém papíru z dnešního receptu.
Tady dokonce odpadá časově náročnější vaření a zchlazování rýže.
Papír se dá jen na moment změknout do vody a pak už záleží pouze na fantazii kuchaře, jak si hodlá pohrát s náplněmi a doplňky.
Není řasa jako řasa.
Výhodou řady pokrmů asijské kuchyně je dnes i to, že suroviny jsou už zpravidla běžně dostupné.
Včetně nakládaného sladkokyselého zázvoru, který je jednou ze základních pochutin doprovázejících sushi či čerstvé rolky.
Můžete si ho připravit i doma, ale pravý růžový gari zázvor má jedinečnou pikantní ostrou a zároveň lahodnou chuť díky tajné receptuře, podle níž se míchá z několika druhů octa a zázvoru.
Stačí tedy koupit sáček odpovídající velikosti, a příloha s prokazatelnými antibakteriálními účinky, podporující trávení i odolnost proti kašli či chřipce, je hotová.
Banánové listy.
Používají se zejména v buddhistických a hinduistických kulturách při servírování a zdobení pokrmů v rámci nejrůznějších slavnostních příležitostí a rituálů.
Dlouhé žebrované listy banánovníku jsou velmi rozšířené v řadě zemí Asie či Jižní Ameriky také jako "pomůcka" pro přípravu nejrůznějších pečených, vařených a smažených jídel, která se do nich balí podobně jako do alobalu.
Banánový list pak pokrmu předá i specifickou příchuť.
U nás se dají koupit v prodejnách s exotickým ovocem a zeleninou, dokonce už předem nařezané do tvaru koleček.
Vybírejte však jen listy sytě zelené, a tedy zdravé - nepopraskané a beze skvrn.
Podobně snadná je příprava salátu z řasy wakame, sezamu a sezamového oleje.
Ten se dá totiž koupit zase zmrazený.
Kdo často jí či připravuje sushi, asi bude znát zejména řasu nori.
V Japonsku jde o jeden z nejdůležitějších druhů mořských řas, z něhož se vyrábí nasekáním, lisováním a sušením takzvané listy nori − tedy pláty určené právě k výrobě sushi.
Wakame − temně zelená řasa rostoucí ve vodách kolem ostrova Hokkaidó − se jí také čerstvá i sušená a je stejně populární jako řasa nori.
Mimochodem, kdo by neznal miso polévku s wakame, údajně ji asijské ženy používají odpradávna na zotavení po porodu.
A vůbec má tahle řasa účinky téměř zázračné.
Čistí krev, posiluje krevní oběh, dokonce údajně zabraňuje šedivění vlasů a je doslova nabitá minerálními látkami.
Sušená a roztlučená wakame slouží také jako koření, například k ochucení rýže.
Čerstvé řasy se nejprve nechají ve vodě vyluhovat, pak se propláchnou, vloží do vroucí vody a půl minuty vaří.
Poté se zchladí v ledové vodě, vyřízne se středové žebroví a dál se upravují, třeba jako oblíbený salát.
Ovšem koupit si jej už hotový, mrazený, je nejjednodušší řešení.
Zbývá tedy už jen umotat rolku se snadnou zeleninovou náplní, lahodnou a lehkou, plnou zdravých chutí.
Taková bombička dlouhověkosti.
Pokud odoláte a nepřihodíte navíc grilovaný bůček.
Najíst se zdravě, lehce a letně.
Asijci vědí, jak na to.
Stačí pár speciálních surovin a troška šikovnosti, a máte zajímavé svěží jídlo, které lahodně kombinuje chutě.
A hotové je raz dva.
Čtyři kusy rýžového papíru, 40 g mrkve, 40 g bílé ředkve, 100 g zeleného chřestu, 60 g salátové okurky, 60 g řasy wakame a 60 g sladké chilli omáčky.
Hrst sekaného koriandru, lžička černého sezamu, lžička sriracha chilli omáčky, 20 g manga a 40 g nakládaného gari zázvoru, trocha piniových oříšků.
Nejprve si připravíme závitky.
Rýžový papír namočíme na pět vteřin do studené vody.
Poté jej vyjmeme a počkáme, až změkne.
Mezitím si v horké vodě krátce povaříme chřestové výhonky, zhruba po třech minutách je dáme rychle zchladit do ledové vody, aby neztratily barvu.
Na povolený papír vložíme náplň ze zeleniny a zabalíme.
Náplň připravíme z bílé ředkve, mrkve a salátové okurky, které nakrájíme na jemné nudličky, smícháme je se sladkou chilli omáčkou, přidáme nasekaný koriandr, důkladně promícháme a vložíme na rýžový papír.
Na banánový list vložíme chřestové výhonky, přidáme závitky a na závěr celý pokrm dozdobíme řasou wakame, nakládaným zázvorem, plátkem manga, posypeme černým sezamem a přidáme pár piniových oříšků.
Británie se musí spokojit se stříbrem v sedmičkovém rugby, výběr Fidži bere zlato
Působivý výkon Velké Británie v sedmičkovém ragby skončil ničivým stopem na poslední překážce, Fidži porazilo ve finálovém zápase ve čtvrtek večer Brity na stadionu Deodoro zde v Riu vysoko 43:7.
Fidžané předvedli mistrovskou lekci ve zpracování, skládce, úhybech, podpůrné hře, běhu na lajnu a brutální síly - a získali zlato, svou první olympijskou medaili vůbec.
Porážka přišla s neokoukanou cenou útěchy v podobě stříbrné medaile - pro Británii třetí v daný den - a Britové mohli být na své výkony v inauguračním olympijském turnaji sedmičkového ragby hrdí, porazili Nový Zéland, Argentinu a Jihoafrickou republiku.
Vydřená výhra nad Jihoafričany 7:5 v semifinále ten samý den, je možná ve finále zamrzela.
Ovšem Fidži by ve své formě porazilo i 15členný tým v plném zdraví.
Nejpíš to pro Brity sice nebude útěchou, ale mohou se radovat z toho, že alespoň jeden z nich bude mít zítra okolo krku zlatou medaili: hlavním koučem Fidžanů je Ben Ryan, dřívější šéf Anglie z Wimbledonu.
Velká Británie urazila kus cesty.
Před osmi lety pod vedením Ryana prohráli v Adelaide Sevens každý zápas.
Zde prohráli jediný.
Tahle porážka sice bolí, ale pokrok je nepopiratelný.
Fidži začalo velkolepě, průniky Britů odráželi pro radost.
Pro kapitána Toma Mitchella a ostatní spoluhráče to bylo jako běžet za řadou autobusů v pohybu a šampioni světového poháru vedli 5:0, když se zpoza rohu vynořil Osea Kolinisau.
Časomíra ukazovala čtyři minuty a Jerry Tuwai přidal další down na pravém křídle, ze kterého byla konverze.
12:0 a Británie se ztěží dotkla míče.
Skvělý Mitchel se pokusil zastavit obrovského Leona Nakarawu a zabránit mu skórovat potřetí, ale pouze Fidžany zpomalil.
V sedmé minutě hodil Jasa Veremalua touchdown do pravého rohu a Britové prohrávali 17:0.
Nakarawa přidal po návratu další a na hodinách stále ještě zbývalo víc než 1 minuta ... z první poloviny.
Vatemo Ravouvou pak pronikl přes malátné Brity a přiřítil se na lajnu, kde skóroval.
Po konverzi na stav 29:0 následovala přestávka.
Bylo to, jako by se Fidži pro ragby 7s narodilo, zatímco Britové se stále učili předávání.
Přesně takhle nějak to je.
Britové po poločase udělali hromadné změny a nápor Fidžanů zastavili... na celé dlouhé čtyři minuty, což v porovnání s prvním poločasem bylo dobré, dokud po brilantní mezihře Fidži Josua Tuisova nepronikl dál.
Dan Norton se pokusil získat pro Brity příležitost, hodil touchdown do levého rohu na zvýšil an 36:7. Zápas už ale dávno vyhráli obyvatelé tichomořských ostrovů a jejich fanoušci na ochozech zpívali, mávali vlajkami a tancovali.
Bylo těžké neobdivovat naprosto rozradostněný přístup Fidžanů.
V závěrečných momentech ještě Mata Viliame dalším pokusem vítězství Fidžanů osladil.
Ozvala se píšťalka, Fidžané se objali a Britové padli na trávník zcela udolaní.
Ještě předtím ten samý den Fidži v semifinále porazilo Japonsko 20:5 a Velká Británie zdolal Jihoafrickou republiku v těsném semifinále - o rozdíl jedné konverze.
Kyle Brown dostal Jihoafričany v prvním poločase do vedení, ale Dan Norton díky své oslnivé práci nohou prorazil obrannou linii a skóroval v druhém poločase pod háčko.
Skvělá pozdní skládka Marcuse Watsona, bratra Anthonyho z patnáctkového týmu Anglie, zajistila vítězství - a nakonec také stříbrnou medaili.
Helen Gloverovou a Heather Stanningovou k vítězství ve veslařském závodě inspiroval boj trenéra s rakovinou
Na těchto Hrách nenajdete emotivnější zlato - a to je co říct.
Od prvního záběru do posledního, během 220 trestajících výdechů do historie našly Helen Gloverová a Heather Stanningová další význam v jejich zlatém okamžiku u Estacio de Lagoa.
I když u vesel seděly dvě, byly v lodi hlasy tři. Když loď svištěla po hladině vstříc druhému olympijskému zlatu za sebou v závodě ženských dvojic, byl s nimi v lodi ještě hlas stále přítomného trenéra Robina Williamse. Jsou prvními ženami v historii britského sportu, které takového výsledku dosáhly.
Jejich převaha byla absolutní, celkově to byl jejich 39. závod, ve kterém zůstaly nepřekonány.
To, co vidíme - dvě vynikající atletky, jak po vodní hladině letí s elegancí labutí - neodráží povahu vítězství úplně.
Za každou zlatou medailí z veslování je batalion pomocných rukou, které kousek po kousku znamenají rozdíl. A žádné ruce nebyly nápomocny víc, než ruce trenéra, který před 30 měsíci nevěděl, zda se tohoto dne dožije, když mu byla zjištěna rakovina.
Podle jeho slov to bylo nejisté.
Trpěl jsem rakovinou močového měchýře, kterou lze operovat, a tuto operaci jsem podstoupil.
Bez operace by se mohlo stát cokoliv.
Byla by to velmi špatná situace.
Poněkud to změní váš pohled na věc.
Rakovina byla Williamsovi zjištěna v prosinci 2013.
Štěstím pro celé trio bylo, že mohl nastoupit léčbu na začátku roku 2014, mimo sezónu, a zkrátit tak výpadek na minimum - pokud to tak můžeme za takovýchto okolností nazvat.
Potřeboval jsem vydělávat peníze, takže jsem se musel dát rychle dohromady.
To byl podnět.
Byl jsem v nemocnici a chodil jsem po pokoji - 20 stop, 30 stop, 50 stop v době, kdy říkali, že několik kroků stačí.
Takhle to začalo.
Veslování samo o sobě je cesta, ale tohle bylo o něco náročnější.
Bezprostředně po vítězství byly jejich první myšlenky na Williamse, který byl ráno velmi nervózní, mluvil méně než obvykle, jak se pokoušel zvládnout svůj vlastní neklid.
Stanningová, kapitánka pluku královského dělostřelectva, která má za sebou misi v Aghánistánu, řekla: „Tenhle týden jsem byla s emocemi na dně, možná je to trochu extrémní, ale znamená to tak moc.“
Znovu to zdůrazňuje, jak moc to pro mě znamená, jak moc jsme s Helen pracovaly a Robin také.
Až do teď to byly tři fantastické roky s Helen a Robinem.
Bez Robina bychom nebyly nikým, takže jemu patří obrovský dík, je to nejlepší trenér na světě.
Nemohla jsem si přát lepšího člověka pro trénink, ani lepšího kouče.
Helen Gloverová a Heather Stanningová neprohrály jediný závod za pět let.
Dvojice nasadila ohromující rytmus, kterému se jejich rivalky nemohly vyrovnat.
Dokonce i v závěrečných 500 metrech, kdy se začaly přibližovat posádky z Nového Zélandu a Dánska, měly Stanningová s Gloverovou velmi velkou rezervu.
Maximálně jsme se v daném okamžiku soustředily.
Helen křičela: „Nepřestávej, nepřestávej“.
Je opravdu důležité nenechat se unést.
Měli jsme dobrý start a zároveň jsme netoužily dosáhnout něčeho famózního.
Netěšily jsme se na dnešní ohňostroj, jenom jsme chtěly dobře zaveslovat, jít ven a vyhrát závod, což se nám povedlo.
Dvojice si vezme rok na rozmyšlenou, než se rozhodnou, co bude dál.
Gloverová se příští týden vdává, jejím nastávajícím je televizní dobrodruh Steva Backshall.
Teď si chce ten okamžik vychutnat.
Nechtěla jsem říct, že to bude můj poslední závod.
To by znamenalo příliš velký tlak.
V Londýně trvalo přibližně šest měsíců, než zjistili, že jsem olympijskou šampionkou.
Všechno to bylo tak nové a byla jsem tolik ve stresu.
Tady to trvalo asi čtyři minuty.
Mám z toho mnohem lepší pocit,“ řekla.
Sedadlo do první řady ke skvostné architektuře Centrální knihovny v Los Angeles
Společnost historiků architektury/Southern California Chapter pořádá setkání s Arnoldem Schwartzmanem a Stephenem Gee, autory nové knihy „Centrální knihovna v Los Angeles: dějiny jejího umění a architektury“.
Gee a Schwartzmann budou hovořit a ukazovat snímky návrhu Bertrama Goodhuea z roku 1926 a obnovy a dostavby z roku 1933 od společnosti Hardy Holzman Pfeiffer Associates.
Setkání se uskuteční od 14 do 16 hodin dne 21. srpna v Salle Moderne v budově soukromé školy Southwestern School of Law ve stylu Art Deco (dříve Bullocks Wilshire), na 3050 Wilshire Blvd.
Účastníci si mohou prohlédnout ústřední sál, Period Rooms, salónek Cactus Lounge a čajovnu.
Je nutné předem si zakoupit vstupenku: členové SAH/SCC 15 USD, nečlenové 25 USD.
Otevřený průmyslový loft v DTLA se dočká útulné přestavby.
Oslavte s námi 90. narozeniny Centrální knihovny v LA. Co dál? - nová kniha
Vězení?
Spíš ať vozí lidi zdarma, říká lovec taximafie Rubeš k přelomové obžalobě.
Šest taxikářů a bývalý úředník magistrátu v Praze jsou, jak uvedla ČT, obžalovaní.
Vy jste natočil řadu reportáží, v nichž jste odhalil podvodné praktiky i těch, kteří mají být ve skupině, jež stane před soudem.
Čelil jste kvůli tomu několika nepříjemným potyčkám s odhalenými aktéry.
Jak je moc je pro vás zpráva o obžalování členů organizované skupiny přelomová?
Čekal jsem, že k nějakému soudu asi dojde.
Jsem hlavně zvědavý na rozsudek.
Nemyslím si ale, že by měli být ve vězení.
To je k ničemu.
Primárně by měli vrátit všechny nakradené peníze.
A měli by je vrátit tak, že budou vozit všechny lidi zadarmo.
To je poněkud svérázné řešení.
Znamená to tedy, že případný trest nevnímáte jako dostatečně účinný?
Pro mě je dostatečné to, že někteří z nich mají takový strach, že už tu práci nedělají.
Například jeden dělá pingla, další rozváží pizzu a jeden se na to úplně vykašlal.
Obžalovaní mohou teoreticky dostat dva až osm let vězení.
Je to podle vás adekvátní sazba?
Všeobecně mám problém s odnětím svobody.
Považuji to za špatný trest.
Zavřít někoho do vězení, zvlášť v takovém případě, je nesmysl.
Takoví lidé by měli navrátit společnosti, co jí vzali.
Čtvrt století totiž páchali to, že naší zemi ničili jméno a sprostě okrádali lidi.
Tak ať teď dělají dobrou vizitku a rozvážejí lidi zadarmo.
Neumím si to jinak představit.
Fungovalo by to jako veřejně prospěšné práce.
Jako někdo chodí sbírat odpadky, oni by dostali auto a zadarmo by vozili lidi po Praze.
Ne, doopravdy si myslím, že nakonec dostanou podmínku a bude jim to jedno.
Najdou si jiný způsob, jak někde podvádět.
Studoval na Filmové akademii Miroslava Ondříčka v Písku a následně na Univerzitě Tomáše Bati ve Zlíně.
Patří k lidem, kteří v České republice začínali s virálními videi a videi přímo pro web.
Pracuje jako redaktor pro internetovou televizi Stream.cz, kde se podílí na řadě pořadů, nyní připravuje pořad Prague Guide, který je určen především zahraničním divákům.
Těm Rubeš formou krátkých reportáží radí, jakým službám se v Praze raději vyhnout a jaké naopak doporučuje bez obav využít.
Dříve natáčel série s názvy Jak na to, Město podvodů?, Život v luxusu, A dost! a Praha vs. Prachy.
V obžalobě se o nich mluví jako o organizované skupině.
Policie ji sledovala několik měsíců.
Lze takovou síť podvodných taxikářů označit za mafiánskou?
Jsou to takoví roztomilí mafiáni, ne takoví, jaké známe z Kmotra.
Jde spíše o mafiány - juniory, ale organizovaní jsou určitě.
Už jenom v tom, že si navzájem hlídají štafly (taxikářská stanoviště).
Praha je celá rozparcelovaná.
Vysledoval jsem, že například hlavní nádraží se nemá rádo s Pařížskou, Pařížská se zas nemá ráda s taxikáři čekajících u Karlových Lázní (disco klubu)
Každý si prostě hlídá to svoje místečko a každá ta skupina je nějak organizovaná.
Jde zřejmě o spletitou síť.
Obžalovaných je ale dohromady jen sedm lidí, šest taxikářů a jeden bývalý úředník magistrátu, který řidiče varoval před kontrolami.
Jak sám říkáte, nežádoucí jev z ulic nezmizeli.
O jaké procento mezi pražskými podvodníky v taxi službě podle vašeho odhadu tedy jde?
Je to velmi malé procento.
Ti nejhorší na ulici pořád jsou.
Mluvím například o Alešovi Ryjáčkovi.
To je člověk, který je skutečně nebezpečný - ve svém autě vozí teleskopický obušek, a každý pátek a sobotu stojí u Karlova mostu a vozí lidi.
Když jsem s ním naposledy jel, chtěl po mně sedm stovek za tři kilometry.
Jeho policie z nějakého důvodu nezadržela.
Vybrali jen pár lidé z celé té velké skupiny.
Stejná situace je ovšem i v dalších lokacích Prahy.
Obžalobou sedmi lidí tedy těžko vymýtí již proslulý pražský nešvar, který má zřejmě mnohem větší rozměry.
Úplně k ničemu to samozřejmě není.
Pomůže to, ale všechno zlo se nevymýtí, to je pravda.
Vystupují taxikáři, kteří okrádají zahraniční turisty, pořád na těch stejných místech, které jste ukázal v reportážích, tedy u Karlova mostu či v Pařížské ulici?
Ano, přesně tak.
V těchto lokacích stojí každý den a každý den porušují vyhlášky.
Ignoruje to jak městská policie, tak pražský magistrát.
Není to už ani kocourkov, ale naprostá lhostejnost.
Byznys pražských taxikářů v číslech
Přesto se někteří z nich, byť jde jen o část skupiny, dostanou před soud.
Už to je průlom.
Musím se proto zeptat: cítíte zadostiučinění?
Kdybych to bral jako zadostiučinění, tak by to bylo špatně, protože mým cílem bylo, je a vždycky bude, aby se centrum Prahy zlepšilo.
A i když budu mít pocit, že je třeba už o trochu lepší, budu v tom i nadále pokračovat.
Je potřeba tlačit na dveře z druhé strany.
I když tam zůstane poslední zloděj, pořád bychom měli dělat něco pro to, abychom ho odstranili.
S tím se nelze spokojit.
Jenže ono to tak není, je jich samozřejmě víc.
Snažíš se je pořád konfrontovat přímo v taxících?
Občas dělám testovací jízdy a musím říct, že je to stále špatné.
Zrovna minulý týden jsem chytl jednoho taxikáře, mimochodem z té stejné skupiny, a byl hodně překvapený, že mě zase vidí.
Naúčtoval si 560 korun za tři kilometry, ačkoli potom tvrdil, že šlo o částku 56 korun (využil trik s desetinnou čárkou).
Měl na to stvrzenku, přijeli policisté a tenhle taxikář byl tak roztomile drzý, že ještě chodil za těmi policisty a ptal se jich, kdy už mu někdo konečně dá těch 56 korun.
Podobný případ.
Taxikář na taxametru přelepil desetinnou čárku a okradl turisty o 357 korun.
Dá se říci, že drzost podvodných taxikářů neustoupila ani poté, co jste ve svých záběrech ukázal tváře těch, kteří účtovali nesmyslné částky za krátkou jízdu?
Jejich drzost je pořád neuvěřitelná.
Jak to s tím taxikářem domáhajícím se 56 korun dopadlo?
Policisté ho poslali pryč s tím, že s ním na místě nemohou diskutovat, protože vystavil účtenku.
A to bude, myslím, problém i u toho soudu (šesti taxikářů a jednoho exúředníka).
Na jedné straně tam bude nějaký taxikář se svými účtenkami, na druhé straně policie.
Jenže podle rozhodnutí Nejvyššího správního soudu nesmí magistrát použít tajné nahrávky z vozidla taxi služby jako důkaz u soudu.
Když jsem natáčel díly o jejich podvodech, tak mě sami taxikáři na tenhle precedens upozornili.
Já jsem záběry ale vždycky chtěl použít jen do reportáže.
Máte obavu, že by je tahle skutečnost mohla ochránit i před soudem?
Doufám, že každý soudce pochopí, že žádný taxikář by nemohl jezdit za šest nebo deset korun na kilometr, protože by se tím neuživil.
Mluvil jste o triku s desetinnou čárkou, kterou zejména před zahraničními klienty podvodní taxikáři posouvají.
Je to pořád aktuální, nebo mají obavu tenhle fígl po zveřejnění vašich reportáží nadále používat?
Myslím, že jsme tenhle trik odvysíláním pořadu naopak zpopularizovali.
Nedávno jsem jel s jedním taxikářem, chvástal se přede mnou, že on je ten poctivý taxikář.
Pak jsem si ale všiml, že z boku taxametru přilepenou černou lepenku.
Když jsem se ho zeptat, co to tam má, řekl mi: "Vy přece víte, co to je."
Když na taxikáře-podvodníky příliš nefungovaly pokuty, může na ně varovně zapůsobit soud s jejich kolegy?
Je vůbec něco, co je může od podvodů odradit?
Mluvil jste o tom, že si podle vás cestu, jak podvádět, najdou vždycky.
Myslím, že odradit je nemůže nic.
Ale někdo je z těch míst může vytlačit.
A to jsou féroví taxikáři, kteří by se měli prát víc za to, aby je odtamtud vážně dostali pryč.
Ze své zkušenosti musím říct, že ti féroví taxikáři v Praze naštěstí převažují.
Mají ale chuť jít proti těm, kteří kazí pověst jejich služeb?
Chuť mají, ale chybí jim um.
Neumí v tom moc chodit a neumí přesně říci, co by chtěli.
Když uspořádali tu demonstraci (kvůli návrhu na celoplošné omezení pocházející z kanceláře primátorky Adriany Krnáčové), nevyznívalo moc jasně, co vlastně chtějí.
Jednou říkali, že neprotestují proti Uberu, že jen chtějí mít stejné podmínky jako má právě tato služba, pak zas tvrdili, že chtějí víc než Uber.
Dopadlo to tak, že jen zablokovali Prahu a vznikla z toho jen ta nejlepší možná reklama pro Uber.
Jak celkově hodnotíte přístup pražského magistrátu v řešení problému s předražováním jízdného?
Je vidět, že do toho musela vstoupit až kriminální policie, aby se něco vyřešilo.
Magistrát byl na to krátký.
Měli tam krtka, který vynášel informace, to znamená, že oddělení taxi vykonávalo svou práci několik let úplně zbytečně.
Doufám, že tomu úředníkovi naúčtují do poslední kontroly všechny zmařené kontroly, aby si uvědomil, co udělal.
To mi na tom totiž přijde nejhorší.
Já jsem s ním dokonce byl na jedné kontrolní jízdě, což jsem zjistil až následně z jejich rozpisu.
Od publikování posledních dílů seriálů uběhlo už několik měsíců.
Jaká je odezva?
Myslím hlavně u zahraničních diváků, na než je vlastně série nejvíce zaměřená.
Vždycky když tu mám kamarády ze zahraničí, tak jim ta videa pouštím.
A když pak jdeme po Staroměstském náměstí, jsou překvapení, že tam ti samí lidé, co jsou vidět na záběrech, vážně stojí.
Neslavně proslulé pražské celebrity.
Ale vážně.
Postavil bych kolem nich plůtek, aby se na ně lidé koukali.
Muzeum komunismu přímo na ulici.
Moje poslední otázka je jasná.
Jezdíte taxíkem, když potřebujete?
Jasně.
Jezdím se službami, u nichž nemusím platit hotově, ale kartou.
Využívám služby jako je Uber nebo Liftago, kde neexistuje možnost podvodu.
Je ale i mnoho dispečinků, které jsou fér.
Na ulici jsem si taxíka vzal od té doby jen jednou.
Řidič mi po nástupu do auta řekl: "Teda, ty máš ale odvahu."
Bém v převlečení za italského turistu.
O podvodných praktikách taxikářů se psalo už v roce 2005.
Někdejší primátor Pavel Bém v tomtéž roce vyrazil na kontrolní jízdu v převlečení za italského turistu a hned na první pokus jej řidič ošidil o dvě stovky.
Redaktor Rubeš měl ale horší zkušenosti.
Řidiči taxislužby mu naúčtovali za jízdu ze Staroměstského na Václavské náměstí 820 korun, což vychází zhruba na 195 korun za kilometr, jak vypočítali tvůrci reportáží.
Pražský magistrát přitom stanovil maximální cenu na 28 korun za kilometr.
V natočené reportáží jsou také další překvapující sumy: například dvoukilometrová cesta z ulice Pařížská do Truhlářské stála turistu 400 korun.
Drahé jízdy poskytovali i taxikáři čekající u Karlovo mostu.
Za jízdu na Anděl, která má 2,5 kilometru, si účtují třeba i šest set korun.
Mramor se myje převážně čistou vodou, co nejvíc bez chemie a čím déle, tím lépe.
Nečistoty z něj jdou dobře, i když občas se musí špína dávat dolů skalpelem, je třeba ji vydloubat ze záhybů.
Není to jednoduché a nejde to rychle, přiblížila svou práci restaurátorka Vanesa Trostová z Oldřichova v Hájích.
Klobouk dolů před ní: náhrobek je obestavěný lešením, po kterém je třeba bezpočtukrát vylézt a zase slézt.
"Restaurátor by měl být pečlivý, trpělivý a nenáročný na pracovní prostředí," zkonstatovala.
Na Frýdlantsku to není zdaleka první její restaurátorská práce.
Díky ní se dočkaly obnovy například kamenné prvky fasády v zadním traktu frýdlantské radnice, restaurovala také sochy svaté Maří Magdaleny v Zátiší, svatého Jana Nepomuckého ve Frýdlantě, Pietu ve frýdlantské Okružní ulici, Mariánský sloup ve Frýdlantu či atlanty v průčelí lázní v Novém Městě pod Smrkem.
S obnovou náhrobku Melchiora, Kryštofa a Kateřiny z Redernu se ve Frýdlantu začalo už v roce 2011.
Teď se očišťuje povrch kamenných prvků od nánosu nečistot a krust, uvolněné kamenné části se zajistí proti pádu a posunu; buď se budou kotvit do stěny nebo k sobě navzájem.
Čeká je taktéž ošetření a konzervace povrchu.
Nápisy na hrobce se znovu pozlatí.
"Potom se začne zlacením nápisů na mramorových deskách ryzím plátkovým zlatem," uvedla referentka Státní památkové péče městského úřadu ve Frýdlantu Věra Sobotová.
Z minulosti nejsou žádné záznamy o tom, že by náhrobek prošel nějakými opravami.
Při bližším pohledu zaujmou otvory, vyvrtané v mramorových sloupech.
Jsou stovky let staré a jde o pozůstatky po výzdobě náhrobku.
Byl bohatě ozdoben, bohužel po nájezdu Švédů za Třicetileté války vše zmizelo.
Doslova náhrobek očesali, poznamenala Sobotová.
V kostele Nalezení svatého Kříže jsou restaurátoři s mírnou nadsázkou jako doma.
Po povodni v roce 2010 bylo potřeba dát do pořádku náhrobky, které se ocitly pod vodou, restaurovala se křtitelnice, nástěnné malby v hrobce a teď náhrobek.
"Rádi bychom se také v budoucnu pustili do vitráží," prozradila Sobotová.
Kostel je jinak ve velmi dobrém stavu, každý rok do údržby a oprav vkládáme peníze.
Restaurátorské práce na obnově redernovského náhrobku přijdou celkem na 128 tisíc korun.
Budou hrazeny z dotací, město do této části obnovy nebude vkládat žádné své peníze.
Sto tisíc korun půjde právě z výhry v krajském kole soutěže Historické město roku 2015, zbylých 28 tisíc korun je pak příspěvek ministerstva kultury, upřesnil starosta Frýdlantu Dan Ramzer.
O uvolnění výhry na restaurování náhrobku rozhodlo zastupitelstvo.
Názory expertů na budoucí vývoj na vybraných zahraničních trzích sledovaný prostřednictvím indexů a porovnání s českým kapitálovým trhem (PX) v horizontu jednoho měsíce a půl roku.
Na trzích převládá nízká volatilita a růst.
Kdo by to byl ještě začátkem roku řekl.
Americký index S&P500, který si v únoru procházel 12% korekcí je dnes na novém historickém maximu a od začátku roku si připsal již 7 procent.
Znovu se tak potvrzuje železné pravidlo, že by obchodníci dlouhodobě nikdy neměli jít proti zájmu centrálních bank, které nakonec zatím vždy dosáhly svého.
V situaci kdy jsou americké akcie na historickém maximu tak znovu mizí volatilita, která je momentálně nejnižší od roku 2014, kdy trhy spokojeně a beze strachu rostly díky kvantitativnímu uvolňování americké centrální banky a kdy se stejně jako dnes index volatility (VIX) držel stabilně pod hranicí 12 procent.
A aby také ne.
Přestože Fed trhy dál připravuje na postupné zvyšování úrokových sazeb, kvantitativní uvolňování v Evropě i v Japonsku je v plném proudu a v minulém týdnu přiložila ruku k dílu také Bank of England, která v nadcházejících šesti měsících nakoupí dluhopisy v objemu 70 mld. liber.
Nová vlna kvantitativního uvolňování tedy tlačí již tak nízké výnosy ještě níže a přispívá k téměř kompletní eliminaci rizika a strachu z budoucnosti.
Jak dlouho tento stav vydrží?
To je samozřejmě otázka za milion.
Na dohled ale momentálně nejsou žádná rizika, světová ekonomika si prochází téměř konstantním růstem bez větších výkyvů, situace na komoditním trhu a v Číně se stabilizuje a brexit již v podstatě není téma, takže bychom se asi neměli příliš divit, kdyby v podobně klidném režimu vydržely americké akcie i nadále.
Škoda, že Juncker nestuduje Klause!
Jsem velmi rád, že můj přítel Michel Barnier přijal tento důležitý a náročný úkol.
Chtěl jsem pro tuto obtížnou práci zkušeného politika, prohlásil šéf Evropské komise Juncker, když francouzského politika (opravdu zkušeného, neboť protřelého tolika nejrůznějšími nadnárodními politickými funkcemi, že lepší příklad tzv. evropské elity bychom obtížně hledali) jmenoval hlavním vyjednavačem Evropské komise podmínek odchodu Velké Británie z EU.
Junckerův výběr sfoukl náznaky nadějí, že je ve vážném zájmu EU hledat s Británií formy budoucí přátelské koexistence.
Však většina britských médií přijala jméno Barniera jako Junckerův válečný akt.
Barnier je skalní evropský federalista.
Velkou Británii nenávidí.
Jako eurokomisař pro vnitřní trh (2009 - 2014) měl na starosti reformu evropského bankovního práva.
Pojal ji tak, jak ji mohl pojmout jenom on: zatvrzelý nepřítel anglosaského pojetí volného trhu a modelu kapitalismu.
Zastánce mnohostranných regulací byl spoluautorem koncepce tzv. bankovní unie a se záští vůči všemu, co pochází z londýnského finančního centra City, prosadil legislativu přemrštěně tvrdých regulací finančního sektoru a služeb.
Tak tento Michel Barnier, představitel Paříže ve sporu s Londýnem, bude tvrdým, neoblomným a zřejmě i bezohledným vyjednavačem.
To asi není dobrá zpráva.
Jak si v tomto kontextu nevzpomenout na klidné a přátelské rozdělení československé federace, ke kterému tolik přispěla rozvaha, přehled a schopnost empatie premiéra Václava Klause.
I proto dnes mohou Češi se Slováky být nejbližšími přáteli i spojenci.
Škoda, že se Juncker od Václava Klause - alespoň v tomto - nepoučil.
Bylo by to k dobru všech!
Zemětřesení kolem Putina?
Vládce Kremlu propustil svého blízkého Ivanova.
Ruský prezident Vladimir Putin v pátek propustil Sergeje Ivanova z postu šéfa prezidentské kanceláře.
Jeho místo převezme Anton Vajno.
Informovala o tom ruská média s odvoláním na oznámení tiskové služby Kremlu.
Putin přitom naznačil, že Ivanova propouští na jeho vlastní žádost.
Při setkání, které přenášela televizní stanice Rossija 24, prezident řekl, že vychází vstříc přání Ivanova vyslovenému při nástupu do funkce, že chce být šéfem prezidentské kanceláře nejvýše čtyři roky.
Zároveň oznámil, že Ivanov bude jeho zvláštním zástupcem pro ekologii a dopravu.
Zpráva o výměně v čele prezidentovy administrativy, kterou nyní povede Ivanovův dosavadní zástupce Vajno, je považována za poměrně překvapivou.
Ivanov, kterému je 63 let, je totiž označován za jednoho z nejbližších spolupracovníků Putina.
Tento bývalý důstojník KGB v minulosti například zastával funkce ministra obrany a místopředsedy vlády.
Nyní opustí i křeslo člena prezidentovy bezpečnostní rady.
Ivanov při setkání s Putinem ale uvedl, že je délkou setrvání v čele administrativy šéfa státu vlastně rekordmanem.
Vydržel v ní čtyři roky a osm měsíců.
V této souvislosti připomněl, že za 25 let od jejího ustavení se v této funkci už vystřídalo 11 lidí.
Kvitová ani deblistky Strýcová se Šafářovou si finále nezahrají.
Zatím ani jedno z pátečních tenisových utkání se nepodařilo proměnit ve finálovou účast.
Jako první svůj boj prohrála Petra Kvitová, která podlehla portorikánskému překvapení Monice Puigové po setech 4:4, 6:1 a 3:6.
Kvitovou po chvíli následovaly i české deblistky Šafářivá se Strýcovou.
Přemožitelky sester Williamsových sice v prvním setu sahaly po výhře, promarnily však dva setboly a Rusky nakonec ukořistily set ve zkrácené hře.
Druhý set pak ztratily poměrem 4:6.
Poloviční úspěšnost v dopoledním programu v Riu zaznamenalo české veslování: skifař Ondřej Synek s přehledem vyhrál své semifinále, když druhého Damira Martina z Chorvatska porazil i přes zvolnění v závěru téměř o sekundu.
Dneska dobrý, podmínky byly super, vítr se zklidnil.
Já jsem se snažil šetřit co nejvíc, uvedl Synek.
To jeho soupeři na rozdíl od něj museli o postup bojovat.
Takže jim to nějaké síly ubralo, o to by to zítra mohlo být jednodušší.
Ale neříkám, že to bude jednoduchý, jen mi to hraje do karet, prohlásil veslař pražské Dukly.
Mirka Topinková-Knapková ale v Snykových šlépějích nekráčela.
Pětatřicetiletá veslařka obsadila v dnešním semifinále ve své jízdě čtvrtou pozici a v sobotu ji čeká start v B finále a boj o 7. až 12. místo.
Zlato z Londýna tak neobhájí.
Poprvé jsem na olympiádě nepostoupila do finále.
Trošku mě to mrzí, ale na druhou stranu jsem jela kvalitní závod a dala jsem do toho všechno, co šlo.
Soupeřky byly prostě lepší, sklonila se před nimi Topinková Knapková.
Bojovala až do konce a věřila, že se na svých čtvrtých hrách mezi elitní šestici dostane.
Boj vzdala až těsně před cílem.
Věděla jsem, že holky jsou vyrovnané, že z toho pole může postoupit kdokoliv.
Překvapila mě Číňanka, že měla takový finiš.
A myslela jsem si, že přes Rakušanku dokážu do finále postoupit.
Bohužel dneska jela životní závod, řekla mistryně světa z roku 2011.
Daleko za finálovými branami v Riu zůstal mladý střelec Filip Nepejchal, kterému se ani na podruhé nepodařilo prodrat se z kvalifikace, tentokrát malorážky v leže.
V ní Nepejchal obsadil 33. místo.
Kvalifikace nejlépe vyšla Rusům.
Z první příčky postoupil Sergej Kamenskij s 629 body, ze druhé Kirill Grigorjan (628,9).
Nepejchalův nástřel měl hodnotu 620,5 bodu.
Do programu v Riu poprvé promluvili také atleti, mezi nimi i české sedmibojařky Kateřina Cachová a Eliška Klučinová.
Cachové patří po druhé disciplíně olympijské soutěže jedenácté místo, české rekordmanka Eliška Klučinová je dvaadvacátá.
Vede Britka Katarina Johnsonová-Thompsonová, která skočila do výšky 198 centimetrů stejně jako průběžně druhá Belgičanka Nafissatou Thiamová.
Obě se postaraly o historicky nejlepší výškařský výkon v rámci sedmiboje.
Pokoušely se ještě skočit 201 centimetrů, ale neuspěly.
Němec, Rus, kdo je horší?
Když odhlédneme od absurdity takto položené otázky: Německá společnost prošla hlubokou sebereflexí, kdežto ruská nikoliv.
V obou velkých eurasijských národech se ve 20. století vyskytli diktátoři, a dostaly se k moci režimy, jež byly nelidské, brutální a strašné.
Ruští bolševici od roku 1917 do roku 1989 přispěli velkou měrou k 94 milionům obětí komunismu, které uvádí Černá kniha komunismu, ať už se jednalo o každodenní individuální represe, cílené hladomory, nekompetentní vedení války nebo nelidské experimenty.
Nacisté nelidským způsobem vyhladili okolo 6 milionů Židů a celkové oběti druhé světové války se odhaduji na 60 milionů.
Na obsazovaných či opouštěných územích prováděli zvěrstva Němci i sověti.
V Německu ani v SSSR nebylo vinno jen pár jednotlivců, ale velká část národa se těchto zločinů účastnila ať již aktivně, pasivně či jen zbabělostí či strkáním hlavy do písku.
To není specifika jen těchto národů, my Češi jsme podobně vinni.
V Německu bezprostředně ukončení války přišla denacifikace, Norimberský tribunál.
To nejdůležitější však přišlo později.
Když děti vyrostly, začaly se ptát: Tatínku, dědečku, proč ses účastnil takových zvěrstev?
Jak jsi to mohl!
To přineslo skutečnou reflexi a vyléčení společnosti.
Německé elity se donedávna staraly hlavně o prosperitu země, odstranění chudoby, blahobyt svých občanů.
Teď mají i jiné (často naivně idealistické) cíle, ale rozhodně jim nejde o to připojit zpět Alsasko-Lotrinsko nebo někoho - na revanš - vojensky napadnout - to snad uzná každý.
Po prohrané studené válce v Rusku k žádné velké reflexi nedošlo.
Okno možných pozitivních změn se definitivně uzavřelo na přelomu tisíciletí, když se k moci dostal bývalý důstojník KGB (sic!)Vladimír Putin.
Často zločinná minulost je dnes v Rusku oslavována.
Politikou putinovskéhu Ruska je revanš, dobytí ztracených území, ponížení Západu.
Zdraví, prosperita a budoucnost vlastních lidí není pro věrchušku žádnou hodnotou.
Bij své, a cizí se budou bát.
Stále věřím, že to je jen těmi desetiletími despotického režimu, že Rusové nejsou geneticky či kulturně méněcenní - předurčeni k asijské (sebe) tyranii.
Komu prospívá růst napětí kolem Krymu?
Ukrajinská armáda.
V posledních dnech a hodinách došlo ke zhoršení situace na ukrajinsko-ruské hranici v oblasti Krymu.
Komu růst napětí prospívá?
Po delší době relativního klidu došlo opět k dalšímu zhoršení vztahů mezi Ukrajinou a Ruskem.
Záminkou ukrajinské strany se stal poloostrov Krym, který byl připojen před více než 2 roky k Rusku a je součástí jeho území.
Zprávy z obou znepřátelených stran si samozřejmě protiřečí a je těžké je nezávisle ověřovat, a tak máme možnost se pouze zamyslet starou známou otázkou komu to prospívá?
Podle zpráv z Moskvy došlo k teroristickým útokům na Krym z ukrajinské strany, což pochopitelně Ukrajina odmítá a naopak obviňuje Kreml z provokace.
Na informace o zatčení příslušníků ukrajinských speciálních jednotek na území Ruska přišla již z případu pilotky Savčenkové známá odpověď, že byli údajně na území Ruska uneseni.
Pokud bychom přistoupili na ukrajinskou verzi, v čem by Rusku prospělo zhoršení situace kolem Krymu?
Jednoduchá odpověď zní: v ničem.
Eskalace napětí kolem Krymu může Rusko jenom poškodit, hlavně ze strany Západu ve formě dalšího přitvrzení sankcí a zesílení protiruské kampaně.
V posledním roce došlo na pozadí imigrační krize do Evropy k ústupu pozornosti od situace na Ukrajině.
Ukrajinské vedení ztratilo před svými obyvateli již zcela kredit, když se aktuální podpora prezidenta Porošenka pohybuje okolo 15%.
Ekonomika Ukrajiny by již dávno zbankrotovala nebýt štědrých finančních injekcí ze strany EU a hlavně MMF.
V této situaci potřebuje ukrajinský režim opět rázně upoutat pozornost ke své zemi, aby tak zdůvodnil své další žádosti o finanční pomoc a pokusil se zlepšit si renomé před voliči ve své zemi.
Prezident Porošenko a další členové vedení silových složek se opět chtějí ukázat jako silní muži, kteří se nebojí se postavit i velkému Rusku.
Nezbývá než doufat, že si všichni ti, kteří se pokouší rozpoutat otevřený konflikt mezi Ukrajinou a Ruskem, uvědomí nakonec svou obrovskou odpovědnost za životy nejen vojáků, ale všech obyčejných lidí na obou znepřátelených stranách a zastaví včas své nepřátelské akce.
Bulharsko poprvé za osm měsíců vykázalo inflaci
Podle národních statistik dosáhla v Bulharsku v červenci měsíční míra inflace 1 %.
Toto je nejvyšší hodnota za několik let (od června 2012) a první nenulová hodnota od října loňského roku, kdy byla zveřejněna kladná míra inflace ve výši 0,2 %.
Roční průměrná míra inflace, měřená indexem CPI, za posledních 12 měsíců (srpen 2015 - červenec 2016) v porovnání s předchozím obdobím 12 měsíců (srpen 2014 - červenec 2015) byla -0,8 %.
Index spotřebitelských cen v červenci 2016 oproti červnu 2016 byl 101,0 %, měsíční inflace tedy byla 1,0 %.
Míra inflace od začátku roku (červenec 2016 oproti prosinci 2015) byla -0,2 % a roční míra inflace v červenci 2016 oproti červenci 2015 byla -0,2 %.
Oproti předchozímu měsíci byl v červenci 2016 zaznamenán nárůst cest těchto skupin spotřebního zboží: potraviny a nealkoholické nápoje (1,7 %), doprava (1,8 %), kultura a rekreace (6,3 %), restaurace a hotely (1,2 %), ostatní zboží a služby (0,3 %).
K poklesu cen došlo u oděvů a obuvi (2,2 %), nábytku, vybavení domácnosti a běžné údržby (0,5 %), zdraví (0,1 %).
Na stejné úrovni jako předchozí měsíc zůstaly ceny u alkoholických nápojů a tabákových výrobků, bydlení, vody, elektřiny, plynu a ostatních paliv, komunikace a vzdělávání.
Tajné služby USA prý rok sledovaly hackerské útoky Rusů.
Informace o ruských útocích se dostaly na veřejnost minulý měsíc, kdy Federální úřad pro vyšetřování (FBI) oznámil, že se zabývá útokem na servery stranického ústředí demokratů.
O ruském podílu na útoku se ale žádná oficiální zpráva nezmiňuje.
Moskva podíl na útoku popřela.
Zpráva o sledování údajného ruského útoku byla přísně tajná, protože jejím vyzrazením by vyšlo najevo, že americké tajné služby hackerský útok monitorují a odhalen by mohl být i způsob, jak to dělají a jakých zdrojů využívají.
Na útočné akci se prý podílely dvě ruské zpravodajské služby.
Nový poradní sbor pro kybernetickou bezpečnost
Materiál o sledování ruské stopy byl zakódován a přístup k němu měla jen malá skupina expertů, napsal Reuters.
Z veřejných činitelů byla informována jen malá skupina osmi čelných poslanců Kongresu, nazývaná v USA gang osmi.
Tvoří ji šéfové obou komor Mitch McConnell a Paul Ryan, předsedové demokratů v obou komorách Nancy Pelosiová a Harry Reid a čtyři členové branných a bezpečnostních výborů Kongresu.
Úřadující šéfka Demokratické strany Donna Brazileová ve čtvrtek oznámila, že vytváří poradní sbor pro kybernetickou bezpečnost, který má "zabránit budoucím útokům a zajistit prvotřídní ochranu serverů Demokratické strany".
V uzeném lososovi z Albertu byl nebezpečný parazit.
Řetězec se omluvil.
Na základě podnětu spotřebitele na zdravotní potíže po konzumaci potraviny Losos divoký uzený - kousky 100 g, datum spotřeby 22.11.2016 provedli pražští hygienici kontrolu v prodejnách Albert na Václavském náměstí a Na Můstku.
Kontrola zjistila, že šarže L23012562/T4 s datem spotřeby 22.11.2016, na kterou zákazník upozornil, již není k dispozici, a proto byl odebrán výrobek totožné šarže s datem spotřeby 11.12.2016.
Laboratorním vyšetřením byla potvrzena přítomnost Anisakis spp. Anisakis simplex.
Jedná se o parazitického červa trávicího traktu mořských savců.
Ten je pro člověka nebezpečný - larvy v tělní dutině či svalovině ryb jsou silným alergenem a člověkem pozřené živé larvy mohou proniknout skrze žaludeční stěnu do vnitřních orgánů, uvedl Šticha.
Zákazníkům se velice omlouváme za problémy u tohoto značkového výrobku.
Zmíněnou šarži jsme okamžitě stáhli z prodeje a z preventivních důvodů jsme stáhli i všechny další šarže této položky.
K pochybení došlo na straně dodavatele, se kterým jednáme, a zároveň jsme sami nechali tento produkt testovat, řekla Novinkám mluvčí Albertu Barbora Vanko.
Pokud si zákazník tento výrobek koupil, může jej ve kterémkoli z obchodů řetězce vrátit a dostane zpět peníze.
Larvy zničí mráz i dostatečná tepelná úprava
Prodávajícím byla společnost Nekton - Vrňata.
O výskytu nebezpečného výrobku hygienici informovali pražskou a středočeskou veterinární správu.
Podle serveru bezpecnostpotravin.cz lidé po pozření parazita mohou onemocnět anisakiózou, která se projeví prudkými bolestmi břicha, zvracením a nauzeou, nebo nemoc může proběhnout bezpříznakově, uvedla ČTK.
Symptomy se dostaví hodinu až dva týdny po konzumaci nedostatečně tepelně zpracované infikované ryby.
Po třech týdnech od počátku onemocnění larvy většinou spontánně opustí zažívací trakt.
Dospělí červi i larvy jsou citliví na vyšší i nízké teploty, proto jsou usmrceny buď při dostatečném tepelném zpracování rybího masa, nebo při jeho zmrazení.
Veterináři aktuálně prověřili lososa i u příjemce dovezeného zboží ve Středočeském kraji.
Tři z pěti zkoumaných vzorků v sobě parazita měly.
Zásilka se 1700 produkty přišla do ČR podle Státní veterinární správy (SVS) začátkem dubna.
Vyexpedováno, v naprosté většině do řetězce Ahold, bylo k dnešnímu dni 919 balení.
V současné době probíhá stahování neprodaných zásob výrobku z prodejen, řekl v pátek ČTK mluvčí SVS Petr Pejchal.
Veterináři okamžitě po nálezu pozitivních vzorků zakázali posílání dalších výrobků ze skladu.
Sedmnáctiletá Britka chtěla prchnout z Rakky, zabil ji zřejmě ruský nálet.
Po počátečním nadšení a rychlém sňatku s džihádistou, který byl záhy zabit, přišlo vystřízlivění.
Očekávaný ráj chalífátu se pro britské dívky proměnil v peklo na zemi, z něhož nebylo úniku.
Dívka byla podle příbuzných v kontaktu se svou sestrou Halimou.
Do Británie jí opakovaně telefonovala a svěřila se, že chce zpátky domů.
Opustit Islámský stát je jako pokusit se utéct z Alcatrazu.
Mají rozkaz bez rozmyslu střílet, cituje The Telegraph právníka rodiny zesnulé dívky Tasnima Akunjeeho.
Poslední stopy vedly do Rakky, odtamtud se dívka ozvala naposledy.
Pak už přišla jen zpráva o její smrti, kterou ale nelze ověřit.
Rodina s ní komunikovala z bytu ve východním Londýně.
Společně probírali, jak by se mohla dostat z Rakky a překročit tureckou hranici.
Tam doufali, že se s bývalou studentkou znovu setkají.
Kadiza ale byla pravděpodobně zabita dřív, než mohla uprchnout, protože dům, v němž se se zdržovala, srovnal v květnu se zemí nálet, uvedla britská ITV News.
Televize dodala, že bombu zřejmě svrhlo ruské letadlo, které útočilo na baštu IS v Sýrii.
Snesli byste modré z nebe, jen abyste dostali své dítě z nebezpečné oblasti, řekl Tasnim Akunjee, právník rodiny.
V týdnu, kdy (Kadiza) přemýšlela o útěku z území Islámského státu, byla při pokusu o útěk chycena jedna Rakušanka a podle dostupných informací byla veřejně ubita k smrti.
Myslím, že si to (Kadiza) vyložila jako varování a rozhodla se neriskovat, míní podle BBC Akunjee.
Rodina by udělala cokoli.
Kadiza Sutlanaová se spolu s 15letými kamarádkami ze školy Shamimou Begumovou a Amirou Abasovou vydaly na cestu 17. února loňského roku.
Doma řekly jen to, že jdou ven.
Zamířily ale na letiště Gatwick a z něj přes Turecko na území ovládané IS.
Rodina dívky podle právníka dělala vše, co bylo v jejích silách, aby Kadizu dostala zpět.
Snesli byste modré z nebe, jen abyste dostali své dítě z nebezpečné oblasti a tahle rodina udělala vše, co mohla, napjala všechny síly, aby dostala svou dceru domů.
Nebylo to ale možné bez toho, aniž by riskovali, že budou sami chyceni, dodal právník.
Jediným pozitivem podle něj je, že může osud Kadizy posloužit jako odstrašující případ pro další dívky nebo i chlapce, kteří se nechají ošálit islamistickou propagandou.
"Je mnoho případů, kdy se tam lidé vydali, uvědomili si, jak se tam věci mají, pochopili, jak dalece se to liší od slibů propagandy Islámského státu, a chtěli se vrátit," konstatoval dále Akunjee.
Osud Kadiziných spolužaček není známý.
Jelikož se ale také odmlčely, musejí se jejich rodiny smířit s tím, že jsou s největší pravděpodobností mrtvé.
Do vězení za peníze.
Ve Skotsku lze jít za mříže i bez spáchání zločinu.
Mnoho staletí byla obec Inveraray krajským centrem a sídlem vévody z Argyllu.
Od poloviny 18. století se na radnici konaly soudy a suterén pod síní sloužil jako lokální vězení.
Podmínky, ve kterých trestanci přebývali, byly žalostné a o útěk se pokusilo mnoho vězňů.
Spousta z nich i úspěšně.
Proto se městští zástupci rozhodli prostory věznice přesunout na nové místo.
Nová budova byla dokončena v roce 1848 a byla k vězňům mnohem přívětivější, měla topení a plynové osvětlení.
Tak či tak v provozu dlouho nebyla, k jejímu uzavření došlo z ekonomických důvodů už koncem srpna 1889, jelikož menší nápravná zařízení byla nákladná na provoz a příliš se nevyplácela.
Příběhy trestanců i hon na duchy.
Pro veřejnost se věznice otevřela o celé století později, návštěvníci mohou porovnat starou budovu s novou, aby se sami přesvědčili, jak rozdílné podmínky v nich panovaly.
Průvodci v dobových kostýmech autentický zážitek ještě umocňují.
K vidění je také mučicí místnost, ve které se návštěvníci mohou dozvědět, jaké formy trestů se na zločince uplatňovaly, ať už to bylo lámání prstů nebo vypalování značek na tělo.
V rámci prohlídky se mohou turisté nechat zavřít do jedné z cel, většinou kvůli fotografii na památku, nebo aby si navodili pocit, který za mřížemi prožívají vězni.
Mimoto je věznice Inveraray jednou z nejznámějších skotských lokalit, kde údajně straší.
Vydalo se tam již několik skupin lovců paranormálních aktivit a dodnes muzeum umožňuje lidem, aby přišli nějaké duchy lovit.
Taková noc ovšem vyjde na 300 liber, což je v přepočtu zhruba 9500 korun.
Obce kromě této populární turistické atrakce láká také na skvělé jídlo, okolní panoramata a historii.
„Animé“ efekt na Snapchatu je kritizován jako asijská karikatura
Podle Snapchatu je tento filtr inspirován animé, ale někteří pozorovatelé říkají, že je rasově necitlivý.
Aplikace Snapchat každý den umožňuje asi 150 milionům uživatelů měnit realitu a pohrávat si s identitou způsoby, které hraničí s absurditou.
Můžete ze sebe udělat ananas, psa nebo postavu, která jako by vystoupila z obrazu Roye Lichtensteina.
Filtry jsou jednoduché nástroje, které deformují realitu a každý den generují více než 30 milionů vylepšených selfíček.
Jakákoliv chybička se ihned uveřejní.
Filtry Snapchatu si v minulosti vysloužily kritiku s obvinění, že aplikace propaguje blackfacing nebo že podporuje bílé odstíny kůže jako ideál krásy.
Takže když tenhle týden uživatelům nabídla filtr, díky kterému měli šikmé oči, pokřivené zuby a nafouknuté tváře, někteří kritici to označili za rasistickou karikaturu Asiatů - „yellowface.“
A ptali se, zda tyto opakované sporné otázky nepoukazují na větší problém společnosti - problém s diverzitou.
Ve středu o tom Verge a Motherboard napsaly a novinka a rozhořčení se rychle rozšířily a Snapchat hned další den uvedl, že funkci zrušil.
Společnost nabídla vysvětlení: Filtr byl zamýšlen jako projev účty postavám animé, ne jako karikatura Asiatů.
Ale pozorovatelům, kteří byli svědky rasismu, filtr připoměl bolestivé stereotypy v akci.
Ostatní bez obalu srovnání s animé odmítli.
Grace Sparapani, studenta amerického umění z Koreje, jejíž tweet o fotografiích byl široce sdílen, v e-mailu uvedla, že filtr byl „přinejmenším škodlivý a trapný.“
Dodala, že „je těžké argumentovat proti srovnání očividné asijské karikatuře a efektů filtru.
Ukazuje se, že filtr není pouze o žlutém obličeji (yellowface), ale že žlutý obličej je dotažen do pohrdavého extrému.
Snapchat není jedinou společností, která tyto kulturní meze překročila.
Zdá se, že americká kultura v sobě má nekonečný zápas o diverzitu a inkluzi, od zasedacích síní v korporacích po Holywood a zařízení, která všichni nosíme v ruce.
A obrovské množství mladých lidí na Snapchatu - kteří jsou více rasově diverzifikovaní než jejich starší partneři - může znamenat, že lze očekávat ještě větší citlivost.
„Když jeden filtr Snapchatu vytvoří obrázek, který je pro některého uživatele urážlivý“, řekla pětadvacetilá Katie Zhuová ve čtvrtek v rozhovoru, „jen velmi těžko se tyhle věci dnes obejdou bez povšimnutí, jako tomu bylo dřív.“
Katie Zhuová, produktová manažerka a návrhářka, která pracuje pro Medium, se ve čtvrtek rozhodla svůj účet na Snapchatu smazat a vyzvala ostatní, aby udělali to samé.
V článku pro Medium a v rozhovoru po telefonu uvedla, že je přesvědčena, že rasově motivované problémy odrážejí nedostatek diverzity při náborech pracovníků v Snapchatu.
Katie Zhuová kritizovala převážné bílé, zcela mužské vedení společnosti a článek zakončila hash tagem: #DeleteSnapchat.
„Je to buď tak, že nemají mezi zaměstnanci žádnou diverzitu a barevné lidi v okamžiku, kdy se o těchhle věcech rozhoduje,“ řekla Zhuová, která má čínsko-americký původ, „nebo tam barevní lidé pracují, ale ne na pozicích, aby se cítili bezpečně nebo příjemně, aby promluvili.“
Jiní pozorovatelé sdílí její názor - stížnost, kterou Snapchat nechal ve značné míře bez odpovědi.
Společnost neuveřejňuje čísla týkající se diverzity jejích zaměstnanců s tím, že má statut soukromé společnosti.
Ve čtvrtek Snapchat odmítl hovořit o rasovém původu svých zaměstnanců, ale podle mluvčího společnost nedávno přijala náborového pracovníka, který by se měl zaměřit na nedostatečně zastoupenou populaci a na interní řízení inkluze.
Zhuová dodává: „Jsem zvědavá, jestli opravdu potřebují další takové uživatele, kteří dokáží říci, že to není v pořádku,“ s tím, že svůj účet zůstane zrušený.
Armádní důstojníci zkreslovali zpravodajské informace o IS, říká parlamentní výbor
Parlamentní výbor ve zprávě vydané ve čtvrtek uvedl, že důstojníci z ústředního velitelství Spojených Států měnili zprávy zpravodajské služby, aby vykreslovaly více optimistický obrázek války proti Islámskému státu v Íráku a v Sýrii, než jaký poskytovaly události ze země.
Podle předběžné zprávy pracovní skupiny sestavené republikánským předsedou Výboru pro ozbrojené síly, Výboru pro zpravodajské služby a Podvýboru pro obranu, byla zjištěna „rozsáhlá nespokojenost“ mezi analytiky ústřední zpravodajské služby, podle kterých jejich nadřízení měnili jejich hodnocení amerického úsilí porazit Islámský stát.
Ústřední velitelství, známé jako CentCom, je armádním ústředním v Tampě na Floridě, které dohlíží na americké vojenské operace na Středním východě a ve Střední Asii.
V tiskovém prohlášení ke zprávě se uvádí: „Výstupy zpravodajských tajných služeb schvalované nadřízenými důstojníky Centcomu obvykle nabízely pozitivnější obraz protiteroristických snah USA, než jaké byly potvrzeny skutečnostmi na zemi, a byly konzistentně pozitivnější, než analýzy získávané z jiných částí zpravodajského společenství.“
„Co se stalo v Centcomu, je nepřijatelné - naši bojovníci jsou poškozeni, když je nadřízeným tvůrcům politiky předložena chybná analýza,“ řekl Ken Calvert, kongresman a republikán z Kalifornie.
Selhání ve vedení Centcomu sahá až na vrchol organizace.
V desetistránkové zprávě jsou podrobně popsány přetrvávající problémy ústředního štábu při popisu a analýze amerických snah při tréninku íráckých sil v letech 2014 a 2015.
I když se nenabízí žádný rozhodující důkaz o tom, že vrchní představitelé Obamovy administrativy nařídili, aby zprávy byly pozměňovány, uvádí se ve zprávě, že analytici měli dojem, že byli ze strany lídrů Centcomu pod tlakem, aby prezentovali optimističtější pohled na nebezpečí představované Islámským státem, neboli IS.
„V první polovině roku 2015 bylo mnoho tiskových zpráv ústředního štábu, prohlášení a výpovědí z kongresu podstatně pozitivnějších, než jaké události ve skutečnosti byly,“ uvádí se ve zprávě.
Například představitel Centcomu veřejně prohlásil, že zásadní vojenský útok k převzetí Mosulu by mohl začít již v dubnu nebo v květnu 2015.
Mosul, druhé největší město Íráku, zůstává i nadále pod kontrolou Islámského státu.
„Toto je po měsících vyšetřování zcela jasné,“ řekl v prohlášení poslanec Mike Pompeo, zástupce republikánské strany z Kansasu.
Od poloviny roku 2014 do poloviny roku 2015 manipulovali nejvýše postavení pracovníci zpravodajských služeb ústředního štábu USA s výstupy zpravodajských služeb štábu s cílem bagatelizovat nebezpečí IS v Íráku.
Republikáni sestavili pracovní skupinu poté, co se dozvěděli o obavách analytiků o tom, že informace zpravodajských služeb týkající se Islámského státu jsou manipulovány.
Po zprávě uveřejněné ve čtvrtek musí po dalším vyšetřování následovat podrobnější zkoumání.
Ve zpravodajských službách Centcomu probíhá ještě další vyšetřování vedené generálním inspektorem ministerstva obrany.
Demokratičtí členové Výboru pro zpravodajské služby uveřejnili ve čtvrtek svá vlastní zjištění, která odpovídala některým závěrům pracovní skupiny republikánů.
„Mezi roky 2014 a 2015 Centcom vytvořil velmi úzký proces pro sestavování hodnocení informací o IS a íráckých bezpečnostních složkách,“ uvedl v prohlášení reprezentant Adam B. Schiff, předseda Výboru a zástupce demokratů.
Podle slov Adama Schiffa tento proces „vedl k překrucování výstupů zpravodajských služeb,“ poškodil morálku mezi analytiky a „nedostatečně zohledňoval nesouhlasné názory.“
Nicméně Schiff a demokraté tvrdí, že nenašli žádný důkaz o tom, že by se Bílý dům pokoušel tlačit na analytiky Centcomu, aby upravili své závěry podle „předlohy nebo politické situace.“
Předběžné výsledky parlamentního vyšetřování byly v úterý uveřejněny v Daily Beast.
Loni v srpnu New York Times informovaly o probíhajícím vyšetřování generálního inspektora Pentagonu, které bylo zahájeno po stížnostech analytiků Centcomu.
Komandér-poručík Patrick Evans, mluvčí Pentagonu, v prohlášení uvedl, že ministerstvo obrany parlamentní zprávu nebude komentovat, protože vyšetřování generálního inspektora stále ještě pokračuje.
Uvedl ale, že „odborníci se někdy neshodují na interpretaci komplexních údajů, a že zpravodajské společenství a ministerstvo obrany vítají zdravý dialog ohledně těchto zásadních otázkek národní bezpečnosti.“
Vyšetřování má dopady nad rámec otázky, zda je Američany vedené bombardování v Íráku a Sýrii úspěšné (výrok, který nyní prohlašuje rostoucí počet představitelů obrany).
Nicméně loňská obvinění vyvolala otazníky ohledně toho, do jaké míry se prezident Obama může spolehnout na to, že ústřední štáb upřímně hodnotí vojenské operace v Íráku, Afghánistánu, Lybii a dalších krizových místech.
Kritika zpravodajství ohledně Islámského státu odráží konflikty již více než deset let, kdy analytik zpravodajských služeb Centcomu Gregory Hooker napsal výzkumnou práci, ve které se uvádělo, že administrativa prezidenta George W. Bushe - navzdory námitkám mnoha analytiků - obhajovala malou jednotku v Íráku a věnovala jen málo času přemýšlení o tom, co bude následovat invazi v roce 2003.
Hooker hrál také klíčovou roli v odporu proti zpravodajským službám Islámského státu.
Minulý rok úřady oznámily, že Hookerův tým dospěl k závěru, že navzdory veřejným prohlášením o opaku, vzdušné údery vedené proti rafineriím Islámského státu nijak výrazně finanční zdroje této teroristické skupiny neoslabily, protože skupina vybudovala dočasné rafinerie a ropu prodává na černém trhu.
The Times v září informoval o tom, že zjištění ale nebyla předána mimo ústřední štáb.
Velitel Centcomu, gen. Lloyd J. Austin III, byl pak podroben kritice uplynulý rok poté, co mnoho zákonodárců shledalo svědectví Senátu příliš pozitivním hodnocením války.
Generál Austin v dubnu odstoupil a v Centcomu jej nahradil gen. Joseph L. Votel.
USA zvítězily v pozemním hokeji ve čtvrtém zápase v řadě, takže dnes se bude hrát rozhodující zápas v týmem Velké Británie
Katie Bamová v zápase proti Japonsku, který skončil vítězstvím 6:1, vstřelila tři branky a pouhý den poté pro americký ženský tým pozemního hokeje vstřelila první dvě branky zápasu, ve kterém ve čtvrtek Amerika porazila Indii 3:0.
Pět branek ve dvou zápasech je úspěch hodný zapamatování, ale Bamová (27) řekla, že si není jistá, zda se jí někdy něco takového podařilo.
„Nemám ponětí,“ řekla.
Nepatřím mezi ty, kdo si své branky zapisují.
Tohle ale ví: Američane na olympijském turnaji vedou na zápasy 4:0 a dělí se o první místo ve skupině s Velkou Británií, která zůstala ve čtvrtek po porážce Japonska 2:0 zůstala neporažená.
Velká Británie a Spojené státy se střetnou v sobotu v posledním zápase prvního kola.
Oba týmy se kvalifikovaly do čtvrtfinále a zápas rozhodne o tom, kdo ze skupiny šesti týmů skončí na prvním a kdo na druhém místě.
Tým z prvního místa se o něco déle vyhne silným Dánům, kteří jsou na čele druhé skupiny.
Ať už sobotní zápas skončí jakkoliv, Američané zde svou překvapivou jízdou vyvolali rozruch, čtyři roky po té, co skončili mezi 12 týmy na hrách v Londýně.
V tom týmu byla i Bamová.
Vyrostla v Blue Bell, v Pensylvánii, a hokejku na pozemní hokej vzala poprvé do ruky, když jí byly 3 roky (její starší sestry dvojčata hrála v Drexelu) a do národního týmu vstoupila, když jí bylo 16 a stala se jeho nejmladší hráčkou vůbec.
Olympiáda v 2008 jí unikla, protože se nedostala na finální soupisku.
Pak přišel rok 2012, kdy se moc nedařilo ani jí, ani členkám jejího týmu.
Další rok byl trenérem jmenován Angličan Craig Parnham a věci se začaly měnit.
„Kulturní změna, duševní změna, fyzická změna,“ řekla Bamová.
V Londýně jsme neměli takové pracovní tempo, jako máme dnes.
Udělali jsme úplný obrat.
Ve čtvrtek v noci Bamová zahájila v první polovině vstřelením branky bekendem z blízkosti.
Indie do zápasu nastoupila bez vítězství v turnaji, ale tým se ukázal jako překvapivě tvrdý a udržel skóre 1:0 až do závěru třetí čtvrtiny, kdy Bamová využila příležitosti.
Unikla po levé straně hracího pole, pak se prokličkovala do středu a vstřelila míček do branky, aby dostala Američanky do vedení 2:0.
Melissa Gonzalezová přidala poslední branku v půlce čtvrté čtvrtiny.
Vyřazení brankářky Američanek, Jackie Briggsovou, která v každém ze tří vítězství pomohla k jedné brance, bylo vůbec první na turnaji.
Je ve výborné formě.
Stejně jako Bamová.
„Teď jsme na dobrém místě,“ řekl Parnham, ale jak dobré to je, to bude záležet na výsledku sobotního zápasu.
Zen trampolíny uprostřed olympijského běsnění
Je jedno, kde jste, je jedno, kolik je hodin - je olympiáda.
Z událostí v Riu de Janeiru je cítit vytrvalé, nepopsatelné a zaujaté střídání soutěživosti a úsilí.
Je to, jak by sama olympijská pochodeň byla žhavým štafetovým kolíkem, který se předává od lustřelce plavci, gymnastce a triatlonistovi.
Nemůžete zapnout televizi, přečíst si noviny nebo poslouchat rozhovor vašeho souseda ve frontě v kavárně, aniž byste neslyšeli o Simone Bilesové, Katie Ledecky nebo nevraživosti mezi Michaelem Phelpsem a Chadem le Closem.
A pak je taky Logan Dooley.
Dooley, nadcházející miláček žen s dolíčky ve tvářích, je na olympiádě poprvé a mohl by být také mezi těmi, jejichž jména zazní v domácnostech v hlavním vysílacím čase mezi reklamou a spoty sponzorů, pokud by byl plavcem, gymnastou nebo dokonce šermířem.
Ale Dooley (28) z Lake Forest v Kalifornii bojuje o olympijské zlato ve skocích na trampolíně.
Olympijský oheň nesvítí na všechny soutěže stejně.
Dál od středu, trochu ve stínu jsou sporty, které nejsou všeobecně uznávané: střelba ze vzduchových pistolí, lukostřelba, badminton, taekvondo.
Vždy budeme mít úspěch v klasickém plaveckému stylu - a bude nejspíš vládnout dlouho.
Ale pokud mohu jmenovat svého mimořádného favorita, dovolte mi upozornit na nenápadné kouzlo trampolíny.
I když jsou skoky na trampolíně olympijským sportem od roku 2000, kdy byly poprvé uvedeny na hrách v Sydney, zůstává po 16 letech intervencí tento sport téměř bez povšimnutí - mnoho lidí, kterých jsem se dotazoval, ani nevědělo, že je to olympijský sport.
Může jít o regionální lhostejnost.
USA nikdy medaili ve skocích na trampolíně nezískaly a až do roku 2012 se žádný z atletů nedostal ani do finále.
Ceny v mužské kategorie se obvykle dělí mezi Čínu a Rusko a v ženské kategorii mezi Čínu a Kanadu.
Letos budou zlaté medaile z Londýna objahovat Dong Dong z Číny a Rosie MacLennanová z Kanady.
Skoky na trampolíně mají ale ještě další smůluo, částečně proto, že uchu nezasvěceného se bude spíš zdát, že se víc hodí na klaunskou univerzitu, než na olympiádu.
Musím se přiznat, že nejsem odborník, ale pouze nadšenec sledující ze země.
Má to komický potenciál - komiksové vibrace nekonečného odrážení - ale také ladnost gymnastiky a potápění, dvou sportů, které v sobě kombinuje.
Slovo „trampolína“ je odvozené ze španělského „el trampolín“, které znamená „skokanská deska.“
Aspirující šampioni skáčí na obrovské trampolíně, která je vystřelí do výšky až téměř 10 metrů a předvádějí sestavy s několika prvky (salta, vruty a kombinace), než konečně opět přistanou na nohách.
Podle oficiálního olympijského programu jsou hodnoceni podle provedení, obtížnosti a „doby ve vzduchu“.
V Riu bude soutěžit dvaatřicet atletů ze 17 zemí, 16 mužů a 16 žen.
Obvyklá trajektorie olympijské dráha je vpřed.
Bojovníci o zlaté medaile musí jít dál, rychleji a ještě výš, někdy až do konce, jindy tam a zpět, nahoru a dolů.
Snaží se dohonit nejen cílovou pásku nebo startovní zeď, ale jak uvádí televizní zpravodajství, také jinou pomyslnou linii: světový nebo olympijský rekord.
Toto jednomyslné snažení je noblesní, obdivuhodné, trochu fanatické - a dostatečné k tomu, aby diváky přivedlo k slzám.
Ale je to podle mě zároveň poněkud vyčerpávající, když olympiádu sledujete.
Skoky na trampolíně v tomto ohledu přinášejí úlevu.
Dráha atleta na trampolíně je směrem vzhůru.
Smyslem není pohyb vpřed.
On nebo ona se odráží, jako by byli ve stavu bez tíže jako astronauti, letí nahoru, pak dolů, a pak opět bez námahy nahoru.
Bez soutěže a samozřejmě ani obtížnosti to nejde, ale po dobu trvání sestavy nevládne žádný zuřivý boj o dosažení cíle, žádné odměřování vzdálenosti, ale jenom dokonalé, ladné pružení času a gravitace.
Tohle jen nejblíž, kdy se olympiáda a zen přiblíží.
Kvalifikace a finále žen se koná v pátek odpoledne, ve 13 hodin východního času, mužské soutěže pak v sobotu ve stejný čas.
Stanice NBC bude finále vysílat v rámci odpoledního bloku, který začíná po oba dny ve 14 hodin.
Uprostřed olympijského šílenství slibují klidné, příjemné chvíle, které přes ostatní souboje nejspíš přehlédnete.
A pokud se má pozornosti dosáhnout pouze tak, že mužští atleti budou předmětem zamilovaných pohledů a zhmotnění - jak podle časopisu Wall Street Journal nedávno navrhli gymnasté USA - pak Logan Dooley pouze čeká na své nové fanoušky, kteří lapají po dechu.
„Protestující generace“ v Etiopii, dlouholetém spojenci USA
Násilné protesty v Etiopii
Demonstranti požadující politické změny v Etiopii narazili na násilný odpor vlády.
Svědci tvrdí, že během střetů s policií bylo zastřeleno mnoho protestujících.
Hrozí v Etiopii válka?
V uplynulém desetiletí to byl jeden z nejstabilnějších národů v Africe, pevná západní aliance s rychle rostoucí ekonomikou.
Během posledních měsíců ale zemi zachvátily protivládní nepokoje, které se šíří do stále více oblastí.
Jen za poslední týden vyrazily do ulic tisíce lidí, kteří požadují zásadní politické změny.
Podle organizací bojujících za lidská práva byla reakce vlády nemilosrdná.
Svědkové tvrdí, že policisté zastřelili a zabili zástupy neozbrojených demonstrantů.
Na kolujících videonahrávkách z protestů, které pocházejí pravděpodobně ze závěru minulého roku nebo začátku tohoto roku, jsou zachyceni příslušníci bezpečnostních sil, jak mlátí mladé lidi holemi poté, co byli donuceni stát u zdi na rukách.
Vysoký komisař OSN pro lidská práva nyní žádá důkladné prošetření.
„Vždy bylo obtížné udržet tuto zemi pohromadě a udělat krok vpřed bude ještě těžší,“ prohlásil Rashid Abdi, vedoucí projektu Horn of Africa pro výzkumnou skupinu International Crisis Group.
Etiopie je po Nigerii druhým nejlidnatějším národem v Africe a její stabilita je podporována Západem.
Americké vojenské a zpravodajské služby úzce spolupracují s Etiopany na odstraňování nebezpečí teroristického útoku v oblasti, především v Somálsku, a málokterá z afrických zemí, pokud vůbec nějaká, získává takovou pomoci ze Západu.
Ekonomika Etiopie se vyvíjela působivým tempem.
Její infrastruktura se zásadním způsobem zlepšila - v hlavním městě Addis Abeba jezdí dokonce nový příměstský vlak.
A ulice města jsou typicky klidné, bezpečné a čisté.
Ovšem Etiopii lze ztěží označit za vzor demokracie - organizace bojující za lidská práva bez ustání hovoří o vládních represích - opozice v zemi byla potlačena, disidenti efektivně umlčeni.
Mnoho jich bylo vypovězeno, uvězněno, usmrceno nebo vyhnáno daleko do pouště.
To se však může změnit.
„Když lidi dusíte a oni nemají jinou možnost než protestovat, dojde k prolomení,“ řekl Seyoum Teshome, který přednáší na univerzitě v centrální Etiopii.
Protestuje veškerá mládež.
Protestuje celá generace.
Stížností je mnoho a týkají se všeho od sporů o půdu po absolutní kontrolu moci vládnoucí koalice.
Po loňských volbách, které byly široce kritizovány, získala vládnoucí strana a její spojenci poslední křeslo držené opozicí a nyní kontroluje v parlamentu 100 procent.
Zároveň narůstá tlak na hranici s Eritreou. Konflikt podél této nepřesně vyznačené, sporné hranici si v červnu vyžádal stovky životů.
Anylitici se obávají, že separatistické skupiny, které byly během uplynulých let víceméně potlačeny, jako je Oromská osvobozenecká fronta nebo Ogadenská národní osvobozenecká fronta, se mohou pokusit zmatek využít a znovu se vyzbrojit.
Existuje několik faktorů, které vysvětlují, proč se nyní po letech doutnání pod povrchem, tyto hořké pocity znovu rozhořely.
První z nich je zdánlivě neškodný: chytré telefony.
Mnoho Etiopanů může komunikovat prostřednictvím sociálních sítí až několik posledních let, kdy se staly běžně dostupnými levnější chytré telefony a zlepšilo se poskytování internetových služeb.
A i když vláda zakáže přístup na Facebook nebo Twitter, jako se tomu běžně děje především během protestů, mnoho lidí může stále komunikovat přes internetové proxy, které skryjí polohu těchto lidí.
Několik mladých Etiopanů promluvilo o tom, jak se shromažďovali na protesty.
Dále existuje větší solidarita mezi Oromy a Amhary, dvěma největšími etnickými skupinami v Etiopii.
Oromové a Amharové nejsou přirozenými spojenci.
Po dlouhé věky Amharové, převážně z křesťanských vrchů Etiopie, vynikali v politice a obchodu a využívali Oromy, z nichž jsou mnozí muslimové a žijí v nížinách.
Ale to se také mění.
„Jsme se na cestě ke sjednocenému vedení,“ řekl Mulatu Gemechu, lídr Oromů.
K největším protestům došlo v oblastech obývaných Amhary a Oromy.
Mnoho Amharů a Oromů se domnívá, že Etiopii neprávem dominují členové etnika Tigrajů, které tvoří okolo 6 procent populace a ovládá armádu, zpravodajské služby, obchod a politiku.
Třetím důvodem nepokojů je úmrtí Melese Zenawiho.
Zenawi, dřívější vůdce povstalců, byl etiopským předsedou vlády celých 17 let až do své smrti v roce 2012, kdy podlehl neuvedené nemoci.
Byl považován za taktického génia, za člověka, který dokázal vidět za roh.
Analytici říkají, že obzvlášť mistrně dokázal odhalovat prvotní signály nespokojenosti a využíval vyslanců, aby oponenty zpracovali a získali na jeho stranu.
„Současný režim postrádá základní vědomosti,“ řekl Abdi, analytik konfliktu.
Nový předseda vlády Etiopie, Hailemariam Desalegn, byl vytažen z relativní neznámosti s cílem nahradit Zenawiho.
Na rozdíl od Zenawiho, který pocházel z Tigrajské oblasti severní Etiopie, pochází Hailemariam z jihu.
Analytici tvrdí, že nemá důvěru v bezpečnostní služby ovládané Tigrejci.
Mnozí se obávají, že výsledkem bude další prolévání krve.
Naposledy Etiopie zažila takovéto nepokoje v roce 2005 po té, kdy tisíce lidí protestovaly proti tomu, co analytici označili jako volby, které vláda zbabrala a pak ukradla.
Následoval tvrdý zásah, během kterého bylo mnoho protestujících zabito - i když méně než v uplynulých měsících - a tohle období nepokojů přešlo relativně rychle.
Odborníci na rozvoj ocenili lídry Etiopie za vizionářské plánování infrastruktury, jakým je nový příměstský vlak a měřitelný pokrok v boji s chudobou.
Ovšem je zcela zřejmé, že postupné narůstání sporů uvnitř etiopské vlády to nezastavilo.
A dochází k nebezpečnému etnickému formování.
Minulý měsíc protestující v amharském městě Gondar napadli obchodní firmy vlastněné Tigrejci a zášť proti Tigrejcům na sociálních sítích se stále běžnější.
Analytici říkají, že protesty staví do nepříjemné situace USA a další západní spojence.
Americká vláda využívá Etiopii jako základnu pro přelety dronů nad sousedním Somálskem, i když nedávno prohlásila, že základna byla uzavřena.
Zatímco Západ chce jednoznačně podporovat demokracii, tak současně nechce, aby se jeho spojenec v již tak nestálé oblasti rozpadl.
„To,“ řekl Abdi, „je velmi ostrá hrana ostří.“
Donald Trump vysvětluje svůj výrok o Obamovi a financování IS jako „sarkasmus“
Donald J. Trump se v pátek pokusil bagatelizovat nejnovější kontroverzi, která zaplavuje jeho kampaň, prohlášením, že to nemyslel vážně, když několikrát tento týden trval na to, že preziden Obama a Hillary Clintonová byli „zakladateli“ teroristické skupiny Islámský stát.
Vysvětlení vyvolalo nové otázky ohledně schopnosti republikánského kandidáta na prezidenta hovořit jasně s americkou veřejností.
Staví do nepříjemné situace také jeho zastánce, kteří jej usilovně v bouřlivé době bránili a musí vysvětlovat, že své poznámky možná nemyslel vážně.
Po tomto návrhu na schůzi ve středu v noci Trump výrok ve čtvrtek potvrdil a v rozhovorech trval na tom, že skutečně neměl v úmyslu říct, že prezident a H. Clintonová IS stvořili.
Ovšem v příspěvku na Twitteru v pátek ráno Trump prohlásil, že byl pouze sarkastický.
Příspěvek byl opakem tvrzení starého pouhý jeden den, kdy Trump v několika rozhovorech řekl, že své obvinění naopak myslel vážně.
Když se konzervativní rozhlasový moderátor Hugh Hewitt pokusil pomoci Trumpovi poznámku zmírnit připomenutím, že Obama usiluje o zničení IS, kandidát republikánů na prezidenta nereagoval.
Nejnovější bouře přichází v okamžiku, kdy se Trump pokusil o zaměření pozornosti své kampaně na ekonomiku, zatímco jeho preference v předvolebních průzkumech klesají.
Trump a Clintonová se tento týden účastnili v Michiganu duelu k ekonomickým otázkám.
V pátek se Trump pokusil k tomuto tématu opět vrátit.
Na Twitteru opět varoval, že návrhy Clintonové jsou spojeny se zvýšením daní, a uvedl, že podle nějk byla její řeč nudná.
Trump použil obranu sarkasmem již dříve.
Na konci července, když sklidil vlnu kritiky, když vystoupil s návrhem, že by Rusové měli proniknout k e-mailům Clintonové, svou poznámku později vysvětlit slovy: „Jsem samozřejmě sarkastický.“
Tento přístup Trumpovi umožňuje tlačit hranice politických prohlášení a mírnit je podle potřeby.
„Myslím, že je to jeho způsob testování, do jaké míry mají některé zprávy odezvu u jeho příznivců, aby zjistil, jakým způsobem reagují, a podle reakce pak jedním nebo druhým způsobem „podal vysvětlení“, řekl Ruth Sherman, specialista na komunikaci, který sledoval jazyk, který oba kandidáti používali.
Také si ale myslím, že je ve svých prohlášeních obratný a ví, že jsou dostatečně vágní na to, aby je bylo možné vysvětlovat různě.
Protože výsledky předvolebních průzkumů v jeho prospěch i nadále klesají, zvolil Trump v posledních dnech ještě více uštěpačný tón, namísto toho, aby věci mírnil pro všeobecné voliče.
Nový průzkum NBC/Wall Street Journal/Marist, který byl uveřejněný v pátek, ukázal, že Tump je s velkým odstupem za Clintonovou v Severní Karolíně, Virginii a Koloradu a velmi těsně za ní na Floridě.
Trump se vůbec pokouší vyhnout se omluvám za provokativní výroky, které říká, ale často své kritiky obviňuje z chybných interpretací svých slov nebo nepochopení jeho smyslu pro humor.
Ale spolu s tím, jak Trump v závěrečných měsících prezidentské kampaně čelí zvýšené pozornosti, uvedly Trumpovy vtipy do nepříjemné situace jeho oddané stoupence, kteří za ním musí veřejně stát, ať už jsou jeho poznámky jakkoliv provokativní.
Rudolph W. Giuliani, dřívější primátor města New York, který je jedním z nejprominentnějších Trumpových stoupenců, musel kandidáta ve čtvrtek v rozhovoru pro CNN obsáhle obhajovat.
„Domnívám se, že to, co říká, je oprávněný politický komentář,“ uvedl Giuliani, když byl dotázán na věrohodnost Trumpova tvrzení o tom, že Obama a Clintonová založil Islámský stát.
To je pravda v tom smyslu, že před Obamou byl IS téměř neznámá, malá organizace, kterou zcela chybně nazýval nováčkem. A došlo k tomu proto, že stáhl svá vojska z Iráku.
Většina běžných republikánů se pokouší argumentovat tím, že Obamova vláda, ve které Clintonová působila jako ministryně zahraničních věcí, dovolila, aby IS bujelo a nedokázala situaci na Středním východě agresivně zvládnout.
Před pátečními shromážděními v Pennsylvánii Trump i nadále na Twitteru okolo sebe dštil oheň na sdělovací prostředky za to, že přemílají každé jeho slovo a jsou vůči němu zaujatí.
Vysmál se „ubohým, patetickým“ televizním učencům, kteří se jej pokouší pochopit, a řekl: „To nedokáží!“
Několik demokratů se Trumpově omluvě ušklíblo s tím, že je to jen další důkaz toho, že pro prezidentský úřad není způsobilý.
Kavárnu vytlačily z trhu ceny. Nyní se vrací v Greenpointu
Kavárna Verb Cafe bylo ošuntělé místo ve Williamsburgu, kde jste mohli platit jenom hotově, bez Wi-Fi, ale kde se káva podávala již 15 let.
Přirozeně došlo k tomu, že byla z průčelí domu na Bedford Avenue vytlačena.
Soap Cherie - obchod, který Verb v létě 2014 nahradil - prodává mýdla ve tvaru dortíků.
Místní to oplakali jako poslední ztrátu rozrůstajícího se města.
Umělkyně Molly Crabappleová na Twitter napsala: „New York je změna, vím, ale stále nedokážu uvěřit, že je CBGB mrtvý, hotel Chelsea vypleněný a z Verb je nyní obchod mýdlem.“
Ale je-li New York změna, pak je to také znovuobjevování.
Vzkříšené Verb Cafe se otevřelo loni v listopadu v Greenpointu, méně než míli severně od původního místa.
Nové Verb má wifi a přijímá platební karty, ale pracují tam někteří z původních zaměstnanců a panuje tam podobná, skromná atmosféra.
Také káva je stále dobrá.
Manažerem nového Verbu je Cisco Rodriguez, dlouholetý zaměstnanec původní kavárny, který je zároveň vlastníkem a výkonným ředitelem nového místa.
Ve Verb začal v roce 2001 a zůstal až do konce.
Když mu jeden ze zákazníků nabídl, že zaplatí přesun na nové místo, řekl, že to udělá s radostí.
Rodriguez (36) ponechal hodně věcí tak, jak byly.
Verb má stále stejného dodavatele pečiva a koupil stejný model stroje na espresso.
Dokonce i znovu použil osvětlení ze starého Verbu.
Rodriguez ale řekl, že chtěl také vyzkoušet něco nového.
Začal používat nové přísady.
V nabídce jsou sendviče se šunkou, vejcem a sýrem a toppingy, jako jsou kapary a smažená cibulka.
Najdete tu také misky s hnědou rýží.
Kavárna již nepodává pivo, ale nabídce vám čerstvé ovocné šťávy.
Po devíti měsících si Rodriguez všiml stálého přílivu původních štamgastů.
„Řada původních zákazníků se z Williamsburgu také musela kvůli cenám vystěhovat“, řekl.
Minulou neděli tu byla jedna z takových zákaznic, Rebecca Oliveirová.
Paní Oliveirová (34) žila ve Williamsburgu a do Verb Cafe chodila často.
Docházela dokonce i pak, když se kavárna přestěhovala do Greenpointu.
Řekla, že když Verb zavřel, na nějakou dobu úplně přestala pít kávu.
„Zjistila jsem, že to, co mám ráda, je káva a kultura ve Verbu,“ řekla.
Nyní opět pije kávu, ale v onen den si místo své obvyklé ledové kávy dala míchaný chai, další novinku.
Tom Rosenthal, další dlouholetý zákazník, oddaně chodí do Verbu od roku 2003.
Chodí se před prací a objednává si vždy to samé.
„Ve čtvrt a osm sem každý den, jako hodinky, přijdu a už pro mi připravují mou housku se vším a s máslem,“ řekl.
Foto: Rodriguez řekl, že chtěl vyzkoušet něco nového a přidat do nabídky nové přísady.
Pan Rosenthal si i nadále objednává to, co obvykle, ale občas si na svou housku se vším nechá dát slaninu, vejce a šunku.
Rodriguez řekl, že mu není líto, že obchod s mýdly zabral jeho staré místo.
Pravdou je, že vlastníci Soap Cherie mu nabídli, že pro Verb vyrobí speciální mýdlo a jako přísadu použijí filtrovanou kávu z kavárny.
„Myslím, že bychom to stále mohli využít,“ řekl Rodriguez.
Také tradiční polští obyvatelé Greenpointu kavárnu přijali dobře.
Jeden z nových zákazníků nabídku přeložil do polštiny a Rodriguez říkal, že chce najít místo, kam ji brzy vystaví, aby se zde jeho noví sousedé cítili jako doma.
Nové místo má ještě další výhody.
Místní výrobce ovocných šťáv chce stáčet do lahví a prodávat filtrovanou kávu.
Nabízí se možnost, aby se kavárna rozšířila do sousední budovy.
Mnoha zákazníkům stačí, že získali zpět svého starého favorita.
Joseph Whitt byl pravidelným zákazníkem a když kavárna zavřela, prý mu to zlomilo srdce.
Pan Whitt říká, že když se znovu kavárna otevřela, vejít a dát si kávu je jako přijít domů.
„Chyběla mi ta vůně,“ řekl.
Depresivní jídlo z doby krize - ve „Square Meal“
Krátce po nastoupení do úřadu prezidenta v březnu 1933 seděl Franklin Delano Roosevelt v Oválné pracovně a obědval.
Labužník prezident Roosevelt si pochutnával na vybraných pokrmech z 5. avenue, jako byla paštička z husích jatýrek a marylandská želví polévka.
Jeho menu na tento den ale bylo skromnější: vejce na ďábelský způsob v rajské omáčce, bramborové pyré a jako dezert švestkový pudink.
„Byl to akt kuchařské solidarity s lidmi, kteří trpěli,“ řekla Jane Ziegelmanová.
Její manžel Andrew Coe dodal: „Bylo to také poselství Američanům, jak mají jíst.“
Pár, který žije v Brooklyn Heights, se věnuje gastronomické historii.
Poslední kniha Andrewa Coea „Chop Suey“ byla o čínské kuchyni v Americe, zatímco Jane ve své knize „97 Orchard“ vypráví životní příběh obytného domu na Lower East Side skrze jídlo.
Jejich nová společná práce „A Square Meal“, kterou v úterý uveřejní Harper, je dějinami americké kuchyně během velké hospodářské krize.
Sami ukázali kuchařskou solidaritu a s reportérem se sešli na večeři v Eisenbergově obchodu se sendviči, malém strohém bufetu ve čtvrti Flatiron, který je v provozu od doby krize, od roku 1929.
Jane (54) si objednala smetanový sýr a sendvič se sekanými olivami, Andrew (57) si dal krocana, bramborou kaši a míchanou zeleninu.
Reportér si objednal masový karbanátek, který se podle páru výborně hodil k rozhovoru o jídle během krize.
„Karbanátky byly velmi oblíbené“, řekla slečna Ziegelmanová.
Prodával se burákový, játrový a fazolový karbanátek.
Vyráběly se z oné příměsi a další levné potraviny, která ingredienci nastavila.
Přestavte si množství buráků, které byste museli k večeři sníst.
Andrew Coe se ušklíbl.
„Ležely by Vám v žaludku jako olovo,“ řekl.
V letech před krizí byla americká kuchyně, především ve venkovských oblastech, podávána formou bufetu sněz, co sníš.
Týmy žen vařily pro dělníky z farmy a k snídani, obědu a večeři se podával čerstvě upečený koláč.
Byli to Američané, kdo posílal jídlo hladovějícím Evropanům během první světové války. „A Square Meal“ sleduje, jakými způsoby se národ vyrovnával s tím, že to najednou nebyla země hojnosti.
„Byla to doba, kdy se jídlo stalo ústředním, obávaným bodem pro americký lid,“ řekl Coe na vysvětlenou, proč se on a jeho žena rozhodli o tom napsat.
Stejně obávanou byla nová rozpočtová dieta: Rozšířila se záhadná jídla, jako karbanátky a jídla z kastrůlků, kastrůlek jako „úžasný způsob, jak využít zbytky,“ poznamenala Ziegelmanová, protože kuchaři mohli skrýt neestetické přísady pod vrstvu krémové omáčky.
Čerstvé ovoce bylo nahrazeno levnějším sušeným ovocem.
Maso - po dlouhé roky ústřední bod amerického jídla - se stalo úsporně přidělovaným luxusem.
Podivné směsky, které měly sloužit jako kalorická a výživová výplň, měly přednost před chutí nebo dokonce zdravým rozumem při vaření.
Během průzkumů pro knihu, která obsahuje recepty, slečna Ziegelmanová připravila dobové jídlo z pečené cibule plněné burákovým máslem.
„Nebyl to oblíbený přírůstek na večerní stůl,“ řekl Andrew Coe.
Jane Ziegelmanová zdůraznila: „Bylo to surrealistické.“
Burákové máslo s pečenou cibulí nejde dohromady.
Bylo to typické pro spoustu domácích receptů.
Tak, jako nikdy předtím a nikdy potom, domácí ekonomové - mezi nimi Louise Stanley, šér federálního úřadu pro domácí ekonomiku v letech 1923 až 1943 - řídili stravovací návyky země.
Uveřejňovali recepty a články v novinách a časopisech, vyzývaly ženy, aby převzaly otěže rozpočtu, a šlichty, jako jsou smetanové špagety s mrkví, přeměňovaly na chutná jídla.
Kniha „A Square Meal“ je oslavou historických pochoutek.
Především zákusky vznikly v odpovědi vlády jejím hladovým občanům, jako třeba póza prezidenta Herberta Hoovera „dám si koláč“.
Zatímco veřejně chválil jednoduchou iowskou farmářskou kuchyni svého dětství, stoloval jako vybraný milionář, kterým se stal.
„Rád jedl kontinentální kuchyni, jako jsou ryby s okurkovou omáčkou,“ řekl Andrew Coe.
Jedl v téměř vyzlacené místnosti, na sobě měl smoking.
Byl neuvěřitelně staromódní.
Prezident Roosevelt by se pravděpodobně dopustil stejné chyby, kdyby jej jeho žena Eleanor nepřiměla, aby šel příkladem svým vlastním žaludkem.
Jak kniha vypráví, paní Rooseveltová najala hospodyni, která se o chuť vůbec nezajímala. To vedlo k tomu, že se Bílém domě „nejen podávalo téměř to nejponurejší jídlo v celém Washingtonu, ale také tím nejneutěšenějším způsobem připravené.“
Řada jídelních návyků z doby krize odezněla hned, jak se země znovu postavila na nohy.
Odkaz zůstal v našem neustálém zkoumání kalorií a výživových hodnot, říká slečna Ziegelmanová, a ve způsobu, jakým se věda aplikuje na vaření.
Pár říká, že během psaní knihy lépe pochopili stravovací návyky matky slečny Ziegelmanové - třeba proč nedokázala vyhodit jídlo.
„Měla opravdový strach z plýtvání jídlem,“ řekl Andrew Coe.
Ziegelmanová připoměla: „Lidem z ní bylo špatně.“
Došlo k nehodě s věnečky.
Když byly u Eisenberga čisté stoly, ona a pan Coe vytáhli dezert, který připravili doma: švestkový dezert, který prezident Roosevelt jedl k obědu.
„Říká se mu švestkový krém,“ řekla Ziegelmanová a dodala, že obvyklým trikem bylo dávat skromným receptům elegantní názvy.
Nebyl tam žádný krém, jen švestky, trochu mouky, cukr, voda a skořice.
Každý neochotně zabořil lžičku do husté hnědé hmoty.
Překvapivě to bylo špatné.
Andrew Coe si přidal, a pak ještě jednou.
A jako správný hospodář řekl své manželce: „Hodilo by se trochu sekaných vlašáků.“
Evropané: Migranti si jdou pro dávky.
Většina uprchlíků, kteří se valí do Evropy, přichází z ekonomických důvodů.
Mladí Rusové si dělají legraci sami ze sebe.
Takhle by vypadaly seriály, kdybychom je točili my.
Skupina ruských umělců, která si říká 2D Among Us, si dělá legraci ze své rodné země.
Pomocí photoshopu vytváří koláže, které vtipně ukazují, jak by to vypadalo, kdyby se slavné seriály a filmy natáčely v Rusku.
Gilead má nárok na úhradu nákladu na právní zastupování v případu patentu proti žloutence typu C proti koncernu Merck
Soudce okresního soudu rozhodl, že společnost Gilead Sciences Inc má nárok na proplacení poplatků za právníky, které jí vznikly v procesu ohledně patentu proti žloutence typu C proti výrobci léků společnosti Merck & Co Inc.
V červnu byl zrušen rozsudek, podle kterého měla Gilead zaplatit 200 milionů za škody kvůli porušení dvou patentů společnosti Merck v souvislosti s velmi úspěšnými léky společnosti Gilead, Sovaldi a Harvoni, poté, co federální soudce zjistil opakovaně protizákonné jednání na straně společnosti Merck, kromě jiného lež pod přísahou a další neetické praktiky.
Federální soudce Beth Labson Freeman do spisu ve čtvrtek uvedl, že Gilead má nárok na prominutí poplatků, které vznikly v souvislosti se zastupováním v případu.
Merck se snaží dohnat Gilead, která dominuje trhu léků nové generace proti žloutence typu C, které dokáží vyléčit více než 90 procent pacientů s tímto onemocněním jater.
Případ pochází z roku 2013, kdy se Gilead a Merck žalovaly navzájem a tvrdily, že jsou vlastníkem základního laboratorního výzkumu pro sofosbuvir, aktivní složku léků od Gilead.
Američany podporované vojenské jednotky tvrdí, že získaly plnou kontrolu nad městem Manbídž
Vojenské jednotky podporované USA získaly plnou kontrolu nad severním městem Manbídž nedaleko hranic s Tureckem poté, co poslední bojovníci Islámské státu z města uprchli, uvedl v pátek mluvčí skupiny.
Syrské demokratické síly (SDF) nyní město pročesává po odchodu zbytku skupiny radikálů, kteří se ve městě ukrývali.
Jednotky osvobodily přes 2 000 civilistů, které radikálové zadržovali, řekl agentuře Reuters Sharfan Darwish z aliance SDF a vojenské rady Manbídže.
„Město je nyní plně pod naší kontrolou, ale ještě jej prohledáváme“, řekl agentuře Reuters.
Clintonovi v roce 2015 vydělali 10,75 milionu dolarů a zaplatili federální sazbu daně 34,2 procent
Hillary Clintonová v pátek uveřejnila své daňové přiznání za rok 2015, ve kterém je uvedeno, že prezidentská kandidátka za demokraty a její manžel měli v daném roce příjmy ve výši 10,75 milionu dolarů a odvedli skutečnou daň ve výši 34,2 procenta.
Clintonovi v roce 2015 věnovali 1 milion dolarů na charitu, převážně do Clintonovy nadace (Clinton Foundation). Exprezident Bill Clinton přispěl do společné kasy částkou téměř honoráři ve výši 5,3 milionu dolarů za přednášky, a dřívější ministryně zahraničí přiznala příjem ve výši 3 miliony dolarů od nakladatelství Simon & Schuster za svou knihu o svém působení na ministerstvu zahraničí.
Clintonové spolukandidát, americký senátor Tim Kaine ze státu Virginie spolu se svou ženou Anne Holtonovou uveřejnili daňová přiznání za 10 let.
Ti v roce 2015 zaplatili skutečnou daň ve výši 20,3 procenta.
„Hillary Clintonová a Tim Kaine jsou i nadále vzorem finanční transparentnosti,“ řekla v prohlášení Jennifer Palmieri, která Clintonové pomáhala s kampaní.
Na proti tomu Donald Trump se schovává za falešné výmluvy a ustupuje od svých dřívějších slibů, že svá daňová přiznání uveřejní.
Je zvykem, že kandidáti na prezidenta USA uveřejní svá daňová přiznání, i když jim to zákon neukládá.
Trump, obchodník z New Yorku, a jeho právníci citovali audit daňového odboru Ministerstav financí USA jako důvod pro jeho odmítnutí daňová přiznání uveřejnit.
„Your move,“ řekl pobočník kampaně Hillary Clintonové na Twitteru a navázal na daňová přiznání demokratské kandidátky.
Michael Cohen, zvláštní Trumpův poradce, řekl ve čtvrtek CNN, že by Trumpovi nedovolil daňová přiznání uveřejnit, dokud nebudou audity skončené.
Podle Trumpových kritiků, mezi nimiž je republikánský kandidát na prezidenta z roku 2012 Mitt Romney a další členové republikánské strany, se shodují, že jeho odmítnutí vyvolává otázky ohledně jeho čistého zisku, příspěvků na charitu, obchodních transakcí a různých dalších vztahů, včetně vztahů s Ruskem.
Clintonová v otázce silně vystupuje a v pátek uveřejnila video, ve kterém připomíná, jak vysoce postavení republikání na Trumpa naléhají, aby svá daňová přiznání uveřejnil.
Ve čtvrtek otázku zmíni ve svém projevu k ekonomickým otázkám v Michiganu.
„Odmítá udělat to, co dělali všichni ostatní kandidáti na prezidentský úřad po desetiletí - uveřejnit svá daňová přiznání,“ řekla před lidmi.
Organizace Politico uvedla, že Trump za poslední dva roky 90. let platil žádné nebo velmi nízké daně, a publicista New York Times citoval řadu daňových poradců a účetních, kteří tvrdí, je tomu tak může být i v současnosti.
Sazby federálních daní se staly tématem ve volbě prezidenta.
Clintonová prosazuje pravidlo pojmenované po miliardáři Warrenu Bufettovi, které by zajistilo, že všichni, kteří za rok vydělají více než 1 milion dolarů, zaplatí daň ve výši minimálně 30 procent.
Prezident Barack Obama návrh také podporuje.
Minulý týden Buffet na shromáždění Clintonové v Omaze, ve státě Nebraska, kde sídlí Buffetův konglomerát Berkshire Hathaway, vyzval Trumpa k setkání a výměně daňových přiznání.
Buffett řekl, že také prošel auditem IRS a že Trump se „nebojí“ finančního úřadu, ale voličů.
Kampaň Clintonové uveřejnila daňová přiznání zpětně až do roku 2007.
Clintonovi, kteří nyní žijí v Chappaqua ve státě New York, v průměru v letech 2007 až 2014 zaplatili federální daň v průměru ve výši 32 procent a kombinovanou daň ve výši přibližně 40,5 procent.
Z daňového přiznání Clintonových za rok 2015 vyplývá, že na rozdíl od většiny Američanů, činí v jejich příjmech mzdy pouhých 100 dolarů.
Jejich hlavní investicí byl nízkonákladový vzájemný indexový fond, z které Clintonovi uvedli příjem na dividendách a úrocích ve výši 109 000 dolarů.
Další zprávy Kevin Drawbaugh, úprava Jonathan Oatis
Kondomy naplněné chilli nebo ohňostroj na ochranu slonů v Tanzánii
Ochránci přírody v Tanzánii používají neortodoxní způsob, aby zabránili slonům v chození do lidských obydlí - hází na ně kondomy naplněné práškem z chilli.
Tento postup se osvědčil a nadace Honeyguide, která s nápadem přišla před několika lety, společně s americkou ekologickou organizací The Nature Conservancy tento postup propaguje a školí dobrovolníky ve vesnicích na severu Tanzánie, jak pomocí tohoto nenásilného postupu ve čtyřech krocích chránit své domovy a úrodu, aniž by ublížili zvířatům.
Mnoho z nich dříve na svou obranu používalo kopí.
Pátek je světový den slonů, který je věnován ochraně těchto zvířat.
„Od té doby, co je vyvinuli tento ... soubor nástrojů, jsme zaznamenali změnu chování v těchto společenstvích. Lidé si mnohem víc věří, že dokáží slony udržet mimo svá pole bez toho, aby je zraňovali,“ řekl výkonný ředitel nadace nadace Honeyguide Damian Bell v prohlášení.
Prvním a druhým krokem je na procházejícího slona posvítit baterkou a spustit klakson.
Pokud jej to neodradí, dojde na vyhození takzvaného „oblaku chilli“.
Chilli prášek smíchaný se solí se spolu s petardou zabalí do kondomu, jeho konec se zauzluje tak, aby z něj koukal pouze knot.
Po odpálení se kondom vybuchne a do vzduchu se rozpráší jemný prášek z chilli.
Většinou stačí jeden závan a slon se vydá jiným směrem.
Poslední možností je odpálení ohňostroje, který vyvolá hlasitou, jasnou explozi.
Židovský režisér se opřel do berlínského hotelu za to, že odstranil kód pro volání do Izraele na „žádost“ Arabů - RT News
Francouzský filmový režisér židovského původu vyvolal rozruch v médiích poté, co zjistil, že hotel Kempinski Bristol v Berlíně nemá v uveden kód pro volání do Izraele, podle slov zaměstnance na základě „požadavku“ arabských klientů.
Claude Lanzmann, autor dokumentárního snímku o holokaustu „Shoah“, ventiloval svou frustraci z hotelu Kempinski Bristol v Berlíně v otevřeném dopise německému deníku FAZ.
Během svého nedávného pobytu se Lanzmann pokoušel najít Izrael v seznamu kódů pro volání v hotelu.
Stát ovšem nebyl uveden mezi zeměmi, do kterých je možné volat přímo z pokoje.
Jak je možné, že v roce 2016 byl v Berlíně, hlavním městě Německa, Izrael odstraněn a smazán?
Napsal Lanzmann.
Hotel Kempinski Bristol namísto toho nabízí možnost volání do Izraele přes vlastní call centrum.
Režisér hledal vysvětlení a s problémem se obrátil na recepci hotelu.
Odpověď, kterou dostal, Lanzmanna podle jeho slov „šokovala“.
Pracovník hotelu odpověděl, že o opatření bylo „rozhodnuto po uvážení vedení společnosti Kempinski Hotels.“
Důvod k tomuto kroku režiséra ještě více popudil.
„Většina našich hostů jsou Arabové a ti požadovali, aby byl volací kód Izraele vymazán,“ citoval Lanzmann zaměstnance ve svém dopise.
Podle Suddeutsche Zeitung velvyslanec Izraele v Německu Yakov Hadas-Handelsman případ označil za „velkou ostudu“.
Událostí jsme byli zděšeni a šokováni.
Samo o sobě je to obrovská ostuda.
Skutečnost, že k něčemu takové došlo v Německu a navíc v takovém hotelovém řetězci, je ještě větší hanbou.
Další vysvětlení není potřeba.
Očekáváme, že hotel vyvodí správné závěry,“ uvedl.
Událost vyvolala silnou reakci online, lidé ji označili za skandální.
Někteří se domnívají, že hotel Kempinski se jednoduše „ztratil“ v požadavcích arabských zákazníků.
„Hanba vám,“ uvádí se v jiném příspěvku, který poukazuje na to, že hotel, který se nachází v noblesní ulici Kurfurstendamm, stojí nedaleko synagogy.
Podle deníku Spiegel samotný hotel rychle odbyl jakákoliv obvinění tím, že událost označil za „přehlédnutí“ a Lanzmanovi se „omluvil“.
„Nikdy nebyl vydán přímý příkaz“ nezahrnovat Izrael do seznamu kódů pro volání, cituje Suddeutsche Zeitung zástupce hotelu Kempinski.
Dodává, že kód pro volání byl do seznamu přidán.
Policie použila slzný plyn a gumové projektily proti protestujícím brazilským studentům
Ke střetu studentů a policie došlo v brazilském San Paulu ve čtvrtek, když se studenti sešli na demonstraci proti vládním reformám v systému veřejného vzdělávání.
Policie proti protestujícím použila slzný plyn a gumové projektily.
Problém se vyhrotil, když se vládní pořádkové služby pokusily studenty rozehnat, což skončilo tím, že policie použila gumové projektily a slzný plyn.
Demonstrace se zúčastnilo několik stovek studentů s cílem vyjádřit jejich obavy z plánů.
Mezi návrhy guvernéra státu San Paulo Geralda Alckmina v cílem ušetřit peníze je také uzavření téměř stovky veřejných škol a přemístění 300 000 studentů.
Někteří z účastníků demonstrace bylo možné vidět, jak sprejují na zdi nápisy proti dočasnému prezidentovi Michelu Temerovi.
Nejnovější protest přichází pouze několik dní poté, co se demonstranti vydali hromadně do ulic na podporu sesazené prezidentky Dilmy Rousseffové, když senát v zemi rozhodl o jejím obžalování.
Obchod mezi Ruskem a Íránem vzrostl o 71 % - RT Business
Podle ruského velvyslance v Íránu Levana Dzhagaryana vzrostl po zrušení sankcí mezi Moskvou a Teheránem obchodní obrat v meziročním srovnání o 70,9 procenta.
Jak velvyslanec uvedl, od doby, kdy byly zrušeny mezinárodní sankce proti Íránu, došlo k nárůstu zájmu ze strany ruských firem, které v zemi obchodují.
Ruské společnosti obnovují existující vazby s Íránem, zatímco nové firmy jsou připraveny na trh vstoupit.
Další rozšiřování obchodu je samozřejmě jednou z hlavních priorit bilaterální spolupráce s Íránem,“ řekl Dzhagaryan.
Poznamenal, že během prvních pěti měsíců roku 2016 obchodní obrat mezi Ruskem a Íránem vzrostl o 70,9 procenta ve srovnání se stejným obdobím za rok 2015 a dosáhl výše 856 milionů dolarů.
Konkrétně export Ruska do Íránu vyskočil o 91,5 procenta a dosáhl výše 697 milionů dolarů.
Ruský import z Íránu se zvýšil o 16 procent na částku 158 milionů dolarů.
Skokový nárůst obchodu zajistily dodávky strojního vybavení, pozemních vozidel a zbraní,“ řekl velvyslanec.
Dzhagaryan také očekává, že Rusko letos navštíví rekordní počet turistů z Íránu.
V uplynulém roce ruská diplomatická mise v Íránu vydala občanům Íránu okolo 35 000 víz, převážně cestovních.
Írán se navíc poprvé dostal mezi top 20 zemí podle počtu turistů, kteří do Ruska přijíždějí.
Bezpečně lze říci, že rekordní počty turistů z Íránu v Rusku z loňského roku budou překonány,“ uvedl.
Současně ale Írán navštěvuje relativně malý počet Rusů. Velvyslanec doufá, že zde dojde ke změně.
„Osobně mohu doporučit návštěvu měst Isfahan, Shiraz a Yazd, kde jsou v dobrém stavu dochované památky dávné perské civilizace,“ řekl.
Skot Callum Skinner spěchá domů poté, co Britové získali zlato v cyklistice
Callum Skinner ze Skotska vstoupil včera v noci do síně slávy v mužském týmovém sprintu na velodromu v Riu, když trio týmu VB obhájilo titul z Londýna 2012.
Třiadvacetiletý rodák z Glasgowa byl v roli brzdy, kterou vzal za svou Skot Sir Chris Hoy, a mladík legendu potěšil, když se přiřítil do cíle a ukradl vítězství z rukou favorizovaného Nového Zélandu.
Británie před čtyřmi lety překvapivě vyhrála a Hoy získal pátou ze svých šesti olympijských zlatých medailí.
A stejný trik zopakovali po skončení skromného šestého na světovém šampionátě v dráhové cyklistice v březnu, i když Hoy mezitím svou kariéru ukončil.
Problémem mezi Pekingem a Londýnem byla náhrada za specializovaného úvodního závodníka Jamieho Staffa.
Hindes se tedy objevil právě včas.
Po odchodu Hoye se také uvolnilo místo, které se pokusil vyplnit Kian Emadi a Matt Crampton.
Skinner byl mužem britských trenérů a hledání potenciálu se nyní potvrdilo.
Kenny Hindes - který byl spolu s Hoyem šampiónem před čtyřmi lety - a se Skinnerem dosáhli olympijského rekordu při kvalifikaci, ale trikot převzal v prvním kole Nový Zéland.
A britské trio získalo v týmovém sprintu zlato.
Hindes byl po svém kole lehce pozadu, ale Kenny tým protlačil dopředu a Skinner vedení udržel.
Změna strategie byla velkou částí transformace, kdy Hindes jel na vyšší převod, aby se zpomalil a umožnil Kennymu a částečně i Skinnerovi, aby tempo udrželi.
Hoy závod sledoval ze své pozice komentátora BBC a když Skinner, Kenny a Hindes vystoupili na pódium, nespustil z nich oči.
Třiadvacetiletý Skinner, rodák z Glasgowa, řekl: „Je to lichotivé srovnání.“
Jsem tu, abych ze sebe dostal to nejlepší a udělal čest svému jménu.
Vytvořili jsme olympijský rekord ve finále a porazili jsme ty nejlepší.
Bylo to prostě neuvěřitelné.
Neexistuje žádný lepší způsob, jak jak to vyhrát.
Po triumfu vedle Kennyho a Hoye v Londýně v roce 2012 Hindes přiznal, že schválně po slabém startu spadl na dráhu.
Poznámku později stáhl zpět a soupeři Británie neměli žádnou možnost se odvolat.
Tentokrát okolo tohoto vítězství k žádnému takovému problému nedošlo.
Hindes řekl: „Se všemi těmi britskými vlajkami na tribunách jsem si připadal jako v Londýně.“
V posledních třech měsících jsme se všichni jako tým semkli.
Prohráli jsme v mnoha světových závodech, takže znovu vyhrát olympiádu je prostě úžasné.
Je to jedna událost, jedna zlatá medaile pro národ, který vyhrál sedm z deseti soutěží v Pekingu a v Londýně.
Pokud to má být ukazatel pokroku za uplynulých pět měsíců, pak na nás na velodromu čeká úspěšných pět dnů.
S formou, kterou Kenny předvedl, není nemyslitelné, že by zopakoval Hoyův úspěch a vyhrál na jedné olympiádě tři zlaté medaile současně.
To by pak pro Kennyho - který je přesně na den o 12 let mladší než Hoy, má také narozeniny 23. března (toto datum se zdá být pro britský sport posvátné, v tento den slaví narozeniny také Steve Redgrave, Mo Farah a Roger Bannister) - znamenalo celkem šest zlatých a jednu stříbrnou medaili.
Stejně, kolik získal Hoy.
Jako další se Kenny bude účastnit sprintu, který začíná dnes a potrvá další tři dny.
Osmadvacetiletý rodák z Boltonu řekl: „Nyní si užívám tuhle.
Týmový závod je vždy nejlepší.
Vyhráváte spolu s ostatními.
Abych pravdu řekl, vyhrávat sám za sebe je trochu osamělé.
Hindes řekl: „Když vyhraje další dvě zlaté medaile, měl by dostat rytířský titul.“
To byl jediný medailový závod toho dne, ale Británii čekaly ještě další dobré zprávy.
Sir Bradley Wiggins, Ed Clancy, Steven Burke a Owain Doull se kvalifikovali jako nejrychlejší do stíhacího závodu družstev na čtyři kilometry.
Skončili s časem 3:51.943.
Světový rekord, který padl v Londýně v roce 2012, je 3:51.659.
První kolo a finále (22:42) se konají v dnešním druhém dni závodu, na který se dozajista zaměří Wiggins.
Včera před kvalifikačním závodem debatoval s komisaři, když jej rozhodčí vyzvali ke změření výšky.
V obdobném závodě žen, který pokračuje a končí zítra, dosáhly Laura Trottová, Joanna Rowsell Shandová, Elinor Barkerová a Katie Archibald of Milngavie světového rekordu s časem 4:13.260.
Tým VB se spolehl na svůj silný tým dráhové cyklistiky a ovládl střední období olympijských her a získal spoustu medailí.
Po opravdu výjimečných výkonech, prokazujících naprostou převahu v Pekingu a v Londýně, se během příprav na Rio očekávání snížila.
Na pozadí se odvíjely dramatické události, v neposlední řadě odstoupení technického ředitele Shane Suttona v dubnu kvůli obvinění ze sexismu a diskriminace, a ukončení kariéry velikánů, jako je Hoy nebo Victoria Pendletonová.
Nicméně, jak dokládá první noc závodů na velodromu, se zdá, že legendární reputace, že tým Velké Británie dokáže podat špičkový výkon s perfektním načasováním, by se mohla znovu potvrdit.
Nejistá budoucnost tavírny v Portlandu po ukončení smlouvy na dodávku energie
Budoucnost portlandské tavírny hliníku ve Victorii - a pracovních míst stovek pracovníků - je nejistá kvůli elektrárně, která podnik zásobuje elektřinou a která informovala o úmyslu jednoho z vlastníků tavírny smlouvu o dodávkách elektřiny ukončit. Očekává se, že všechny smlouvy o dodávkách elektřiny budou zkráceny.
K tomuto kroku dochází po té, co vláda státu Victoria dříve v tomto roce rozhodla, že neprodlouží poskytování dotací, které podnik udržují v chodu.
Platnost pevné dvacetileté dotace vyprší v listopadu.
V podniku Alcoa Portland může být v ohrožení až 2000 pracovních míst.
Při zavření může být ohroženo až 2000 pracovních míst - přímých nebo nepřímých.
A protože tavírna spotřebovává okolo 10 procent celkové vyrobené elektřiny ve Victorii, může dojít k dalším lavinovitým dopadům.
Alcoa v roce 2014 zavřela tavírnu Point Henry, což loni vedlo k zavření elektrárny Anglesea.
Tavírna společnosti Alcoa v Portlandu je prodělečná a hrozí jí zavření.
Tento krok následuje po několikaletých spekulacích ohledně budoucnosti podniku, původně v reakci na silný australský dolar a v nedávné době kvůli cenám za produkci závodu.
AGL, která velké tavírně hliníku dodává elektřinu z elektrárny Loy Yang A v údolí Latrobe Valley, prohlásila, že očekává, že některý z dalších tří vlastníků se také rozhodne smlouvu ukončit.
Většinovým vlastníkem závodu je společný podnik společností Alcoa a Alumina, malé obchodní podíly drží čínská společnost CITIC a japonská Marubeni Corp.
„AGL očekává, že portlandský závod bude i nadále fungovat, jinými slovy tedy, že vyzická poptávka po elektřině z tavírny bude pokračovat,“ sdělila.
AGL uvedla, že smlouvy jsou takzvané „zajišťovací smlouvy“, které měly vstoupit v platnost od listopadu 2016.
Smlouvy mají 12měsíční výpovědní lhůtu, takže jejich platnost skutečně skončí v roce 2017.
„AGL i nadále předpokládá, že smlouvy se budou podílet na zisku za fiskální rok 2017“, prohlásila elektrárna.
Jakýkoliv možný dopad na zisky AGL od fiskálního roku 2018 dále je v současné době omezený díky silnému výhledu komoditního trhu pro velkoobchodní ceny elektřiny.
AGL uvedla, že již sepsala hodnotu smluv podle svých účetních knih ve výši 187 milionů dolarů „pro případ, že by k ukončoení došlo.“
Společnost Alcoa uvedla, že rozhodnutí smlouvy ukončit „nemá dopad na její ... schopnost provozovat tavírnu nebo zabezpečit dodávky elektřiny do tavírny.“
Americká společnost uvedla, že v roce 2010 uzavřela s Loy Yang kontrakt na 20 let, který měl začít platit od listopadu tohoto roku, i když ještě musí vysvětlit, proč od smlouvy ustoupila.
Analytici jsou velmi opatrní, pokud jde o možné uzavření portlandské tavírny ve Victorii i závodu Tomago v blízkosti Newcastlu v důsledku slabé ekonomiky v odvětví.
Vedoucí provozu AGL Stehpen Mikkelsen, který se na začátku tohoto týdne obrátil na analytiky, řekl, že Portland ročně spotřebovává okolo 600 megawattů elektrické energie a Tomago okolo 900 megawattů.
Pokud by se oba tyto podniky stáhly z trhu, znamenalo by to podstatné snížení poptávky na trhu [elektrické energie].
Pro nás jako výrobce by to nebylo dobré,“ řekl.
Kendall je nejen hvězdou realitní TV show Kardashianových - nyní je obálce zářijového Vogue
Kendall Jennerová (20), modelka a čtvrtá dcera matky-manažerky klanu Kris Kardashian-Jennerová, se objevila na titulní stránce zářijového vydání amerického časopisu Vogue.
Kendall, ambasadorka značky Estee Lauder, která předváděla na fashion weeku v Miláně, Paříži a New Yorku, novinku oznámila ve čtvrtek na svém účtu na Instagramu.
„V místnosti plné lidí, které miluji, se mi při pohledu na tuhle titulní stránku chce plakat,“ napsala Kendall.
Odhalení titulní stránky následovalo bizarní (nebo jednoduše pokračování humoresky v podání Kardashianových?) zinscenované video, ve kterém byla celá rodina Kardashianových-Jennerových (baroví výtržníci Rob a Caitly a spolu s nimi všemi oblíbený strýček ze šoubyznysu, producent Keeping Up Ryan Seacrest). Na obálku své sestry zapomněli, jenom aby scéna mohla skončit klasickým obratem: připravují tajnou párty.
Je to obehraná dějová linie téměř každého „narozeninového“ dílu dětské televizní show (Seacrest pronáší: „Myslela jsi si, že jsme na Tebe zapomněli?“ s upřímností kresleného králíka v pořadu v osm hodin ráno), ale Kris nějak potřebovala zajistit, aby se ostatní děvčata na téhle publicitě mohla přiživit.
Protože když se podíváme na zářijové číslo časopisu Vogue, tak jsme určitě vstoupili do nové éry Kardashianových.
Starší sestra Kim možná Kendall na obálku Vogue dotlačila (byla na ní společně se svým manželem Kanye Westem v dubnu 2014), ale titulka zářijového vydání časopisu je jiná liga.
Zářijové vydání časopisu Vogue je nejprodávanější číslo celého roku.
Vydání, které svou tloušťkou připomíná spíš knihu pro reklamní účely než módní časopis, přitahuje celou řadu inzerentů (Fashionista napočítal, že z 832 stran v loňském vydání bylo 615 stran s reklamním obsahem).
Odhalení hvězdy, která se objeví na titulní stránce, je nedočkavě očekáváno, takže není divu, že v uplynulých dvou letech snímky časopisu unikly ještě před jeho oficiálním uveřejněním.
Mezi ženy, které se v minulosti na obálce objevily, patří Naomi Campbell, Linda Evandelista nebo Kate Moss.
V uplynulých letech se na titulní stránce objevilo zajisté víc „celebrit, které dělají modelky“ než „modelek, které jsou celebritami.“
Jennifer Lawrence, držitelka Oscara a ambasadorka značky Dior, se na titulce objevila v roce 2013, o rok později měla tu čest Lagy Gaga.
Ale i když je velmi nepravděpodobné, že Kendall - kterou magazín popisuje jako „průlomovou modelku“ její generace - spadne do první kategorie, bude ve velmi dobré společnosti.
Tyto celebrity nejsou příbuznými známých lidí, ani hvězdy realitních show, nebo děti dneška, které vědí, jak udělat dobře sestříhané video (i když Jennerová představuje tohle všechno).
Jsou to prokazatelně talentované ženy, které vynikají v zábavním průmyslu.
Beyoncé, která se na titulní stránce objevila loni, měla jeden z nejsilnějších roků ve své kariéře díky vydání alba Lemonade.
Samozřejmě ne každý je z úspěchu Jennerové nadšený.
Její pozice ve světě módy bude vždy obtížná kvůli její účasti v reality show.
Stephanie Seymorová, původní modelka Victoria's Secret v červnu kritizovala Jennerovou a její kolegyni Gigi Hadidovou a nazvala je „děvkami okamžiku“.
Tyto pocity se znovu rozhořely se zprávou o tom, že se Jennerová objeví na obálce Vogue.
Ale tahle nespokojenost není na místě.
Kendall Jennerová je na obálce zářijového Vogue.
Je to supermodelka v pravém slova smyslu.
Předvádí pro Marka Jacobse.
Prodává vám make up od Estee Lauder.
Ona a všechny její sestry vám prodávají snímky sebe samých na jejich vlastních paywallech.
Prodává fotky dcery Cindy Crawfordové, které nafotila pro magazín LOVE.
A ve volných chvílích účinkuje v reality show, možná pouze jako jeden ze způsobů, jak vidět Kourtney a její děti.
Komunitní centra právní pomoci ročně odmítnou 160 000 lidí
Více než 160 000 nejvíce ohrožených občanů je každý rok v komunitních centrech právní pomoci odmítnuto a v sektoru samotném se chystají na dopady, které budou mít další omezení finančních prostředků na již nadmíru vytížené služby.
V Queenslandu tři z pěti lidí - převážně lidé v pokročilém věku, imigranti, ohrožení pracovníci, oběti násilí a lidé bez finančních prostředků k tomu, aby mohli bojovat s nespravedlivým vystěhováním a podobně - jsou odmítání již ve chvíli, kdy hledají bezplatnou právní pomoc a zastupování.
Komunitní právní služby, které jsou již tak napjaté k prasknutí, se chystají k dalším škrtům.
Od června příštího roku tato centra právní pomoci přijdou o dalších 30 procent federálních financí.
Ředitel komunitních center právní pomoci v Queensladu James Farrell řekl, že podle nejnovější souhrnné zprávy Národní asociace komunitních center právní pomoci bylo zjištěno, že každoročně je odmítnuto pět tisíc lidí.
Pan Farrell řekl, že bez zrušení rozhodnutí federální vlády se situace bude zhoršovat.
„Komunitní centra právní pomocí v Queenslandu jsou chronicky podfinancovaná, což znamená, že tisícům lidí jsou odmítány životně důležité služby, které potřebují,“ uvedl.
Lidé, kteří unikli ze vztahů s násilníkem, lidé s nadměrnými a ochromujícími dluhy, rodiny procházející odloučením, pracovníci, kteří jsou nespravedlivě propuštěni - všichni tito lidé mají problémy s právními rozměry a tato zpráva ukazuje, že nemají šanci získat pomoc, kterou potřebují.
Federální vláda od června 2017 sníží financování o 30 procent, což povede k tomu, že další tisíce ohrožených lidí z Queenslandu se bude muset zorientovat ve složitých právních problémech bez pomoci.
Vyzýváme státního zástupce a senátora Queenslandu George Brandise, aby ihned zabránili tomuto zkrácení financí, aby se lidem dostala pomoc, kterou potřebují, když se dostanou do právních problémů.
V uplynulém roce vláda státu dostála svému závazku zajistit financování právní pomoci až do výše celonárodního průměru.
Nyní je čas podívat se na potřeby komunitních center právní pomoci a společenství jejich klientů a Palaszczukova vláda musí do této důležité práce investovat.
Žaloba na kampaň Donalda Trumpa po té, co člen štábu údajně namířil zbraň
New York: Na kampaň Donalda Trumpa byla podána žaloba za údajnou nečinnost po té, co jim bylo sděleno, že ředitel operací v Severní Karolíně v únoru namířil zbraň na člena štábu během jízdy džípem.
Incident byl popsán v soudním spise, který ve středu u státního soudu v Charlottě předal Vincent Bordini, bývalý softwarový školitel kampaně ve státě.
Bordini řekl, že měsíce čekal na to, že se situace vyřeší interně, než dospěl k závěru, že „se tak nestane“.
Ředitel Earl Phillip „naznačil prsty pistoli, dal pravý ukazováček na spoušť a namířil hlaveň Vincentovi na čéšku“, uvedl Bordini v žalobě.
Ve spisu se uvádí, že Bordini po stížnosti u lokálního a regionálního vedení kampaně zjistil, že minimálně čtyři další lidé zažili s Phillipem to samé.
„Zbraně nemusí vystřelit, aby způsobily škodu“, uvedl Bordini v žalobě.
Žaloba přichází pouhé dva dny poté, co republikánský kandidát na prezidenta vyvolal pozdvižení, když voličům v Severní Karolíně řekl, že by mohli zakročit majitelé a držitelé zbraní (což je v USA upraveno ve druhém dodatku ústavy), pokud bude jeho soupeřka Hillary Clintonová zvolena a bude moci jmenovat své soudce.
Trumpova kampaň říká, že média jeho slova vytrhla z kontextu a že Trump násilí neobhajoval.
Bordini v žalobě žádá od kampaně náhradu za nedbalý dohled a od Phillipa za ohrožení osobní bezpečnosti, nezákonné použití násilí a způsobení emocionální újmy.
Trumpova mluvčí Hope Hicksová na zprávu s žádostí o komentář ihned nereagovala.
Pokusy získat vyjádření od Phillipa byly neúspěšné.
WCCB, místní pobočka zpravodajství ve městě Charlotta, oznámila, že Phillip před nedávnem z kampaně odešel.
Telefonát do jeho poradenské společnosti Innovative Consulting Services nikdo během krátké doby nereagoval.
Republikánský kandidát na prezidenta Donald Trump vede kontroverzní předvolební kampaň.
Případ Bordini versus Donald J. Trump For President Inc., 16-CS-14300, General Court of Justice, Superior Court Division County of Mecklenburg (Charlotta).
Británie musí šířit dál olympijského ducha a expanzovat Heathrow
Heathrow bude také zdrojem obnovy a prosperity nejen pro naše místní komunity a napříč Londýnem, ale v celé zemi.
Pro mě je Heathrow obrovským způsobem přitažlivé, právě tak, jako byl Londýn 2012, kdy jsme vyvinuli mimořádné úsilí, abychom zajistili, že všechny naše národy a regiony budou moci z olympijských her těžit.
Olympijské hry znamenaly obrovské přínosy pro Startford i East End.
A my to uděláme znovu tak, že vytvoříme příležitosti pro místní lidi a firmy v blízkosti Heathrow.
Jenom pro naše místní komunity vytvoříme 10 000 nových výučních míst, 40 000 nových pracovních míst a skoncujeme s nezaměstnaností mladých lidí v okolí letiště.
Stejně jako před londýnskou olympiádou v roce 2012 se i zde najdou tací, kteří si budou myslet, že rozšíření Heathrow je příliš velké.
Bylo mi řečeno, že Británie nikdy nebude připravena na olympijské hry a že se na světovém pódiu zesměšníme.
Pochybovači se mýlili v roce 2012 a i v případě Heathrow se ukáže, že neměli pravdu.
Vždy bude nutné zdolávat překážky, ale Heathrow dokáže zodpovědět každou otázku, která se ho týká.
Stejně jako olympijské hry, je Heathrow projekt infrastruktury, na kterém se podílí mnoho lidí a firem, nejenom pouze několik.
Rozšíření je příležitostí k vytvoření 180 000 nových pracovních míst, ekonomickému růstu o 211 miliard liber, k zanechání dědictví v podobě dovedností a zaměstnání jak v okolí letiště, tak v celé Velké Británii.
Máme na Heathrow skvělý tým, který v termínu a se stanoveným rozpočtem zavedl program investic do infrastruktury za 11 miliard liber, počínaje terminálem T5 - který byl zvolen nejlepším terminálem na světě pět let za sebou, po terminál T2, který byl postaven mezi dvěma nejrušnějšími ranvejemi na světě.
Nyní jsou připraveni dodat třetí ranvej, za kterou stojí 16 miliard liber soukromých investic.
Hry v Londýně v roce 2012 byly obrovským úspěchem Velké Británie a já jsem přesvědčen, že rozšíření Heathrow jím bude také.
Je čas, abychom dál šířili ducha olympijských her a rozšířili Heathrow, zajistili si obchodování do budoucna a zanechali dědictví dovedností a zaměstnanosti, na které může být Británie hrdá.
Lord Paul Deighton je předseda rady představenstva a dřívější náměstek pro obchodní záležitosti ministerstva financí.
Adblock Plus - Facebook ve hře na kočku a myš v blokování reklam
Z pokusů, jak obejít programy blokující reklamu, se pro společnosti, které na online marketingu vydělávají, stala hra na kočku a myš. Aspoň to tvrdí jedna ze společností, které takový software programují.
Ve čtvrtek, tedy pouze dva dny poté, co Facebook oznámil, že bude blokovat reklamní filtry na svých desktopových stránkách, společnost Adblock Plus na svých stránkách uveřejnila příspěvek, ve kterém se uvádí, že uživatelé mohou aktualizovat filtry v jejich programu a znovu zablokovat reklamu na této sociální sítí.
Facebook v úterý uvedl, že jeho desktopové webové stránky změní kódování okolo reklam, aby bylo pro reklamní filtry složitější zjistit, které části stránky jsou reklamní.
Adblock ale nyní tvrdí, že nové kódy již obešli.
Mluvčí Adblocku Ben Williams do příspěvku v blogu napsal, že „tahle jakási válka mezi komunitou open source blokování reklam a těmi, kdo se je snaží obejít, trvá od té doby, co bylo blokování reklam vynalezeno,“ a že Facebook pravděpodobně přijde s další vlastní opravou.
Skutečnost, že se společnost vlastnící největší sociální síť na světě do války zapojila, jen dokazuje, jak velkým problémem se blokování reklam pro průmysl stalo.
Podle studie, tkerou loni provedla Pagefair a Adobe používá na celém světě filtry reklamy okolo 200 milionů lidí - téměř čtyřnásobek, než tomu bylo v roce 2013.
Mobilní reklama nyní dosahuje 84 procent zisků z reklamy na Facebooku, každý den Facebook z mobilních zařízení navštíví 1,03 miliardy aktivních uživatelů.
Mluvčí uvedl, že společnost jde ovšem proti reklamním filtrům na desktopech, protože mobilní filtry reklamy na mobilní aplikace pro sociální síť a Instagram nefungují.
Reklamy na desktopech stále představují zisk natolik vysoký, aby se Facebook rozhodl do něj investovat.
Facebook také v úterý uvedl, že bude aktualizovat nástroj pro „nastavení reklamy“ (ad preferences), aby dal lidem možnost lépe kontrolovat, jak se jim reklamy zobrazují.
Ve čtvrtek Facebook prohlásil, že nové filtry Adblocku je znepokojují, protože by na stránkách mohly také blokovat obsah, který s reklamou nesouvisí.
„Pro lidi to není příjemná zkušenost a my tento problém chceme vyřešit,“ uvedl mluvčí Facebooku v e-mailovém prohlášení.
Blokování reklamy je necitlivý nástroj, a proto jsme se raději zaměřili na budování nástrojů, jako jsou Ad Preferences, které dají kontrolu lidem.
Ženu srazilo auto švýcarské dálnici
Oběť ležela na dálnici uprostřed noci.
Policie hledá svědky události, při které ve čtvrtek v ranních hodinách byla na dálnici několika vozy přejeta žena, která se pravděpodobně pokusila spáchat sebevraždu.
K nehodě došlo na dálnici A1 nedaleko Morges v kantonu Vaud krátce po půlnoci ve čtvtek.
Policie ve Vaud v prohlášení uvedla, že aktérka „zoufalého činu“ ležela ve tmě na silnici a přejelo ji několik aut.
Je jasné, že oběť, žena ve věku 49, se chtěla zabít a srazilo ji několik aut, včetně nákladního vozidla.
Zemřela na místě.
Několik řidičů již bylo vyslechnuto, ale podle policie stále ještě všichni nebyli identifikováni. Policie vyzývá tyto řidiče a všechny ostatní, kdo byli svědky nehody, aby se přihlásili.
Bylo otevřeno kriminální vyšetřování, „logický“ krok v situaci, jako je tato, řekl pro Le Tribune de Geneve právní zástupce Gilles Hofstetter.
Stále je nutné zjistit, zda některý ze zúčastněných řidičů bude čelit nějakým obviněním.
Bylo možné nárazu zabránit?
Tohle musí žalobce zjistit,“ řekl Hofstetter.
Na základě dvou podobných případů z uplynulých pěti let se zdá, že řidiči nést odpovědnost nebudou.
V obou případech - z nichž v jednom se jednalo o osobu jdoucí po dálnici - bylo rozhodnuto, že motoristé nemohou očekávat chodce, který uprostřed noci přechází dálnici, jak noviny uvedly.
Minulý rok byla policejní důstojnice zbavena obvinění za usmrcení z nedbalosti poté, co v noci v srpnu 2014 srazila a usmrtila muže, který ležel na dálnici A1 nedaleko Paynerne.
U soudu zaznělo, že oběť ve věku 22 let popíjela alkohol a na silnici omdlela.
Soud shledal, že policejní důstojnice - která reagovala na nouzové volání - jela přiměřeným způsobem a že přítomnost muže na silnici byla „zcela výjimečná a nepředvídatelná situace,“ uvedl soudce.
Kdokoliv s informace o čtvrtečním incidentu, ke kterému došlo u Morges, by se měl přihlásit na policii na telefonních číslech 021 644 83 46 nebo 021 644 44 44.
Tolerantní město.
Praha je oblíbenou destinací LGBT komunity.
Asociace českých cestovních kanceláří a agentur (AČCKA) očekává, že v rámci Prague Pride do Prahy přijede až 20 tisíc návštěvníků.
V pátek to sdělila výkonná ředitelka AČCKA Kateřina Petříčková.
Šestý ročník Prague Pride začal 8. srpna, festival přibližuje život leseb, gayů, bisexuálů a transsexuálů (LGBT).
Loni se akce zúčastnilo asi 35 tisíc lidí.
"Praha patří mezi nejpopulárnější destinace LGBT komunity, a to pro vysokou míru tolerance a širokou škálu specializovaných podniků," uvedla Petříčková.
Podle průzkumu pořadatelů utrácejí zahraniční návštěvníci festivalu v průměru denně 3100 korun na osobu.
Gay turistům jsou na podporu jejich cestování k dispozici speciální mapy Prahy s kompletním seznamem pražských gay a gay-friendly barů, klubů, kaváren a restaurací v podobě mobilních aplikací atd.
"Pro cestovní ruch obecně platí, že LGBT klientela je velmi lukrativní, zajímá se o pobyty ve vyšších cenových relacích s vysokým standardem cestovních služeb a utrácí více než ostatní," sdělila Petříčková.
V rámci programu festivalu se letos koná i první Pride Tourism Sympozium.
Na něm přednášejí odborníci ze sektoru LGBT cestovního ruchu z Evropy, USA a Číny.
Festival pokračuje do neděle 14. srpna.
Hlavním tématem letos je láska, ale akce se bude věnovat rovněž několika tematickým oblastem, kterými jsou rodina, prevence AIDS a transgenderová problematika.
Vrcholem festivalu bude v sobotu tradiční průvod s alegorickými vozy, který půjde z Václavského náměstí na Letnou.
Průvod, kterého v minulých letech účastnily tisíce lidí, letos uctí minutou ticha památku obětí červnového útoku v nočním klubu v Orlandu, kde útočník zastřelil 49 lidí, převážně homosexuálů.
Pat a Mat slaví čtyřicet let.
Neodraditelní kutilové Pat a Mat, jejichž snaha končí obvykle katastrofou, baví malé i velké diváky již čtyřicet let.
Pilotní díl tohoto večerníčkového seriálu režiséra Lubomíra Beneše měl premiéru 12. srpna 1976.
Za vznikem tohoto animovaného seriálu, který nyní znají diváci ve více než stovce zemí světa, byly kreslené vtipy výtvarníka a režiséra Lubomíra Beneše, které vymýšlel pro časopis se dvěma kutily pány Ouholíčkem a Sedlecem.
Beneš poté přizval ke spolupráci dramaturga Jiřího Kubíčka a výtvarníka Vladimíra Jiránka a společně vytvořili film Kuťáci.
Dnešní podobu se žlutým a červeným trikem a kulichem a rádiovkou dostaly postavičky v roce 1979, kdy začal v Krátkém filmu Praha vznikat seriál pro Slovenskou televizi.
Jména Pat a Mat pak kutilové dostali v roce 1985, tentokrát se točilo již přímo pro Krátký film Praha.
V roce 1990 založil Lubomír Beneš své vlastní studio animovaného filmu AIF Studio v Praze a Curychu, kde vznikly další díly.
Po jeho smrti v roce 1995 pokračovaly další díly s jinými tvůrci, na mnohých z nich se podílel Benešův syn Marek.
V současnosti existuje přes devadesát epizod s příběhy těchto kutilů, kterým se vše sype pod rukama, ale nikdy se na sebe nezlobí a jsou vždy plní optimismu, nápadů a kutilského nadšení a nakonec jsou se svým dílem spokojeni, což doloží známým gestem "...a je to!".
Pat a Mat se dokonce z televizních obrazovek přesunuli do knih, na DVD i do divadla a postavičky či další hračky s vyobrazením Pata a Mata jsou hitem každého hračkářství.
Pohádka pro Fidži i pro dvouletou Harmonii.
Konec týdne je ve znamení pohádek, vybrali jsme pro vás jednu sportovní a jednu ze života.
Obě mají dobrý konec.
Tak se pojďme podívat.
Fidži dosáhlo historického úspěchu.
Co je důvodem radosti celé země?
Dvouletá britská dívenka má identickou kamarádku a je s ní šťastná.
A za jaké věci lidé nejvíce utrácí na letištích?
To je páteční přehled ze světových webů.
První medaile z olympijských her.
Historický úspěch slaví ostrovní stát Fidži.
Ragbyový výběr tohoto souostroví porazil ve finále olympijského turnaje sedmičkového ragby tým Velké Británie.
Je to tak vůbec první medaile, jež pro sebe Fidži na olympiádě získalo.
Čekání na zisk prvního cenného kovu trvalo šedesát let od vyslání první výpravy na olympijské hry.
Velkou zásluhu na úspěchu nese trenér Fidži.
Je však ironií, že jím je Brit Ben Ryan.
Tým vede od roku 2013 a po finále coby britský občan mohl být na rozdíl od svých krajanů spokojený.
"Pojďme hrát volně a lehce a uvidíme, jestli největší zápas v naší historii zvládneme," prohlásil trenér před finále.
Fidži jej nakonec suverénně ovládlo a malý stát s 900 tisíci obyvateli nyní prožívá olympijskou pohádku.
Zprávu přinesl francouzský deník Le Monde.
Nová kamarádka a štěstí pro malou dívenku.
2letá Harmonie-Rose Ivy Allenová, jež od 11 měsíců žije bez rukou a nohou dostala novou kamarádku.
Panenku, která vypadá jako ona.
"Mami, ona je jako já," radovala se dvouletá dívenka, jak prozradila její matka pro ABC News.
Dodala, že její dcerka ráda panence sundává ruce a nohy a pak společně sedí bez protéz.
Harmonii byla v necelém roce života diagnostikována meningitida typu B, lékaři jí dávali pouze desetiprocentní šanci na přežití.
Není nic, co bych na ní nemilovala.
Je krásná, chytrá, vtipná a nikdy se nevzdává.
Má i nadhled.
Viděla jsem jí, jak se představuje ostatním dětem se slovy Ahoj, já jsem Harmonie a nemám ruce, dodala matka.
Podívejte se, jakou radost panenka vyvolala.
Za co nejvíc utrácíme na letišti?
CNN přináší zjištění, podle něhož lidé na letištích nejvíce utratí za balenou vodu.
Řetězec prodejen Hudson's travel essential stores zveřejnil údaje za poslední rok, kde shrnuje 10 výrobků, které zákazníci v jeho obchodech na letištích kupují nejčastěji.
Voda byla suverénně první.
Nápoje byly obecně velmi oblíbené, v první desítce se jich umístilo osm.
Deváté místo obsadilo velké balení bonbónů M&M s kokosovou příchutí.
A dokážete uhodnout, kdo uzavírá první desítku?
Jako jediná z výše uvedených věcí se nedá jíst.
Podle CNN je to deník The Wall Street Journal.
Mezi další populární noviny prodávané na letištích patří: New York Post, The New York Times USA Today.
Mezi časopisy to jsou US Weekly, In Touch a The Economist.
Veslařští suveréni.
Prostě jdeme vyhrát, smáli se Murray s Bondem.
Veslaři Eric Murray a Hamish Bond z Nového Zélandu suverénně kralují kategorii dvojek bez kormidelníka již sedm let a svoji dominanci potvrdili i na olympijských hrách v Riu de Janeiro.
Na první pohled nesourodá dvojice přešla na menší posádku po olympiádě v Pekingu a od roku 2009 drtí konkurenci.
Na laguně Rodriga de Freitase si ve čtvrtečním finále připsali 69. výhru v řadě.
V čem jsme jiní než ostatní?
Jsme prostě hezčí, vtipkoval Murray již v průběhu olympijské regaty, když měl odpovídat na otázky o dominanci novozélandské dvojice.
Upřímně řečeno, neděláme nic odlišného oproti ostatním.
Prostě tvrdě trénujeme, hodně tvrdě.
A neustále se snažíme vylepšit svoji techniku, to je naše filozofie, řekl Murray již vážněji.
Jejich nadvláda je pozoruhodná i proto, že jsou fyzicky odlišní.
Murray je téměř dvoumetrový a stokilový chasník, akademicky vyhlížející Bond je o pět centimetrů menší a o 15 kilogramů lehčí.
Navíc mají i rozdílnou povahu.
Bond studuje a věnuje se financím, Murray má za sebou například charitativní boxerský zápas.
I kvůli tomu spolu mimo veslování moc času netráví.
Eric nastupuje do lodě v podstatě s tím, že nemůžeme prohrát.
Prostě jdeme vyhrát.
Já mám tendenci přemýšlet nad tím, co se může pokazit, přiznal Bond, který i na tiskové konferenci názorně předvedl, že dominantní v posádce je Murray.
Právě on vždy odpovídal jako první a Bond čekal na svoji příležitost.
Na vodě však ničí soupeře klidnou silou.
Jedou si své tempo, a třebaže často ještě v polovině trati nejsou v čele, na jejich postupné zrychlování ještě protivníci nenašli recept.
Závodíme na dvoukilometrové trati a my jsme nikdy nechtěli jet první kilometr nadoraz.
Jen se prostě snažíme jet tempo, které nikdo jiný nedokáže.
Víme, co musíme udělat, abychom vyhráli, řekl čtyřiatřicetiletý Murray.
Se svým o čtyři roky mladším parťákem získal sedm zlatých medailí na mistrovství světa.
Triumfovali i v roce 2007, kdy byli oba členy zlaté čtyřky bez kormidelníka.
Právě po nečekaném neúspěchu větší posádky na olympiádě v Pekingu o rok později se rozhodli přesednout na dvojku bez kormidelníka.
Na olympiádě v Londýně zřejmě největší porážku své kariéry odčinili a dominanci potvrdili i v Riu.
Londýn byl hodně intenzivní.
Dělali jsme vše, co nám trenér řekl, a na nic se neptali.
Tentokrát to bylo trochu zábavnější.
Věděli jsme, že to bude zatraceně těžké, a museli jsme se ujistit, že jsme na tom psychicky dobře, uvedl Murray.
Víme, že nás všichni chtějí svrhnout z trůnu.
Ten terč na zádech máme pořád.
My se ale snažíme být půl kroku před všemi, dodal.
Model klimatu podle NASA: Venuše byla kdysi obyvatelná
Podle projekcí nového klimatického modelu NASA byla Venuše kdysi obyvatelná.
Vědci v Goddardově institutu NASA pro studium vesmíru vyvinuli model pro zkoumání Venuše pomocí nástrojů a algoritmů podobných těm, které používají vědci zabývající se studiem klimatu.
Model byl navržen k určení toho, zda kdysi na Venuši, jejíž povrch je horký, bez vody a prosycená CO2, mohly panovat podmínky podobné podmínkám na Zemi.
Vědci již dříve navrhli, že nízkou rychlost otáčení Venuše lze vysvětlit její hustou atmosférou.
Podle nejnovějších simulací se ale zdá, že se Venuše kdysi mohla pyšnit řídkou atmosférou podobnou Zemi a přitom se otáčela pomalu.
Model se také zabýval dřívější topografií Venuše.
Na planetě pravděpodobně byly oblasti sušší než na Zemi, ale kdysi na ní byl dostatek vody a zeměpisné rozmanitosti k tomu, aby na ní vládl život a poskytovala ochranu proti rychlému odpařování.
Venuše dříve také využívala Slunce, které bylo o 30 procent tlumenější.
„V simulaci modelu GISS Venuše během pomalého otáčení vystavuje svou denní stranu ke slunci téměř dva měsíce najednou,“ vysvětlil vědec z GISS Anthony Del Genio v nové zprávě.
Takto dochází k ohřívání povrchu a tvorbě deště, který vytváří hustou vrstvu mraků, které se chovají jako deštník a povrch zaštiťují před přílišným solárním teplem.
Výsledkem je podnebí s průměrnými teplotami, které jsou ve skutečnosti o něco nižší, než v současné době na Zemi.
Model sestavil příběh Venuše podobný evoluci, kterou dříve hypoteticky sestavili planetární vědci.
I když byla Venuše v minulosti pravděpodobně obyvatelná -- v průběhu několik miliard let -- byla vystavena přílišnému horku a ultrafialovému záření.
Její oceány se odpařily a vodní páry byly ultrafialovým světlem spáleny.
Vodík unikl a zbyla pouze hustá atmosféra oxidu uhličitého se smrtelným účinkem skleníkového plynu -- to je Venuše, jak ji známe dnes.
Výzkumníci své výsledky z nového klimatického modelu Venuše uveřejnili v časopise Geophysical Research Letters.
Patrick Roy rezignoval na post trenéra týmu Colorado Avalanche
Patrick Roy ve čtvrtek rezignoval na svůj post trenéra a viceprezidenta hokejových operací týmu Colorado Avalanche, jako důvod uvedl nemožnost podílet se na rozhodovacím procesu v otázkách týmu.
Výkonný viceprezident/generální manažer Colorada Joe Sakic krok potvrdil a uvedl, že klub začne ihned hledat nového trenéra.
„Poslední tři roky jsem působil jako hlavní trenér a viceprezident hokejových operací pro Colorado Avalanche, s energií, vášní a odhodláním,“ uvedl padesátiletý Roy v prohlášení.
Dlouho a intenzivně jsem během léta přemýšlel, jak mohu tým zlepšit, dát mu hloubku, kterou potřebuje, a dostat jej na vyšší úroveň.
Aby to bylo možné dosáhnout, je nutné, aby vize trenéra a viceprezidenta hokejových operací byly v souladu s vizí organizace.
Musí mít také možnost podílet se na rozhodnutích, která mají dopad na výkonnost týmu.
Tyto podmínky v současné době nejsou splněny.
Sakic, který Roye 23. května 2013 přijal, mu poděkoval za jeho přínosy týmu.
„Patrick mě o svém rozhodnutí dnes informoval,“ řekl Sakic.
Ceníme si všeho, co pro naši organizaci udělal, a přejeme mu do budoucna hodně štěstí.
Roy byl nominován na výhru Jacka Adamse jako nejlepší trenér ligy během své první sezóny s Avalanche 2013/2014.
Dovedl tým k zisku 112 bodů a prvnímu místu v Centrální divizi. Colorado se ale potýkalo s Minnesotou v prvním kole play-off a během posledních dvou let mu vždy zápasy po sezóně nevyšly.
Tým Avalanche v sezóně 2015/2016 dosáhl skóre 39:39:4 a chybělo mu pět bodů k získání druhé divoké karty v západní konferenci.
Brankář Roy, který se zapsal do Síně slávy, vyhrál Stanley Cup čtyřikrát -- dvakrát s Montreal Canadiens a dvakrát s Avalanche.
Pracovníci na ropné plošině v Severním moři obnovují rozhovory a přerušují stávku
Vrchní představitelé jednajících stran uvedli, že stávky kvůli mzdám pro pracovníky ropné plošiny v Severním moři jsou přerušeny, zatímco se všechny strany sporu sešly na nové kolo vyjednávání.
Ke stávkám proti společnosti služeb pro ropná pole Wood Group sporadicky docházelo na plošinách v Severním moři, které provozuje společnost Royal Dutch Shell.
„Wood Group a odborové organizace Unite a RMT mohou potvrdit, že se dohodly na obnovení procesu pro řešení současných neshod,“ uvádí se v prohlášení.
Počínaje příštím týdnem budeme mít v průběhu nadcházejících několika týdnů řadu celodenních setkání, kde se na problémy pokusíme podívat z nových úhlů.
Podle odborových organizací je jejich nedávná akce, která byla podle jejich slov první za více než 25 let, na protest proti mzdovým škrtům až o 30 procent.
Společnost Wood Group v letošním roce snížila sazby a vyplatila svým dodavatelům v Severním moři asi o 9 procent méně kvůli negativnímu tržnímu tlaku.
Snížení sazeb společností přichází po desetiprocentním snížení pro pobřežní společnosti v roce 2014.
Společnost tvrdí, že další škrty by společnosti poskytly prostor vyrovnat se s tržním poklesem.
Na druhé straně Shell vyškrtl ze svých výplatních listin tisíce lidí a oznámil plány na opuštění operací na poli ropy a zemního plynu až v 10 zemích kvůli modernizaci svých procesů - bezprostředně po mega fúzi s britskou energetickou společností BG Group.
Energetické společnosti jsou pod tlakem kvůli nízkým cenám ropy, ekonomické situaci spojené s červnovým rozhodnutím Británie opustit Evropskou unii.
Člen parlamentu ze Skotska Dave Anderson se na začátku tohoto týdne setkal s odborovými předáky, aby projednal jednu z největších pracovních neshod celé generace, která vedla ke stávce v Severním moři.
Severní moře, jak uvedl, je pro ekonomiku v regionu životně důležité.
„V Severním moři a v celé zemi potřebujeme ekonomiku, která funguje pro všechny, nejenom pouze pro některé,“ uvedl v prohlášení.
Pro porovnání, v roce 2016 se očekává téměř 1,4 miliardy dolarů investic do nových projektů v Severním moři, zatímco průměr za uplynulých pět let byl okolo 7 miliard dolarů.
Kepler měří rychlost otáčení hvězd v Plejádách
Nejnovější mise Keplerova vesmírného teleskopu na pomoc astronomům je získání téměř kompletního seznamu rychlostí otáčení hvězd z hvězdokupy Plejády.
Nové údaje pomáhají astronomům pochopit, proč se hvězdy ve hvězdokupě točí různými rychlostmi, a také, jak doba otáčení souvisí se zformováním planety.
„Doufáme, že porovnáním našich výsledků s jinými hvězdokupami se dozvíme více o vztahu mezi hvězdnou hmotou, jejím stářím a dokonce historií v jejím solárním systému,“ uvedla v nové zprávě Luisa Rebullová, výzkumná pracovnice v centru Caltech's Infrared Processing and Analysis Center v Pasadeně.
Hvězdokupa Plejády se nachází 445 světelných let od Země.
Mnoho hvězd ve shluku nyní právě dosahuje stavu dospělosti a vznikly asi přes 125 milióny let.
Nyní se otáčí nejrychleji.
V okamžicích maximálních rychlostí otáčení tyto dospívající hvězdy uvolňují obrovská množství hvězdného větru.
Protože se tyto větry pohybují podél magnetických polí hvězd, mají na ně zpomalující účinek.
Spolu s tím, jak hvězda stárne, zpomaluje se i její rychlost otáčení.
Kepler měří rychlost otáčení každé hvězdy tak, že měří čas mezi objevením rozeznatelných bodů na hvězdách -- podobných slunečním skvrnám.
Podle nejnovějších údajů o rychlostech otáčení se větší hvězdy otáčejí pomaleji než méně masivní hvězdy.
Rebullová přirovnává hvězdy k tanečníkům, větší dělají piruety pomaleji než ti menší.
„V „baletu“ Plejád vidíme, že pomaleji se točící hvězdy jsou masivnější, zatímco ty, které se točí nejrychleji, jsou obvykle velmi lehké hvězdy,“ řekla Rebullová.
Protože je hvězdokupa Plejád tak blízko, slouží jako ideální kosmická laboratoř pro porovnávání kvality hvězd a rychlostí otáčení.
„Plejády nám poskytují kotvu pro teoretické modely hvězdné rotace do obou směrů, u mladších i starších hvězd,“ řekla Rebullová.
Stále je toho hodně, co se chceme dozvědět o tom, jak, kdy a proč hvězdy zpomalují svou rychlost otáčení a tak říkajíc „pověsí své taneční boty na hřebíček“.
Rebullová a její kolegové podrobně popsali nejnovější analýzu rychlostí otáčení Plejád ve třech studiích, které budou brzy uveřejněny v časopise Astronomical Journal.
Je kvalifikační dohoda nutná?
Jestliže bych se nepřihlásila, pak by se tedy kvalifikační dohoda neuzavírala a po několika měsících bych mohla přejít do jiné nemocnice?
Je vůbec možné po dostudování pracovat bez přihlášení do specializačního vzdělávání?
Jedná se mi o to, že v oboru, ve kterém bych chtěla pracovat, je nyní volné pracovní místo jen v poněkud vzdálenější nemocnici, ale zhruba za půl roku by se mohlo uvolnit místo v jiné, kde bych potom ráda pracovala.
Nevím si tedy rady, jak situaci zhruba onen půlrok řešit, pokračuje dotaz.
Odpovídá Mgr. Lenka Vlková.
Žádný právní předpis nestanoví povinnost uzavřít kvalifikační dohodu se zaměstnavatelem - nemocnicí.
Kvalifikační dohoda je právní institut, jejž upravuje zákoník práce, a může být uzavřena mezi zaměstnancem a zaměstnavatelem za účelem zajištění návratnosti vynaložených nákladů spojených se zvyšováním či prohlubováním kvalifikace zaměstnance.
V oblasti zdravotnictví je přitom vyvíjen dlouhodobý tlak na neuzavírání těchto dohod s ohledem na zajištění pracovní mobility zdravotnických pracovníků a ne všechny nemocnice v současné době tuto dohodu vyžadují.
Podle zákona č. 95/2004 Sb., o podmínkách získávání a uznávání odborné způsobilosti a specializované způsobilosti k výkonu zdravotnického povolání lékaře, zubního lékaře a farmaceuta, přitom výslovně platí, že účast na specializačním vzdělávání se považuje za prohlubování kvalifikace (nikoli za její zvyšování).
To znamená, že kvalifikační dohoda může být podle zákoníku práce uzavřena, pouze pokud náklady dosahují alespoň 75 000 Kč.
Žádný právní předpis ani nestanoví povinnost přihlásit se do specializačního vzdělávání.
Zákon pouze stanoví podmínky žádosti o zařazení do oboru specializačního vzdělávání.
Lékař je však podle zákona oprávněn vykonávat povolání lékaře již díky absolvování potřebného vysokoškolského studia, i když za zákonem stanovených podmínek (pod odborným dohledem lékaře se specializovanou způsobilostí v příslušném oboru).
Zákon předvídá situaci, kdy může být do specializačního vzdělávání lékaře započítána odborná praxe absolvovaná v jiném oboru specializace, pokud její obsah a rozsah odpovídají příslušnému vzdělávacímu programu.
Teoreticky by tak bylo možné započítat dobu odpracovanou jinde, což by odpovídalo tazatelčině situaci.
Nicméně s ohledem na to, že neznám bližší okolnosti tohoto případu, lze doporučit konzultaci s příslušným odborem ministerstva zdravotnictví (odbor vědy a lékařských povolání), jelikož ministerstvo zdravotnictví ze zákona poskytuje poradenskou a konzultační službu související se zařazením do specializačního vzdělávání a s jeho průběhem.
Poradenskou službu též bezplatně poskytuje Česká lékařská komora, jejímž členem musí každý lékař být.
Lékaři ze syrského Halabu žádají o intervenci USA.
Spojené státy nevyvinuly žádné úsilí, aby bylo ukončeno obléhání (povstalecké části města vládními vojsky), a nevyužily svůj vliv k prosazení ochrany civilistů, citovala z dopisu adresovaného Bílému domu agentura AFP.
"Nepotřebujeme slzy, soucit, a dokonce ani modlitby; zoufale však potřebujeme vytvořit nad východním Halabem bezletovou zónu, aby byly zastaveny útoky, a potřebujeme mezinárodní akci, která by zajistila, že Halab nebude znovu obklíčen," uvedli lékaři.
Ruské síly, které podporují armádu věrnou prezidentovi Bašáru Asadovi, oznámily, že ode dneška zastaví každý den na tři hodiny údery v oblasti Halabu, aby umožnily bezpečný průjezd humanitárním konvojům.
Od 9:00 do 12:00 SELČ mají být zastaveny veškeré vojenské aktivity, letecké útoky a dělostřelecká palba.
Šéf humanitárních operací OSN Stephen O'Brien to sice přivítal, zdůraznil nicméně, že je potřeba alespoň dvoudenní příměří.
Na Obamu se podle AFP v dopise obrátilo 15 z 35 lékařů, kteří působí ve východní části Halabu, již ovládají rebelové.
Píší, že během pětileté války byli svědky násilné, kruté smrti nesčetných pacientů, přátel a kolegů.
Svět přihlíží a konstatuje, jak složitá Sýrie je, ale dělá jen málo pro to, aby nás ochránil.
Nedávné nabídky evakuace obyvatel od syrského režimu a Ruska zní jako jen lehce zastřené výhrůžky, podotkli pediatři, chirurgové a další lékaři.
Lékaři uvedli, že za uplynulý měsíc bylo zaznamenáno 42 útoků na lékařská zařízení v Sýrii, z toho 15 na nemocnice, ve kterých pracují.
Nejvíce smutní jsme z toho, že musíme rozhodovat o tom, kdo bude žít a kdo zemře.
Na pohotovost k nám přicházejí malé děti s tak vážnými zraněními, že musíme mezi nimi vybírat ty, u nichž je největší pravděpodobnost, že přežijí.
A někdy nemáme ani potřebný materiál, abychom jim pomohli, popsali lékaři.
Před dvěma týdny se udusili čtyři novorozenci, když výbuch přerušil dodávky kyslíku do jejich inkubátorů.
Lapali po dechu a pak jejich život skončil - dřív, než skutečně mohl začít, připomněli.
Armáda věrná prezidentovi Bašáru Asadovi, kterou podporují ruské síly, v minulých týdnech obklíčila povstalci ovládanou východní část Halabu, uvnitř se ocitlo bez dodávek potravin přes 200.000 lidí.
Rebelům, kteří jsou pod neustálými údery ruského a syrského letectva, se v sobotu po třech týdnech podařilo obklíčení prolomit a zahájit protiofenzivu.
Oběma stranám poté přibyly ve městě a jeho okolí posily.
